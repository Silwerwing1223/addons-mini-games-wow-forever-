local ADDON_NAME, WR = ...
WR.NAME = ADDON_NAME
WR.TEX = "Interface\\AddOns\\WarcraftRunner\\Textures\\"
WR.GAME_W = 580
WR.GAME_H = 440

WR.Games = {}
WR.State = {
    activeGame = "match3",
    running = false,
    zoneIdx = 1,
    gold = 0,
    elapsed = 0,
    shakeTimer = 0,
    flashTimer = 0,
}

WR.ZONES = {
    { id = "elwynn",    title = "Элвиннский лес",   bg = WR.TEX .. "bg_elwynn.tga",    pColor = { 1.0, 0.85, 0.35 } },
    { id = "northrend", title = "Ледяная Корона",   bg = WR.TEX .. "bg_northrend.tga", pColor = { 0.65, 0.90, 1.0 } },
    { id = "pandaria",  title = "Нефритовый лес",   bg = WR.TEX .. "bg_pandaria.tga",  pColor = { 1.0, 0.68, 0.82 } },
    { id = "durotar",   title = "Врата Оргриммара", bg = WR.TEX .. "bg_durotar.tga",   pColor = { 1.0, 0.45, 0.15 } },
}


function WR.GetSpellIcon(spellID, fallback)
    local tex
    if C_Spell and C_Spell.GetSpellTexture then
        local ok, res = pcall(C_Spell.GetSpellTexture, spellID)
        if ok and res then tex = res end
    end
    if not tex and GetSpellTexture then
        local ok, res = pcall(GetSpellTexture, spellID)
        if ok and res then tex = res end
    end
    return tex or fallback or (WR.TEX .. "minimap_icon.tga")
end

WR.SOUND = "Interface\\AddOns\\WarcraftRunner\\Sounds\\"

function WR.PlaySound(id)
    if id == 847 then id = 856 end
    if PlaySound then pcall(PlaySound, id, "SFX") end
end

local lastVoiceTime = 0
function WR.PlaySoundFile(file, cooldown, channel)
    if not file then return false end
    local now = GetTime and GetTime() or 0
    if cooldown and cooldown > 0 then
        if (now - lastVoiceTime) < cooldown then
            return false
        end
        lastVoiceTime = now
    end
    local fullPath = file:find("^Interface\\") and file or (WR.SOUND .. file)
    if PlaySoundFile then
        pcall(PlaySoundFile, fullPath, channel or "SFX")
    end
    return true
end

function WR.PlayVoice(soundFile, cooldown)
    return WR.PlaySoundFile(soundFile, cooldown or 1.5)
end

function WR.SetColor(tex, r, g, b, a)
    if tex.SetColorTexture then
        tex:SetColorTexture(r, g, b, a or 1)
    else
        tex:SetTexture(r, g, b, a or 1)
    end
end

function WR.CreateStyled(frameType, name, parent, extra)
    local tmpl = extra
    if BackdropTemplateMixin then
        tmpl = tmpl and (tmpl .. ", BackdropTemplate") or "BackdropTemplate"
    end
    return CreateFrame(frameType, name, parent, tmpl)
end

-- GPU AnimationGroup helpers
function WR.AnimPop(frame, peak)
    if not frame or not frame.CreateAnimationGroup then return end
    if frame._popAG then frame._popAG:Stop() end
    local ag = frame._popAG or frame:CreateAnimationGroup()
    frame._popAG = ag
    if not ag.s1 then
        local s1 = ag:CreateAnimation("Scale")
        s1:SetOrder(1)
        s1:SetDuration(0.10)
        if s1.SetScaleFrom then s1:SetScaleFrom(0.5, 0.5); s1:SetScaleTo(peak or 1.15, peak or 1.15)
        else s1:SetScale(peak or 1.15, peak or 1.15) end
        ag.s1 = s1

        local s2 = ag:CreateAnimation("Scale")
        s2:SetOrder(2)
        s2:SetDuration(0.10)
        if s2.SetScaleFrom then s2:SetScaleFrom(peak or 1.15, peak or 1.15); s2:SetScaleTo(1.0, 1.0)
        else s2:SetScale(1.0 / (peak or 1.15), 1.0 / (peak or 1.15)) end
        ag.s2 = s2
    end
    ag:Play()
end

local FloatPool = {}
function WR.FloatText(text, x, y, r, g, b)
    if not WR.HUDLayer then return end
    local fs
    for _, f in ipairs(FloatPool) do
        if not f._busy then fs = f; break end
    end
    if not fs then
        fs = WR.HUDLayer:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        local ag = fs:CreateAnimationGroup()
        local tr = ag:CreateAnimation("Translation")
        tr:SetOffset(0, 46)
        tr:SetDuration(0.85)
        tr:SetSmoothing("OUT")
        local al = ag:CreateAnimation("Alpha")
        al:SetFromAlpha(1)
        al:SetToAlpha(0)
        al:SetStartDelay(0.35)
        al:SetDuration(0.50)
        ag:SetScript("OnFinished", function()
            fs:Hide()
            fs._busy = false
        end)
        fs._ag = ag
        table.insert(FloatPool, fs)
    end
    fs._busy = true
    fs:ClearAllPoints()
    fs:SetPoint("CENTER", WR.Viewport, "CENTER", x or 0, y or 20)
    fs:SetText(text)
    if r then fs:SetTextColor(r, g, b) else fs:SetTextColor(1, 0.85, 0.25) end
    fs:SetAlpha(1)
    fs:Show()
    fs._ag:Stop()
    fs._ag:Play()
end

function WR.Shake(duration)
    WR.State.shakeTimer = math.max(WR.State.shakeTimer, duration or 0.22)
end

function WR.DamageFlash()
    WR.State.flashTimer = 0.30
    if WR.DamageTex then WR.DamageTex:Show() end
    WR.Shake(0.25)
end

function WR.InitDB()
    WarcraftRunnerDB = WarcraftRunnerDB or {}
    if WarcraftRunnerDB.minimapAngle == nil then WarcraftRunnerDB.minimapAngle = 215 end
    if WarcraftRunnerDB.activeGame == nil then WarcraftRunnerDB.activeGame = "match3" end
    if WarcraftRunnerDB.zoneIdx == nil then WarcraftRunnerDB.zoneIdx = 1 end
    if WarcraftRunnerDB.totalGold == nil then WarcraftRunnerDB.totalGold = 0 end
    if WarcraftRunnerDB.bestMatch3 == nil then WarcraftRunnerDB.bestMatch3 = 0 end
    if WarcraftRunnerDB.bestSurv == nil then WarcraftRunnerDB.bestSurv = 0 end
    if WarcraftRunnerDB.bestTactics == nil then WarcraftRunnerDB.bestTactics = 0 end
    if WarcraftRunnerDB.bestMines == nil then WarcraftRunnerDB.bestMines = 0 end
    if WarcraftRunnerDB.bestFlappy == nil then WarcraftRunnerDB.bestFlappy = 0 end
    if WarcraftRunnerDB.bestSnake == nil then WarcraftRunnerDB.bestSnake = 0 end
    if WarcraftRunnerDB.bestSolitaire == nil then WarcraftRunnerDB.bestSolitaire = 0 end
    if WarcraftRunnerDB.bestDurak == nil then WarcraftRunnerDB.bestDurak = 0 end
end

-- Minimap button (only component loaded on PLAYER_LOGIN)
local MinimapBtn
local function UpdateMinimapPos()
    if not MinimapBtn then return end
    local angle = math.rad(WarcraftRunnerDB.minimapAngle or 215)
    local radius = (Minimap:GetWidth() * 0.5) + 8
    MinimapBtn:ClearAllPoints()
    MinimapBtn:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function CreateMinimapButton()
    MinimapBtn = CreateFrame("Button", "WarcraftRunnerMinimapButton", Minimap)
    MinimapBtn:SetSize(32, 32)
    MinimapBtn:SetFrameStrata("MEDIUM")
    MinimapBtn:SetFrameLevel(20)
    MinimapBtn:Show()
    MinimapBtn:EnableMouse(true)
    MinimapBtn:RegisterForClicks("LeftButtonUp")
    MinimapBtn:RegisterForDrag("LeftButton")

    local bg = MinimapBtn:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(22, 22)
    bg:SetPoint("CENTER")
    bg:SetTexture("Interface\\Icons\\INV_Boots_05")

    local border = MinimapBtn:CreateTexture(nil, "OVERLAY")
    border:SetSize(54, 54)
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    MinimapBtn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    MinimapBtn:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local s = Minimap:GetEffectiveScale()
            WarcraftRunnerDB.minimapAngle = math.deg(math.atan2(cy / s - my, cx / s - mx))
            UpdateMinimapPos()
        end)
    end)
    MinimapBtn:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    MinimapBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("|cFFFFD100Warcraft Runner|r")
        GameTooltip:AddLine("ЛКМ: Открыть мини-игры (/runner)", 1, 1, 1)
        GameTooltip:AddLine(string.format("Всего золота: |cFFFFD100%d|r", WarcraftRunnerDB.totalGold or 0), 0.85, 0.85, 0.85)
        GameTooltip:Show()
    end)
    MinimapBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    MinimapBtn:SetScript("OnClick", function() WR.Toggle() end)
    UpdateMinimapPos()
end

local Loader = CreateFrame("Frame")
Loader:RegisterEvent("PLAYER_LOGIN")
Loader:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        WR.InitDB()
        CreateMinimapButton()
        SLASH_WARCRAFTRUNNER1 = "/runner"
        SLASH_WARCRAFTRUNNER2 = "/wowrunner"
        SLASH_WARCRAFTRUNNER3 = "/wcr"
        SlashCmdList["WARCRAFTRUNNER"] = function() WR.Toggle() end
        print("|cFFFFD100[Warcraft Runner]|r готов! Нажми иконку у миникарты или введи |cFF33EEFF/runner|r")
    end
end)
