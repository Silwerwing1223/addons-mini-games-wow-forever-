-- WarcraftRunner v2.1.0
-- Authentic Warcraft 3D Runner & Vertical Climb mini-game

local ADDON_NAME = "WarcraftRunner"
local TEX_PATH = "Interface\\AddOns\\WarcraftRunner\\Textures\\"

local GAME_W = 580
local GAME_H = 440
local ROAD_HORIZON_Y = 215
local ROAD_BOTTOM_Y = 0
local ROAD_TOP_W = 112
local ROAD_BOT_W = 490
local NUM_ROAD_STRIPS = 14
local ZONE_SWITCH_STEP = 250 -- auto-switch zone every 400m

local ANIM_STAND = 0
local ANIM_DEATH = 1
local ANIM_RUN = 5
local ANIM_HIT = 8
local ANIM_ATTACK = 16
local ANIM_JUMP = 37
local ANIM_JUMP_ALT = 5
local ANIM_JUMP_FALLBACK = 5
local ANIM_CHEER = 68
local ANIM_ROAR = 74
local ANIM_SPRINT = 5

local ZONES = {
    {
        id = "elwynn",
        name = "Элвинн",
        title = "Элвиннский лес",
        bg = TEX_PATH .. "bg_elwynn.tga",
        road = TEX_PATH .. "road_cobble.tga",
        pColor = { 1.0, 0.85, 0.35 },
        pDirY = 18,
        pDirX = 12,
        pSize = 10,
        roadTint = { 1, 1, 1 },
    },
    {
        id = "northrend",
        name = "Нордскол",
        title = "Ледяная Корона",
        bg = TEX_PATH .. "bg_northrend.tga",
        road = TEX_PATH .. "road_northrend.tga",
        pColor = { 0.75, 0.92, 1.0 },
        pDirY = -55,
        pDirX = -28,
        pSize = 9,
        roadTint = { 1, 1, 1 },
    },
    {
        id = "pandaria",
        name = "Пандария",
        title = "Нефритовый лес",
        bg = TEX_PATH .. "bg_pandaria.tga",
        road = TEX_PATH .. "road_pandaria.tga",
        pColor = { 1.0, 0.68, 0.82 },
        pDirY = -28,
        pDirX = 24,
        pSize = 11,
        roadTint = { 1, 1, 1 },
    },
    {
        id = "durotar",
        name = "Дуротар",
        title = "Врата Оргриммара",
        bg = TEX_PATH .. "bg_durotar.tga",
        road = TEX_PATH .. "road_durotar.tga",
        pColor = { 1.0, 0.45, 0.12 },
        pDirY = 65,
        pDirX = 18,
        pSize = 9,
        roadTint = { 1, 1, 1 },
    },
}

local HEROES = {
    { id = "player",  name = "Мой герой", sub = "Текущий персонаж", unit = "player", icon = "Interface\\Icons\\Achievement_Character_Human_Male" },
    { id = "murloc",  name = "Мурлок",    sub = "Мргллглгл!",       creature = 735,   display = 397, icon = "Interface\\Icons\\INV_Misc_Head_Murloc_01" },
    { id = "sheep",   name = "Овца",      sub = "Бее-БАБАХ!",       creature = 16372, display = 856, icon = "Interface\\Icons\\Spell_Nature_Polymorph" },
    { id = "chicken", name = "Курица",    sub = "Ко-ко-ко!",        creature = 620,   display = 304, icon = "Interface\\Icons\\Spell_Magic_PolymorphChicken" },
    { id = "hogger",  name = "Дробитель", sub = "Босс Элвинна",     creature = 448,   display = 384, icon = "Interface\\Icons\\INV_Misc_Bone_OrcSkull_01" },
    { id = "orc",     name = "Орк",       sub = "Рубака Орды",      creature = 3296,  icon = "Interface\\Icons\\Achievement_Character_Orc_Male" },
}

local function SafePlaySound(soundID)
    if PlaySound then
        pcall(PlaySound, soundID, "SFX")
    end
end

local function SetSolidColor(tex, r, g, b, a)
    if tex.SetColorTexture then
        tex:SetColorTexture(r, g, b, a or 1)
    else
        tex:SetTexture(r, g, b, a or 1)
    end
end

local function CreateStyledFrame(frameType, name, parent, extraTemplate)
    local tmpl = extraTemplate
    if BackdropTemplateMixin then
        tmpl = tmpl and (tmpl .. ", BackdropTemplate") or "BackdropTemplate"
    end
    return CreateFrame(frameType, name, parent, tmpl)
end

local function InitDB()
    WarcraftRunnerDB = WarcraftRunnerDB or {}
    if WarcraftRunnerDB.minimapAngle == nil then WarcraftRunnerDB.minimapAngle = 215 end
    if WarcraftRunnerDB.bestSubway == nil then WarcraftRunnerDB.bestSubway = 0 end
    if WarcraftRunnerDB.bestDoodle == nil then WarcraftRunnerDB.bestDoodle = 0 end
    if WarcraftRunnerDB.bestFlappy == nil then WarcraftRunnerDB.bestFlappy = 0 end
    if WarcraftRunnerDB.bestWhack == nil then WarcraftRunnerDB.bestWhack = 0 end
    if WarcraftRunnerDB.totalGold == nil then WarcraftRunnerDB.totalGold = 0 end
    if WarcraftRunnerDB.zoneIdx == nil then WarcraftRunnerDB.zoneIdx = 1 end
    if WarcraftRunnerDB.heroIdx == nil then WarcraftRunnerDB.heroIdx = 1 end
    if WarcraftRunnerDB.mode == nil then WarcraftRunnerDB.mode = "subway" end
end

local State = {
    running = false,
    gameOver = false,
    mode = "subway",
    zoneIdx = 1,
    nextZoneScore = ZONE_SWITCH_STEP,
    zoneBannerTimer = 0,
    heroIdx = 1,
    elapsed = 0,
    score = 0,
    gold = 0,
    speed = 0.60,
    boostTimer = 0,
    shieldTimer = 0,
    combo = 1,
    comboTimer = 0,
    floatTimer = 0,
    shakeTimer = 0,
    flashTimer = 0,
    attackTimer = 0,
    -- Flappy
    flappyY = 220,
    flappyVy = 0,
    flappySpawn = 0,
    -- Whack-a-Murloc
    whackTime = 45,
    whackSpawn = 0,
    lives = 3,
    invulnTimer = 0,
    lane = 2,
    laneX = 0,
    jumpZ = 0,
    jumpVz = 0,
    jumpCount = 0,
    duckTimer = 0,
    roadScroll = 0,
    spawnTimer = 0,
    lanternTimer = 0,
    djX = 0,
    djY = 120,
    djVx = 0,
    djVy = 540,
    djMaxY = 0,
    keys = {},
    currentAnim = ANIM_STAND,
    desiredFacing = math.pi,
    modelLoaded = false,
}

local MainFrame, Viewport, ModelAnchor, PlayerModel
local Scene3D, HeroActor3D
local ActorPool3D = {}
local USE_3D_SCENE = false
local RoadStrips = {}
local BgParticles = {}
local Entities = {}
local Lanterns = {}
local Platforms = {}
local HUD = {}
local MinimapBtn

-- ============================================================================
-- 3D MODEL CONTROLLER (Fixed-size PlayerModel inside movable ModelAnchor)
-- ============================================================================
local function ResolveJumpAnim()
    if PlayerModel and PlayerModel.HasAnimation then
        if PlayerModel:HasAnimation(ANIM_JUMP) then return ANIM_JUMP end
        if PlayerModel:HasAnimation(ANIM_JUMP_ALT) then return ANIM_JUMP_ALT end
    end
    return ANIM_JUMP_FALLBACK
end

local function ApplyModelCameraAndAnim()
    if not PlayerModel then return end
    pcall(PlayerModel.SetPortraitZoom, PlayerModel, 0)
    pcall(PlayerModel.SetCamDistanceScale, PlayerModel, 1.45)
    if not PlayerModel.SetPortraitZoom then
        pcall(PlayerModel.SetCamera, PlayerModel, 1)
    end
    pcall(PlayerModel.SetPosition, PlayerModel, 0, 0, -0.05)
    pcall(PlayerModel.SetFacing, PlayerModel, State.desiredFacing)
    local anim = State.currentAnim
    if anim == ANIM_JUMP then anim = ResolveJumpAnim() end
    pcall(PlayerModel.SetAnimation, PlayerModel, anim)
end

local function SetHeroAnim(animID, force)
    if not force and State.currentAnim == animID then return end
    State.currentAnim = animID
    if not PlayerModel then return end
    local playID = animID
    if playID == ANIM_JUMP then
        playID = ResolveJumpAnim()
    elseif playID == ANIM_SPRINT and PlayerModel.HasAnimation and not PlayerModel:HasAnimation(ANIM_SPRINT) then
        playID = ANIM_RUN
    elseif playID == ANIM_ATTACK and PlayerModel.HasAnimation and not PlayerModel:HasAnimation(ANIM_ATTACK) then
        playID = 17
    elseif (playID == ANIM_ROAR or playID == ANIM_CHEER) and PlayerModel.HasAnimation and not PlayerModel:HasAnimation(playID) then
        playID = ANIM_RUN
    end
    pcall(PlayerModel.SetAnimation, PlayerModel, playID)
    if USE_3D_SCENE and HeroActor3D then pcall(HeroActor3D.SetAnimation, HeroActor3D, playID) end
end

local function LoadHeroModel(idx)
    State.heroIdx = idx
    if WarcraftRunnerDB then WarcraftRunnerDB.heroIdx = idx end
    if not PlayerModel then return end

    local hero = HEROES[idx] or HEROES[1]
    State.modelLoaded = false
    pcall(PlayerModel.ClearModel, PlayerModel)

    if hero.unit then
        local ok = pcall(PlayerModel.SetUnit, PlayerModel, hero.unit)
        if not ok and PlayerModel.SetDisplayInfo then
            pcall(PlayerModel.SetDisplayInfo, PlayerModel, 29110)
        end
    else
        local ok = false
        if hero.creature and PlayerModel.SetCreature then
            ok = pcall(PlayerModel.SetCreature, PlayerModel, hero.creature)
        end
        if not ok and hero.display and PlayerModel.SetDisplayInfo then
            pcall(PlayerModel.SetDisplayInfo, PlayerModel, hero.display)
        end
    end

    ApplyModelCameraAndAnim()
    if USE_3D_SCENE then UpdateHeroActor3D() end
    if C_Timer and C_Timer.After then
        C_Timer.After(0.08, ApplyModelCameraAndAnim)
    end
end


-- ============================================================================
-- SHARED 3D MODELSCENE (Unified 3D Camera, Fog, Lighting & Actors)
-- ============================================================================
local MOB_DISPLAY_IDS = {
    murloc    = 397,
    kobold    = 10913,
    sheep     = 856,
    barrel    = 2051,  -- Wooden barrel / crate prop
    barricade = 10913, -- Kobold / barricade
    coin      = 1662,  -- Floating chest/coin/orb
    potion    = 11686, -- Arcane crystal/orb
    shield    = 11686,
}

local function AcquireActor3D(displayID, animID, yaw, scale)
    if not Scene3D then return nil end
    local actor
    for _, a in ipairs(ActorPool3D) do
        if not a.inUse then
            actor = a
            break
        end
    end
    if not actor then
        local ok, created = pcall(Scene3D.CreateActor, Scene3D)
        if not ok or not created then return nil end
        actor = { obj = created, inUse = true }
        table.insert(ActorPool3D, actor)
    end
    actor.inUse = true
    pcall(actor.obj.Show, actor.obj)
    pcall(actor.obj.SetModelByCreatureDisplayID, actor.obj, displayID)
    pcall(actor.obj.SetScale, actor.obj, scale or 1.0)
    pcall(actor.obj.SetYaw, actor.obj, yaw or math.pi)
    pcall(actor.obj.SetAnimation, actor.obj, animID or 0)
    return actor
end

local function ReleaseAllActors3D()
    for _, a in ipairs(ActorPool3D) do
        a.inUse = false
        pcall(a.obj.Hide, a.obj)
    end
end

local function UpdateHeroActor3D()
    if not Scene3D or not HeroActor3D then return end
    local hero = HEROES[State.heroIdx] or HEROES[1]
    if hero.unit then
        pcall(HeroActor3D.SetModelByUnit, HeroActor3D, hero.unit)
    else
        pcall(HeroActor3D.SetModelByCreatureDisplayID, HeroActor3D, hero.display or 397)
    end
    pcall(HeroActor3D.SetScale, HeroActor3D, 1.0)
    pcall(HeroActor3D.SetYaw, HeroActor3D, 0)
    pcall(HeroActor3D.SetPosition, HeroActor3D, 0, 0, 0)
    pcall(HeroActor3D.SetAnimation, HeroActor3D, ANIM_RUN)
end

local function ApplyZone3DFog(z)
    if not Scene3D then return end
    local c = z.pColor or { 0.5, 0.5, 0.6 }
    pcall(Scene3D.SetFogColor, Scene3D, c[1] * 0.35, c[2] * 0.35, c[3] * 0.4)
    pcall(Scene3D.SetFogNear, Scene3D, 16)
    pcall(Scene3D.SetFogFar, Scene3D, 36)
    pcall(Scene3D.SetLightAmbientColor, Scene3D, 0.55, 0.55, 0.6)
    pcall(Scene3D.SetLightDiffuseColor, Scene3D, c[1], c[2], c[3])
end

-- ============================================================================
-- POOL HELPERS
-- ============================================================================
local function ClearPools()
    ReleaseAllActors3D()
    for _, e in ipairs(Entities) do e.frame:Hide(); e.active = false end
    for _, l in ipairs(Lanterns) do l.frame:Hide(); l.active = false end
    for _, p in ipairs(Platforms) do p.frame:Hide(); p.active = false end
end

local function AcquireEntity()
    for _, e in ipairs(Entities) do
        if not e.active then
            e.active = true
            e.frame:Show()
            return e
        end
    end
    local f = CreateFrame("Frame", nil, Viewport)
    f:SetFrameLevel(Viewport:GetFrameLevel() + 6)
    local tex = f:CreateTexture(nil, "ARTWORK")
    tex:SetAllPoints()
    local glow = f:CreateTexture(nil, "BACKGROUND")
    glow:SetTexture(TEX_PATH .. "particle_glow.tga")
    glow:SetBlendMode("ADD")
    glow:SetPoint("CENTER")
    glow:SetSize(64, 64)
    glow:Hide()
    local obj = { frame = f, tex = tex, glow = glow, active = true }
    table.insert(Entities, obj)
    return obj
end

local function AcquireLantern()
    for _, l in ipairs(Lanterns) do
        if not l.active then
            l.active = true
            l.frame:Show()
            return l
        end
    end
    local f = CreateFrame("Frame", nil, Viewport)
    f:SetFrameLevel(Viewport:GetFrameLevel() + 5)
    local tex = f:CreateTexture(nil, "ARTWORK")
    tex:SetAllPoints()
    tex:SetTexture(TEX_PATH .. "street_lantern.tga")
    local glow = f:CreateTexture(nil, "OVERLAY")
    glow:SetTexture(TEX_PATH .. "particle_glow.tga")
    glow:SetBlendMode("ADD")
    glow:SetVertexColor(1.0, 0.72, 0.25, 0.75)
    local obj = { frame = f, tex = tex, glow = glow, active = true }
    table.insert(Lanterns, obj)
    return obj
end

local function AcquirePlatform()
    for _, p in ipairs(Platforms) do
        if not p.active then
            p.active = true
            p.frame:Show()
            return p
        end
    end
    local f = CreateFrame("Frame", nil, Viewport)
    f:SetFrameLevel(Viewport:GetFrameLevel() + 5)
    local tex = f:CreateTexture(nil, "ARTWORK")
    tex:SetAllPoints()
    tex:SetTexture(TEX_PATH .. "platform_dalaran.tga")
    local spring = f:CreateTexture(nil, "OVERLAY")
    spring:SetTexture(TEX_PATH .. "particle_glow.tga")
    spring:SetBlendMode("ADD")
    spring:SetVertexColor(0.2, 1.0, 0.65, 0.9)
    spring:SetSize(44, 24)
    spring:SetPoint("TOP", f, "TOP", 0, 8)
    spring:Hide()
    local obj = { frame = f, tex = tex, spring = spring, active = true }
    table.insert(Platforms, obj)
    return obj
end

-- ============================================================================
-- ZONE & BACKGROUND PARTICLES
-- ============================================================================
local function ApplyZone(idx, showBanner)
    State.zoneIdx = idx
    if WarcraftRunnerDB then WarcraftRunnerDB.zoneIdx = idx end
    local z = ZONES[idx] or ZONES[1]
    if Viewport and Viewport.bgTex then
        Viewport.bgTex:SetTexture(z.bg)
    end
    ApplyZone3DFog(z)
    local roadTex = z.road or (TEX_PATH .. "road_cobble.tga")
    for _, s in ipairs(RoadStrips) do
        pcall(s.tex.SetTexture, s.tex, roadTex, "CLAMP", "REPEAT")
        if not s.tex:GetTexture() then s.tex:SetTexture(roadTex) end
        s.tex:SetVertexColor(z.roadTint[1], z.roadTint[2], z.roadTint[3], 1)
    end
    for _, p in ipairs(BgParticles) do
        p.tex:SetVertexColor(z.pColor[1], z.pColor[2], z.pColor[3], p.alpha)
        p.tex:SetSize(z.pSize, z.pSize)
    end
    if HUD.zoneText then
        HUD.zoneText:SetText("|cFFFFD100" .. z.title .. "|r")
    end
    if showBanner and HUD.zoneBanner then
        HUD.zoneBanner:SetText("|cFFFFD100Локация: " .. z.title .. "|r")
        HUD.zoneBanner:SetAlpha(1)
        HUD.zoneBanner:Show()
        State.zoneBannerTimer = 2.6
        SafePlaySound(8959)
    end
end

local function UpdateParticles(dt)
    local z = ZONES[State.zoneIdx] or ZONES[1]
    local t = State.elapsed
    if Viewport and Viewport.bgTex then
        local ox = math.sin(t * 0.5) * 0.015
        local oy = math.cos(t * 0.38) * 0.01
        Viewport.bgTex:SetTexCoord(0.02 + ox, 0.98 + ox, 0.02 + oy, 0.98 + oy)
    end
    for _, p in ipairs(BgParticles) do
        p.x = p.x + (z.pDirX + math.sin(t * 2 + p.phase) * 18) * dt
        p.y = p.y + (z.pDirY + math.cos(t * 1.5 + p.phase) * 10) * dt
        if p.x < -20 then p.x = GAME_W + 15 elseif p.x > GAME_W + 20 then p.x = -15 end
        if p.y < -20 then p.y = GAME_H + 15 elseif p.y > GAME_H + 20 then p.y = -15 end
        local pulse = 0.45 + 0.45 * math.sin(t * 3.2 + p.phase)
        p.tex:SetAlpha(p.alpha * pulse)
        p.tex:ClearAllPoints()
        p.tex:SetPoint("CENTER", Viewport, "BOTTOMLEFT", p.x, p.y)
    end
    if State.zoneBannerTimer > 0 then
        State.zoneBannerTimer = State.zoneBannerTimer - dt
        if State.zoneBannerTimer <= 0 then
            HUD.zoneBanner:Hide()
        elseif State.zoneBannerTimer < 0.6 then
            HUD.zoneBanner:SetAlpha(State.zoneBannerTimer / 0.6)
        end
    end
    if State.shakeTimer > 0 then
        State.shakeTimer = State.shakeTimer - dt
        local amp = (State.shakeTimer / 0.30) * 6
        Viewport:ClearAllPoints()
        Viewport:SetPoint("CENTER", Viewport:GetParent(), "CENTER", math.sin(State.elapsed * 90) * amp, math.cos(State.elapsed * 75) * amp)
        if State.shakeTimer <= 0 then
            Viewport:ClearAllPoints()
            Viewport:SetPoint("CENTER", Viewport:GetParent(), "CENTER", 0, 0)
        end
    end
    if State.flashTimer > 0 and HUD.damageFlash then
        State.flashTimer = State.flashTimer - dt
        HUD.damageFlash:SetAlpha(math.max(0, (State.flashTimer / 0.35) * 0.42))
        if State.flashTimer <= 0 then HUD.damageFlash:Hide() end
    end
    if State.floatTimer > 0 then
        State.floatTimer = State.floatTimer - dt
        if State.floatTimer <= 0 then
            HUD.floatText:Hide()
        elseif State.floatTimer < 0.4 then
            HUD.floatText:SetAlpha(State.floatTimer / 0.4)
        end
    end
end

-- ============================================================================
-- GAME START / OVER / HUD
-- ============================================================================
local function ShowFloat(msg)
    if not HUD.floatText then return end
    HUD.floatText:SetText(msg)
    HUD.floatText:SetAlpha(1)
    HUD.floatText:Show()
    State.floatTimer = 1.4
end

local function UpdateHUD()
    if not HUD.scoreText then return end
    if State.mode == "subway" or State.mode == "whack" then
        HUD.scoreText:SetText(string.format("Дистанция: |cFFFFD100%d м|r", math.floor(State.score)))
        HUD.bestText:SetText(string.format("Рекорд: %d м", math.floor(WarcraftRunnerDB.bestSubway or 0)))
    elseif State.mode == "doodle" then
        HUD.scoreText:SetText(string.format("Высота: |cFFFFD100%d м|r", math.floor(State.score)))
        HUD.bestText:SetText(string.format("Рекорд: %d м", math.floor(WarcraftRunnerDB.bestDoodle or 0)))
    elseif State.mode == "flappy" then
        HUD.scoreText:SetText(string.format("Врата: |cFFFFD100%d|r", math.floor(State.score)))
        HUD.bestText:SetText(string.format("Рекорд: %d", math.floor(WarcraftRunnerDB.bestFlappy or 0)))
    else
        HUD.scoreText:SetText(string.format("Очки: |cFFFFD100%d|r  |  Время: |cFF33EEFF%dс|r", math.floor(State.score), math.ceil(math.max(0, State.whackTime))))
        HUD.bestText:SetText(string.format("Рекорд: %d", math.floor(WarcraftRunnerDB.bestWhack or 0)))
    end
    HUD.goldText:SetText(string.format("Золото: |cFFFFD100%d|r", State.gold))

    if State.mode == "subway" then
        local color = (State.lives >= 3 and "|cFF44FF44") or (State.lives == 2 and "|cFFFFD100") or "|cFFFF4444"
        HUD.livesText:SetText(string.format("Жизни: %s%d/3|r", color, State.lives))
        HUD.livesText:Show()
    else
        HUD.livesText:Hide()
    end

    local buffs = {}
    if State.boostTimer > 0 then
        table.insert(buffs, string.format("|cFF33EEFFУскорение: %.1fс|r", State.boostTimer))
    end
    if State.shieldTimer > 0 then
        table.insert(buffs, string.format("|cFFFFD100Щит: %.1fс|r", State.shieldTimer))
    end
    if #buffs > 0 then
        HUD.boostText:SetText(table.concat(buffs, "  |  "))
        HUD.boostText:Show()
    else
        HUD.boostText:Hide()
    end
    if State.combo > 1 and HUD.comboText then
        HUD.comboText:SetText(string.format("|cFFFF9900Комбо x%d|r", State.combo))
        HUD.comboText:Show()
    elseif HUD.comboText then
        HUD.comboText:Hide()
    end
end

local function TriggerGameOver()
    State.running = false
    State.gameOver = true
    SetHeroAnim(ANIM_DEATH, true)
    SafePlaySound(121)

    local s = math.floor(State.score)
    local isRecord = false
    if State.mode == "subway" then
        if s > (WarcraftRunnerDB.bestSubway or 0) then WarcraftRunnerDB.bestSubway = s; isRecord = true end
    elseif State.mode == "doodle" then
        if s > (WarcraftRunnerDB.bestDoodle or 0) then WarcraftRunnerDB.bestDoodle = s; isRecord = true end
    elseif State.mode == "flappy" then
        if s > (WarcraftRunnerDB.bestFlappy or 0) then WarcraftRunnerDB.bestFlappy = s; isRecord = true end
    else
        if s > (WarcraftRunnerDB.bestWhack or 0) then WarcraftRunnerDB.bestWhack = s; isRecord = true end
    end
    WarcraftRunnerDB.totalGold = (WarcraftRunnerDB.totalGold or 0) + State.gold
    if isRecord then SafePlaySound(618) end

    UpdateHUD()
    if HUD.overlay then
        HUD.overlayTitle:SetText(isRecord and "|cFFFFD100НОВЫЙ РЕКОРД!|r" or "|cFFFF4444ПОРАЖЕНИЕ|r")
        local unitLabel = (State.mode == "subway" and "Дистанция") or (State.mode == "doodle" and "Высота") or (State.mode == "flappy" and "Врата") or "Очки"
        HUD.overlaySub:SetText(string.format("%s: |cFFFFD100%d м|r   |   Золото: |cFFFFD100+%d|r", unitLabel, s, State.gold))
        HUD.overlayBtn:SetText("Играть снова")
        HUD.overlay:Show()
    end
end

local function SetRoadVisible(vis)
    for _, s in ipairs(RoadStrips) do
        if vis then s.tex:Show() else s.tex:Hide() end
    end
end

local function StartGame()
    ClearPools()
    State.running = true
    State.gameOver = false
    State.score = 0
    State.gold = 0
    State.boostTimer = 0
    State.shieldTimer = 0
    State.combo = 1
    State.comboTimer = 0
    State.floatTimer = 0
    State.jumpCount = 0
    State.invulnTimer = 0
    State.lives = 3
    State.nextZoneScore = ZONE_SWITCH_STEP

    if State.mode == "subway" then
        SetRoadVisible(true)
        if USE_3D_SCENE and Scene3D then
            Scene3D:Show(); ModelAnchor:Hide(); UpdateHeroActor3D()
        else
            if Scene3D then Scene3D:Hide() end; ModelAnchor:Show()
        end
        State.lane = 2
        State.laneX = 0
        State.jumpZ = 0
        State.jumpVz = 0
        State.duckTimer = 0
        State.speed = 0.62
        State.spawnTimer = 0.7
        State.lanternTimer = 0.1
        State.desiredFacing = math.pi
        ModelAnchor:SetScale(1.0)
        ApplyModelCameraAndAnim()
        SetHeroAnim(ANIM_RUN, true)
    elseif State.mode == "doodle" then
        SetRoadVisible(false)
        if Scene3D then Scene3D:Hide() end
        ModelAnchor:Show()
        State.djX = 0
        State.djY = 120
        State.djVx = 0
        State.djVy = 540
        State.djMaxY = 0
        State.desiredFacing = math.pi * 0.45
        ModelAnchor:SetScale(0.72)
        ApplyModelCameraAndAnim()
        SetHeroAnim(ANIM_JUMP, true)

        local p0 = AcquirePlatform()
        p0.x = 0; p0.y = 40; p0.ptype = "normal"; p0.dir = 1; p0.broken = false
        p0.tex:SetVertexColor(1, 1, 1, 1); p0.spring:Hide()

        for i = 1, 9 do
            local p = AcquirePlatform()
            p.x = math.random(-190, 190)
            p.y = 40 + i * 52
            p.ptype = (i % 5 == 0) and "moving" or ((i % 7 == 0) and "spring" or "normal")
            p.dir = (math.random(0, 1) == 0) and -1 or 1
            p.broken = false
            if p.ptype == "moving" then
                p.tex:SetVertexColor(0.55, 0.9, 1.0, 1)
                p.spring:Hide()
            elseif p.ptype == "spring" then
                p.tex:SetVertexColor(0.75, 1.0, 0.8, 1)
                p.spring:Show()
            else
                p.tex:SetVertexColor(1, 1, 1, 1)
                p.spring:Hide()
            end
        end
    elseif State.mode == "flappy" then
        SetRoadVisible(false)
        if Scene3D then Scene3D:Hide() end
        ModelAnchor:Show()
        State.flappyY = 220
        State.flappyVy = 260
        State.flappySpawn = 0.6
        State.nextZoneScore = 12
        State.desiredFacing = math.pi * 0.45
        ModelAnchor:SetScale(0.68)
        ApplyModelCameraAndAnim()
        SetHeroAnim(ANIM_JUMP, true)
    else
        SetRoadVisible(false)
        if Scene3D then Scene3D:Hide() end
        ModelAnchor:Hide()
        Viewport.heroShadow:Hide()
        State.whackTime = 45
        State.whackSpawn = 0.25
        State.nextZoneScore = 150
        -- Create 3x3 Dalaran rune pads
        for row = 1, 3 do
            for col = 1, 3 do
                local p = AcquirePlatform()
                p.x = (col - 2) * 145
                p.y = 75 + (3 - row) * 115
                p.ptype = "pad"
                p.tex:SetVertexColor(1, 1, 1, 1)
                p.spring:Hide()
                p.frame:SetSize(116, 38)
                p.frame:ClearAllPoints()
                p.frame:SetPoint("CENTER", Viewport, "BOTTOM", p.x, p.y)
            end
        end
    end

    if C_Timer and C_Timer.After then
        C_Timer.After(0.06, function()
            if State.running and State.mode ~= "whack" then
                SetHeroAnim(State.mode == "subway" and ANIM_RUN or ANIM_JUMP, true)
            end
        end)
    end

    if HUD.overlay then HUD.overlay:Hide() end
    UpdateHUD()
end

local function SwitchMode(mode)
    State.mode = mode
    if WarcraftRunnerDB then WarcraftRunnerDB.mode = mode end
    ClearPools()
    State.running = false
    State.gameOver = false

    if mode == "subway" then
        SetRoadVisible(true)
        if USE_3D_SCENE and Scene3D then
            Scene3D:Show(); ModelAnchor:Hide(); UpdateHeroActor3D()
        else
            if Scene3D then Scene3D:Hide() end; ModelAnchor:Show()
        end
        State.desiredFacing = math.pi
        ModelAnchor:SetScale(1.0)
        ModelAnchor:ClearAllPoints()
        ModelAnchor:SetPoint("BOTTOM", Viewport, "BOTTOM", 0, 10)
        HUD.overlayTitle:SetText("|cFFFFD100ПОГОНЯ ПО АЗЕРОТУ|r")
        HUD.overlaySub:SetText("[A / D] Полоса   |   [Пробел x2] Двойной прыжок   |   [S] Вниз")
    elseif mode == "doodle" then
        SetRoadVisible(false)
        if Scene3D then Scene3D:Hide() end
        ModelAnchor:Show()
        State.desiredFacing = math.pi * 0.45
        ModelAnchor:SetScale(0.72)
        ModelAnchor:ClearAllPoints()
        ModelAnchor:SetPoint("BOTTOM", Viewport, "BOTTOM", 0, 80)
        HUD.overlayTitle:SetText("|cFFFFD100ВОСХОЖДЕНИЕ|r")
        HUD.overlaySub:SetText("[A / D] Полёт влево-вправо со сквозным краем экрана")
    elseif mode == "flappy" then
        SetRoadVisible(false)
        if Scene3D then Scene3D:Hide() end
        ModelAnchor:Show()
        State.desiredFacing = math.pi * 0.45
        ModelAnchor:SetScale(0.68)
        ModelAnchor:ClearAllPoints()
        ModelAnchor:SetPoint("BOTTOM", Viewport, "BOTTOM", -150, 180)
        HUD.overlayTitle:SetText("|cFFFFD100ПОЛЁТ НАД АЗЕРОТОМ|r")
        HUD.overlaySub:SetText("[Пробел / W / ЛКМ] Взмах крыльями сквозь преграды")
    else
        SetRoadVisible(false)
        if Scene3D then Scene3D:Hide() end
        ModelAnchor:Hide()
        Viewport.heroShadow:Hide()
        HUD.overlayTitle:SetText("|cFFFFD100ОХОТА НА МУРЛОКОВ|r")
        HUD.overlaySub:SetText("Кликай по мурлокам, кобольдам и монетам — не трогай овец!")
    end

    ApplyModelCameraAndAnim()
    SetHeroAnim(ANIM_STAND, true)
    HUD.overlayBtn:SetText("Начать игру")
    HUD.overlay:Show()
    RefreshSidebarSelection()
    UpdateHUD()
end

-- ============================================================================
-- SUBWAY SURFERS 3D UPDATE
-- ============================================================================
local function PerspectiveAt(z)
    local p = z * z * 0.65 + z * 0.35
    local y = ROAD_HORIZON_Y - p * (ROAD_HORIZON_Y - ROAD_BOTTOM_Y)
    local roadW = ROAD_TOP_W + p * (ROAD_BOT_W - ROAD_TOP_W)
    local scale = 0.22 + p * 0.88
    return y, roadW, scale
end

local function SpawnSubwayRow()
    local lane = math.random(1, 3)
    local roll = math.random(1, 100)
    if roll <= 36 then
        for k = 0, 2 do
            local e = AcquireEntity()
            e.kind = "coin"; e.lane = lane; e.z = -k * 0.08; e.weave = 0
            e.tex:SetTexture(TEX_PATH .. "coin_gold.tga")
            e.tex:SetVertexColor(1, 1, 1, 1)
            e.glow:SetVertexColor(1, 0.85, 0.2, 0.65)
            e.glow:Show()
        end
    elseif roll <= 44 then
        local e = AcquireEntity()
        e.kind = "potion"; e.lane = lane; e.z = 0; e.weave = 0
        e.tex:SetTexture(TEX_PATH .. "potion_speed.tga")
        e.tex:SetVertexColor(1, 1, 1, 1)
        e.glow:SetVertexColor(0.2, 0.9, 1.0, 0.8)
        e.glow:Show()
    elseif roll <= 52 then
        local e = AcquireEntity()
        e.kind = "shield"; e.lane = lane; e.z = 0; e.weave = 0
        e.tex:SetTexture(TEX_PATH .. "particle_glow.tga")
        e.tex:SetVertexColor(1.0, 0.85, 0.2, 1)
        e.glow:SetVertexColor(1.0, 0.9, 0.3, 0.9)
        e.glow:Show()
    elseif roll <= 65 then
        local e = AcquireEntity()
        e.kind = "murloc"; e.lane = lane; e.z = 0
        e.weave = (math.random(0, 1) == 0) and 0.65 or -0.65
        e.tex:SetTexture(TEX_PATH .. "mob_murloc.tga")
        if USE_3D_SCENE then e.actor3D = AcquireActor3D(397, ANIM_RUN, math.pi, 0.95) end
        e.tex:SetVertexColor(1, 1, 1, 1)
        e.glow:Hide()
    elseif roll <= 78 then
        local e = AcquireEntity()
        e.kind = "kobold"; e.lane = lane; e.z = 0; e.weave = 0
        e.tex:SetTexture(TEX_PATH .. "mob_kobold.tga")
        if USE_3D_SCENE then e.actor3D = AcquireActor3D(10913, ANIM_RUN, math.pi, 0.95) end
        e.tex:SetVertexColor(1, 1, 1, 1)
        e.glow:Hide()
    elseif roll <= 88 then
        local e = AcquireEntity()
        e.kind = "sheep"; e.lane = lane; e.z = 0; e.weave = 0
        e.tex:SetTexture(TEX_PATH .. "mob_sheep.tga")
        if USE_3D_SCENE then e.actor3D = AcquireActor3D(856, ANIM_RUN, math.pi, 1.05) end
        e.tex:SetVertexColor(1, 1, 1, 1)
        e.glow:SetVertexColor(1.0, 0.35, 0.1, 0.7)
        e.glow:Show()
    else
        local e = AcquireEntity()
        e.kind = "gnoll"; e.lane = lane; e.z = 0; e.weave = 0
        e.tex:SetTexture(TEX_PATH .. "mob_kobold.tga")
        e.tex:SetVertexColor(1, 1, 1, 1)
        e.glow:Hide()
        if USE_3D_SCENE then e.actor3D = AcquireActor3D(384, ANIM_RUN, math.pi, 0.90) end
    end
end

local function CheckAutoZoneSwitch()
    if State.score >= State.nextZoneScore then
        State.nextZoneScore = State.nextZoneScore + ZONE_SWITCH_STEP
        local nextIdx = (State.zoneIdx % #ZONES) + 1
        ApplyZone(nextIdx, true)
    end
end

local function UpdateSubway(dt)
    if State.boostTimer > 0 then State.boostTimer = math.max(0, State.boostTimer - dt) end
    if State.shieldTimer > 0 then State.shieldTimer = math.max(0, State.shieldTimer - dt) end
    if State.comboTimer > 0 then
        State.comboTimer = State.comboTimer - dt
        if State.comboTimer <= 0 then State.combo = 1 end
    end
    if State.invulnTimer > 0 then State.invulnTimer = math.max(0, State.invulnTimer - dt) end
    if State.duckTimer > 0 then State.duckTimer = math.max(0, State.duckTimer - dt) end

    local curSpeed = State.speed * (State.boostTimer > 0 and 1.45 or 1.0)
    State.speed = math.min(1.25, State.speed + dt * 0.008)
    State.score = State.score + curSpeed * dt * 28
    CheckAutoZoneSwitch()

    State.roadScroll = (State.roadScroll - curSpeed * dt * 2.4) % 1
    for i, s in ipairs(RoadStrips) do
        local v0 = ((i - 1) / NUM_ROAD_STRIPS + State.roadScroll) % 1
        local v1 = v0 + (1 / NUM_ROAD_STRIPS)
        s.tex:SetTexCoord(0, 1, v0, v1)
    end

    local targetLaneX = State.lane - 2
    State.laneX = State.laneX + (targetLaneX - State.laneX) * math.min(1, dt * 14)
    local lean = math.max(-0.55, math.min(0.55, (State.laneX - targetLaneX) * 0.55))
    local desired = math.pi + lean
    if math.abs(desired - State.desiredFacing) > 0.02 then
        State.desiredFacing = desired
        pcall(PlayerModel.SetFacing, PlayerModel, desired)
    end
    if State.attackTimer > 0 then
        State.attackTimer = State.attackTimer - dt
        if State.attackTimer <= 0 and State.running and State.jumpZ <= 1 then
            SetHeroAnim(State.boostTimer > 0 and ANIM_SPRINT or ANIM_RUN, true)
        end
    end

    if State.jumpZ > 0 or State.jumpVz ~= 0 then
        State.jumpZ = State.jumpZ + State.jumpVz * dt
        State.jumpVz = State.jumpVz - 1350 * dt
        if State.jumpZ <= 0 then
            State.jumpZ = 0
            State.jumpVz = 0
            State.jumpCount = 0
            if State.running then SetHeroAnim(ANIM_RUN, true) end
        end
    end

    local heroScreenX = State.laneX * 135
    local heroScreenY = 10 + State.jumpZ
    if USE_3D_SCENE and HeroActor3D then
        pcall(HeroActor3D.SetPosition, HeroActor3D, 0, -State.laneX * 1.55, State.jumpZ * 0.018)
        pcall(HeroActor3D.SetYaw, HeroActor3D, -lean * 0.45)
    else
        ModelAnchor:ClearAllPoints()
        ModelAnchor:SetPoint("BOTTOM", Viewport, "BOTTOM", heroScreenX, heroScreenY)
    end

    local shadowScale = math.max(0.45, 1.0 - State.jumpZ / 220)
    Viewport.heroShadow:SetSize(96 * shadowScale, 26 * shadowScale)
    Viewport.heroShadow:ClearAllPoints()
    Viewport.heroShadow:SetPoint("CENTER", Viewport, "BOTTOM", heroScreenX, 22)
    Viewport.heroShadow:Show()

    if State.invulnTimer > 0 then
        PlayerModel:SetAlpha(math.floor(State.elapsed * 16) % 2 == 0 and 0.45 or 1.0)
    else
        PlayerModel:SetAlpha(1.0)
    end

    State.lanternTimer = State.lanternTimer - curSpeed * dt
    if State.lanternTimer <= 0 then
        State.lanternTimer = 0.48
        for _, side in ipairs({ -1, 1 }) do
            local l = AcquireLantern()
            l.side = side
            l.z = 0
        end
    end
    for _, l in ipairs(Lanterns) do
        if l.active then
            l.z = l.z + curSpeed * dt
            if l.z > 1.15 then
                l.active = false
                l.frame:Hide()
            else
                local y, roadW, sc = PerspectiveAt(l.z)
                local lx = l.side * (roadW * 0.54)
                l.frame:SetSize(74 * sc, 138 * sc)
                l.frame:ClearAllPoints()
                l.frame:SetPoint("BOTTOM", Viewport, "BOTTOM", lx, y)
                l.glow:SetSize(90 * sc, 90 * sc)
                l.glow:ClearAllPoints()
                l.glow:SetPoint("CENTER", l.frame, "TOP", 0, -24 * sc)
                local flicker = 0.65 + 0.25 * math.sin(State.elapsed * 8 + l.side)
                l.glow:SetAlpha(flicker)
            end
        end
    end

    State.spawnTimer = State.spawnTimer - curSpeed * dt
    if State.spawnTimer <= 0 then
        State.spawnTimer = math.max(0.42, 0.85 - (State.speed - 0.6) * 0.45)
        SpawnSubwayRow()
    end

    for _, e in ipairs(Entities) do
        if e.active then
            e.z = e.z + curSpeed * dt
            if e.z > 1.12 then
                e.active = false
                e.frame:Hide()
                if e.actor3D then e.actor3D.inUse = false; pcall(e.actor3D.obj.Hide, e.actor3D.obj); e.actor3D = nil end
            elseif e.z >= 0 then
                local y, roadW, sc = PerspectiveAt(e.z)
                local ex = (e.lane - 2) * (roadW * 0.30)
                local baseSize = (e.kind == "coin" or e.kind == "potion") and 46 or 78
                local sz = baseSize * sc
                if USE_3D_SCENE and e.actor3D then
                    e.frame:Hide()
                    local worldX = (1.0 - e.z) * 28.0
                    local worldY = -(e.lane - 2) * 1.55
                    pcall(e.actor3D.obj.SetPosition, e.actor3D.obj, worldX, worldY, 0)
                else
                    e.frame:Show()
                    local spinW = (e.kind == "coin") and math.max(sz * 0.25, sz * math.abs(math.cos(State.elapsed * 4.5 + e.z * 6))) or sz
                    e.frame:SetSize(spinW, sz)
                    e.frame:ClearAllPoints()
                    e.frame:SetPoint("BOTTOM", Viewport, "BOTTOM", ex, y + ((e.kind == "coin" or e.kind == "potion") and 16 * sc or 0))
                end
                if e.glow:IsShown() then
                    e.glow:SetSize(sz * 1.45, sz * 1.45)
                end

                if e.weave and e.weave ~= 0 and e.z > 0.25 and e.z < 0.85 then
                    e.lane = math.max(1, math.min(3, e.lane + e.weave * dt))
                end

                if e.kind == "coin" and State.boostTimer > 0 and e.z > 0.50 then
                    e.lane = e.lane + (State.lane - e.lane) * math.min(1, dt * 9)
                end

                if e.z >= 0.82 and e.z <= 0.98 and math.abs((e.lane - 2) - State.laneX) < 0.46 then
                    if e.kind == "coin" then
                        e.active = false; e.frame:Hide(); if e.actor3D then e.actor3D.inUse = false; pcall(e.actor3D.obj.Hide, e.actor3D.obj); e.actor3D = nil end
                        State.combo = math.min(5, State.combo + 1)
                        State.comboTimer = 3.0
                        State.gold = State.gold + State.combo
                        SafePlaySound(120)
                    elseif e.kind == "potion" then
                        e.active = false; e.frame:Hide(); if e.actor3D then e.actor3D.inUse = false; pcall(e.actor3D.obj.Hide, e.actor3D.obj); e.actor3D = nil end
                        State.boostTimer = 5.5
                        if State.jumpZ <= 1 then SetHeroAnim(ANIM_SPRINT, true) end
                        ShowFloat("|cFF33EEFFУСКОРЕНИЕ И МАГНИТ!|r")
                        SafePlaySound(618)
                    elseif e.kind == "shield" then
                        e.active = false; e.frame:Hide(); if e.actor3D then e.actor3D.inUse = false; pcall(e.actor3D.obj.Hide, e.actor3D.obj); e.actor3D = nil end
                        State.shieldTimer = 7.0
                        ShowFloat("|cFFFFD100БОЖЕСТВЕННЫЙ ЩИТ!|r")
                        SafePlaySound(618)
                    elseif State.jumpZ < 44 and State.invulnTimer <= 0 then
                        if State.boostTimer > 0 or State.shieldTimer > 0 then
                            e.active = false; e.frame:Hide(); if e.actor3D then e.actor3D.inUse = false; pcall(e.actor3D.obj.Hide, e.actor3D.obj); e.actor3D = nil end
                            State.attackTimer = 0.42
                            SetHeroAnim(ANIM_ATTACK, true)
                            State.shakeTimer = 0.18
                            if State.shieldTimer > 0 and State.boostTimer <= 0 then
                                State.shieldTimer = 0
                                ShowFloat("|cFFFFD100Щит поглотил удар!|r")
                            elseif e.kind == "sheep" then
                                ShowFloat("|cFFFF6600Бее-БАБАХ!|r")
                            end
                            SafePlaySound(1247)
                        else
                            e.active = false; e.frame:Hide(); if e.actor3D then e.actor3D.inUse = false; pcall(e.actor3D.obj.Hide, e.actor3D.obj); e.actor3D = nil end
                            State.lives = State.lives - 1
                            State.combo = 1
                            State.invulnTimer = 1.4
                            State.shakeTimer = 0.30
                            State.flashTimer = 0.35
                            if HUD.damageFlash then HUD.damageFlash:Show() end
                            if e.kind == "kobold" then
                                ShowFloat("|cFFFF4444Ты не взять свеча!|r")
                            elseif e.kind == "murloc" then
                                ShowFloat("|cFF33FF99Мргллглгл!|r")
                            elseif e.kind == "sheep" then
                                ShowFloat("|cFFFF6600Бее-БАБАХ!|r")
                            end
                            SetHeroAnim(ANIM_HIT, true)
                            SafePlaySound(1247)
                            if C_Timer and C_Timer.After then
                                C_Timer.After(0.35, function()
                                    if State.running and State.jumpZ <= 1 then SetHeroAnim(ANIM_RUN, true) end
                                end)
                            end
                            if State.lives <= 0 then
                                TriggerGameOver()
                                return
                            end
                        end
                    end
                end
            end
        end
    end
end

-- ============================================================================
-- VERTICAL CLIMB UPDATE
-- ============================================================================
local function UpdateDoodle(dt)
    Viewport.heroShadow:Hide()

    local moveDir = 0
    if State.keys["A"] or State.keys["LEFT"] then moveDir = moveDir - 1 end
    if State.keys["D"] or State.keys["RIGHT"] then moveDir = moveDir + 1 end

    if moveDir ~= 0 then
        State.djVx = State.djVx + (moveDir * 320 - State.djVx) * math.min(1, dt * 12)
        local targetFacing = (moveDir > 0) and (math.pi * 0.45) or (-math.pi * 0.45)
        if State.desiredFacing ~= targetFacing then
            State.desiredFacing = targetFacing
            pcall(PlayerModel.SetFacing, PlayerModel, targetFacing)
        end
    else
        State.djVx = State.djVx * math.max(0, 1 - dt * 8)
    end

    State.djX = State.djX + State.djVx * dt
    local halfW = GAME_W * 0.5
    if State.djX < -halfW then State.djX = halfW
    elseif State.djX > halfW then State.djX = -halfW end

    State.djVy = State.djVy - 980 * dt
    State.djY = State.djY + State.djVy * dt

    local camThreshold = 200
    if State.djY > camThreshold then
        local diff = State.djY - camThreshold
        State.djY = camThreshold
        State.djMaxY = State.djMaxY + diff
        State.score = State.djMaxY * 0.12
        CheckAutoZoneSwitch()

        for _, p in ipairs(Platforms) do
            if p.active then
                p.y = p.y - diff
                if p.y < -40 then
                    p.y = p.y + 490
                    p.x = math.random(-200, 200)
                    p.broken = false
                    local r = math.random(1, 100)
                    if r <= 20 then
                        p.ptype = "moving"; p.tex:SetVertexColor(0.55, 0.9, 1.0, 1); p.spring:Hide()
                    elseif r <= 34 then
                        p.ptype = "fragile"; p.tex:SetVertexColor(1.0, 0.65, 0.45, 1); p.spring:Hide()
                    elseif r <= 46 then
                        p.ptype = "spring"; p.tex:SetVertexColor(0.75, 1.0, 0.8, 1); p.spring:Show()
                    else
                        p.ptype = "normal"; p.tex:SetVertexColor(1, 1, 1, 1); p.spring:Hide()
                    end
                    if math.random(1, 100) <= 35 then
                        local c = AcquireEntity()
                        c.kind = "coin"; c.x = p.x; c.y = p.y + 34
                        c.tex:SetTexture(TEX_PATH .. "coin_gold.tga")
                        c.tex:SetVertexColor(1, 1, 1, 1)
                        c.glow:SetVertexColor(1, 0.85, 0.2, 0.65)
                        c.glow:Show()
                    end
                end
            end
        end

        for _, e in ipairs(Entities) do
            if e.active then
                e.y = e.y - diff
                if e.y < -40 then e.active = false; e.frame:Hide(); if e.actor3D then e.actor3D.inUse = false; pcall(e.actor3D.obj.Hide, e.actor3D.obj); e.actor3D = nil end end
            end
        end
    end

    for _, p in ipairs(Platforms) do
        if p.active then
            if p.ptype == "moving" then
                p.x = p.x + p.dir * 95 * dt
                if p.x > 200 then p.x = 200; p.dir = -1
                elseif p.x < -200 then p.x = -200; p.dir = 1 end
            end
            p.frame:SetSize(106, 32)
            p.frame:ClearAllPoints()
            p.frame:SetPoint("CENTER", Viewport, "BOTTOM", p.x, p.y)

            if State.djVy < 0 and not p.broken then
                if math.abs(State.djX - p.x) < 54 and State.djY >= p.y - 6 and State.djY <= p.y + 22 then
                    if p.ptype == "fragile" then
                        p.broken = true; p.tex:SetVertexColor(0.5, 0.3, 0.2, 0.35)
                        State.djVy = 460; SafePlaySound(1247)
                    elseif p.ptype == "spring" then
                        State.djVy = 840; SafePlaySound(618)
                    else
                        State.djVy = 540; SafePlaySound(847)
                    end
                    SetHeroAnim(ANIM_JUMP, true)
                end
            end
        end
    end

    for _, e in ipairs(Entities) do
        if e.active then
            e.frame:SetSize(34, 34)
            e.glow:SetSize(48, 48)
            e.frame:ClearAllPoints()
            e.frame:SetPoint("CENTER", Viewport, "BOTTOM", e.x, e.y)
            if math.abs(State.djX - e.x) < 38 and math.abs(State.djY + 35 - e.y) < 42 then
                e.active = false; e.frame:Hide(); if e.actor3D then e.actor3D.inUse = false; pcall(e.actor3D.obj.Hide, e.actor3D.obj); e.actor3D = nil end
                State.gold = State.gold + 1
                SafePlaySound(120)
            end
        end
    end

    ModelAnchor:ClearAllPoints()
    ModelAnchor:SetPoint("BOTTOM", Viewport, "BOTTOM", State.djX, State.djY - 12)

    if State.djY < -40 then
        TriggerGameOver()
    end
end

-- ============================================================================
-- FLAPPY FLIGHT & WHACK-A-MURLOC
-- ============================================================================
local function UpdateFlappy(dt)
    Viewport.heroShadow:Hide()
    State.flappyVy = State.flappyVy - 860 * dt
    State.flappyY = State.flappyY + State.flappyVy * dt

    ModelAnchor:ClearAllPoints()
    ModelAnchor:SetPoint("BOTTOM", Viewport, "BOTTOM", -150, State.flappyY - 24)

    if State.flappyY < 10 or State.flappyY > GAME_H - 10 then
        TriggerGameOver()
        return
    end

    State.flappySpawn = State.flappySpawn - dt
    if State.flappySpawn <= 0 then
        State.flappySpawn = 1.55
        local gapY = math.random(125, GAME_H - 125)
        local gapH = 148
        -- Bottom arcane rune pillar (clean glowing beam + Dalaran stone cap, no stretched paper)
        local b = AcquireEntity()
        b.kind = "pillar"; b.x = GAME_W * 0.5 + 50; b.y = (gapY - gapH * 0.5) * 0.5
        b.h = gapY - gapH * 0.5; b.scored = false
        b.tex:SetTexture(TEX_PATH .. "platform_dalaran.tga")
        b.tex:SetVertexColor(0.85, 0.75, 1.0, 1)
        b.glow:SetVertexColor(0.45, 0.25, 1.0, 0.75); b.glow:Show()
        -- Top arcane rune pillar
        local t = AcquireEntity()
        t.kind = "pillar"; t.x = GAME_W * 0.5 + 50; t.y = (gapY + gapH * 0.5 + GAME_H) * 0.5
        t.h = GAME_H - (gapY + gapH * 0.5); t.scored = true
        t.tex:SetTexture(TEX_PATH .. "platform_dalaran.tga")
        t.tex:SetVertexColor(0.85, 0.75, 1.0, 1)
        t.glow:SetVertexColor(0.45, 0.25, 1.0, 0.75); t.glow:Show()
        -- Coin in gap
        local c = AcquireEntity()
        c.kind = "coin"; c.x = GAME_W * 0.5 + 50; c.y = gapY; c.h = 36
        c.tex:SetTexture(TEX_PATH .. "coin_gold.tga")
        c.tex:SetVertexColor(1, 1, 1, 1)
        c.glow:SetVertexColor(1, 0.85, 0.2, 0.7); c.glow:Show()
    end

    for _, e in ipairs(Entities) do
        if e.active then
            e.x = e.x - 195 * dt
            if e.x < -GAME_W * 0.5 - 60 then
                e.active = false; e.frame:Hide(); if e.actor3D then e.actor3D.inUse = false; pcall(e.actor3D.obj.Hide, e.actor3D.obj); e.actor3D = nil end
            else
                if e.kind == "pillar" then
                    e.frame:SetSize(88, 30)
                    e.glow:SetSize(36, math.max(28, e.h))
                    e.frame:ClearAllPoints()
                    local capY = (e.scored and (e.y - e.h * 0.5 + 14)) or (e.y + e.h * 0.5 - 14)
                    e.frame:SetPoint("CENTER", Viewport, "BOTTOM", e.x, capY)
                    e.glow:ClearAllPoints()
                    e.glow:SetPoint("CENTER", Viewport, "BOTTOM", e.x, e.y)
                    if not e.scored and e.x < -150 then
                        e.scored = true
                        State.score = State.score + 1
                        if State.score >= State.nextZoneScore then
                            State.nextZoneScore = State.nextZoneScore + 12
                            ApplyZone((State.zoneIdx % #ZONES) + 1, true)
                        end
                    end
                    if math.abs(e.x - (-150)) < 36 and math.abs(State.flappyY - e.y) < (e.h * 0.5 + 16) then
                        TriggerGameOver()
                        return
                    end
                elseif e.kind == "coin" then
                    e.frame:SetSize(36, 36); e.glow:SetSize(52, 52)
                    e.frame:ClearAllPoints()
                    e.frame:SetPoint("CENTER", Viewport, "BOTTOM", e.x, e.y)
                    if math.abs(e.x - (-150)) < 36 and math.abs(State.flappyY - e.y) < 34 then
                        e.active = false; e.frame:Hide(); if e.actor3D then e.actor3D.inUse = false; pcall(e.actor3D.obj.Hide, e.actor3D.obj); e.actor3D = nil end
                        State.gold = State.gold + 1
                        SafePlaySound(120)
                    end
                end
            end
        end
    end
end

local function OnWhackHit(e)
    if not State.running or State.mode ~= "whack" or not e.active then return end
    e.active = false
    e.frame:Hide()
    if e.kind == "sheep" then
        State.lives = State.lives - 1
        State.shakeTimer = 0.28
        State.flashTimer = 0.35
        if HUD.damageFlash then HUD.damageFlash:Show() end
        ShowFloat("|cFFFF4444Бее-БАБАХ! -1 жизнь|r")
        SafePlaySound(1247)
        if State.lives <= 0 then TriggerGameOver() end
    elseif e.kind == "coin" then
        State.gold = State.gold + 3
        State.score = State.score + 20
        ShowFloat("|cFFFFD100+3 Золота!|r")
        SafePlaySound(120)
    elseif e.kind == "kobold" then
        State.score = State.score + 15
        ShowFloat("|cFFFFD100Свеча моя! +15|r")
        SafePlaySound(847)
    else
        State.score = State.score + 10
        ShowFloat("|cFF33FF99Мргллгл! +10|r")
        SafePlaySound(847)
    end
    CheckAutoZoneSwitch()
end

local function UpdateWhack(dt)
    State.whackTime = State.whackTime - dt
    if State.whackTime <= 0 then
        State.whackTime = 0
        TriggerGameOver()
        return
    end

    State.whackSpawn = State.whackSpawn - dt
    if State.whackSpawn <= 0 then
        State.whackSpawn = math.max(0.38, 0.78 - (45 - State.whackTime) * 0.008)
        local row = math.random(1, 3)
        local col = math.random(1, 3)
        local e = AcquireEntity()
        e.x = (col - 2) * 145
        e.y = 95 + (3 - row) * 115
        e.ttl = 1.35
        local r = math.random(1, 100)
        if r <= 42 then
            e.kind = "murloc"; e.tex:SetTexture(TEX_PATH .. "mob_murloc.tga"); e.glow:Hide()
        elseif r <= 68 then
            e.kind = "kobold"; e.tex:SetTexture(TEX_PATH .. "mob_kobold.tga"); e.glow:Hide()
        elseif r <= 85 then
            e.kind = "sheep"; e.tex:SetTexture(TEX_PATH .. "mob_sheep.tga")
            e.glow:SetVertexColor(1, 0.3, 0.1, 0.75); e.glow:Show()
        else
            e.kind = "coin"; e.tex:SetTexture(TEX_PATH .. "coin_gold.tga")
            e.glow:SetVertexColor(1, 0.85, 0.2, 0.75); e.glow:Show()
        end
        e.frame:SetSize(74, 74)
        e.glow:SetSize(96, 96)
        e.frame:ClearAllPoints()
        e.frame:SetPoint("CENTER", Viewport, "BOTTOM", e.x, e.y)
        e.frame:EnableMouse(true)
        e.frame:SetScript("OnMouseDown", function() OnWhackHit(e) end)
    end

    for _, e in ipairs(Entities) do
        if e.active then
            e.ttl = (e.ttl or 1) - dt
            if e.ttl <= 0 then
                e.active = false
                e.frame:Hide()
                if e.actor3D then e.actor3D.inUse = false; pcall(e.actor3D.obj.Hide, e.actor3D.obj); e.actor3D = nil end
            end
        end
    end
end

-- ============================================================================
-- UI CONSTRUCTION (Native Blizzard PortraitFrameTemplate + InsetFrameTemplate)
-- ============================================================================
local function RefreshSidebarSelection()
    if HUD.heroCards then
        for i, c in ipairs(HUD.heroCards) do
            if i == State.heroIdx then
                c.bg:SetColorTexture(0.24, 0.19, 0.08, 0.90)
                c.title:SetTextColor(1, 0.85, 0.25)
                if c.sel then c.sel:Show() end
            else
                c.bg:SetColorTexture(0.08, 0.09, 0.12, 0.65)
                c.title:SetTextColor(0.92, 0.90, 0.85)
                if c.sel then c.sel:Hide() end
            end
        end
    end
    if HUD.modeCards then
        for m, b in pairs(HUD.modeCards) do
            if m == State.mode then
                b:Disable()
            else
                b:Enable()
            end
        end
    end
end

local function CreateUI()
    local SIDEBAR_W = 192
    local TOTAL_W = SIDEBAR_W + GAME_W + 34
    local TOTAL_H = GAME_H + 68

    local ok, f = pcall(CreateFrame, "Frame", "WarcraftRunnerFrame", UIParent, "PortraitFrameTemplate")
    if ok and f then
        MainFrame = f
    else
        MainFrame = CreateStyledFrame("Frame", "WarcraftRunnerFrame", UIParent)
        MainFrame:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
            tile = true, tileSize = 32, edgeSize = 24,
            insets = { left = 6, right = 6, top = 6, bottom = 6 },
        })
    end

    MainFrame:SetSize(TOTAL_W, TOTAL_H)
    MainFrame:SetPoint("CENTER")
    MainFrame:SetMovable(true)
    MainFrame:EnableMouse(true)
    MainFrame:SetClampedToScreen(true)
    MainFrame:SetFrameStrata("HIGH")
    MainFrame:RegisterForDrag("LeftButton")
    MainFrame:SetScript("OnDragStart", MainFrame.StartMoving)
    MainFrame:SetScript("OnDragStop", MainFrame.StopMovingOrSizing)
    MainFrame:Hide()
    table.insert(UISpecialFrames, "WarcraftRunnerFrame")

    if MainFrame.SetTitle then
        MainFrame:SetTitle("Warcraft Runner")
    end
    if MainFrame.SetPortraitToAsset then
        pcall(MainFrame.SetPortraitToAsset, MainFrame, TEX_PATH .. "minimap_icon.tga")
    elseif MainFrame.PortraitContainer and MainFrame.PortraitContainer.portrait then
        MainFrame.PortraitContainer.portrait:SetTexture(TEX_PATH .. "minimap_icon.tga")
    end
    if MainFrame.CloseButton then
        MainFrame.CloseButton:HookScript("OnClick", function()
            State.running = false
        end)
    end

    -- Left Inset Panel (Mode + Heroes + Zone)
    local leftInset = CreateFrame("Frame", nil, MainFrame, InsetFrameTemplate and "InsetFrameTemplate" or nil)
    leftInset:SetSize(SIDEBAR_W, GAME_H + 8)
    leftInset:SetPoint("TOPLEFT", 10, -48)

    local modeHdr = leftInset:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    modeHdr:SetPoint("TOPLEFT", 12, -10)
    modeHdr:SetText("Режим игры")

    HUD.modeCards = {}
    local function MakeModeBtn(key, label, x, y, w)
        local b = CreateFrame("Button", nil, leftInset, "UIPanelButtonTemplate")
        b:SetSize(w, 22)
        b:SetPoint("TOPLEFT", x, y)
        b:SetText(label)
        b:SetScript("OnClick", function() SwitchMode(key); RefreshSidebarSelection() end)
        HUD.modeCards[key] = b
    end
    MakeModeBtn("subway", "Погоня",      10, -26, 82)
    MakeModeBtn("doodle", "Восхождение", 96, -26, 86)
    MakeModeBtn("flappy", "Полёт",       10, -52, 82)
    MakeModeBtn("whack",  "Охота",       96, -52, 86)

    local heroHdr = leftInset:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    heroHdr:SetPoint("TOPLEFT", 12, -82)
    heroHdr:SetText("Персонаж")

    HUD.heroCards = {}
    for i, h in ipairs(HEROES) do
        local c = CreateFrame("Button", nil, leftInset)
        c:SetSize(SIDEBAR_W - 20, 42)
        c:SetPoint("TOPLEFT", 10, -98 - (i - 1) * 44)

        c.bg = c:CreateTexture(nil, "BACKGROUND")
        c.bg:SetAllPoints()
        SetSolidColor(c.bg, 0.08, 0.09, 0.12, 0.65)

        c.sel = c:CreateTexture(nil, "BORDER")
        c.sel:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        c.sel:SetBlendMode("ADD")
        c.sel:SetAllPoints()
        c.sel:Hide()

        local hl = c:CreateTexture(nil, "HIGHLIGHT")
        hl:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        hl:SetBlendMode("ADD")
        hl:SetAlpha(0.35)
        hl:SetAllPoints()

        local ico = c:CreateTexture(nil, "ARTWORK")
        ico:SetSize(30, 30)
        ico:SetPoint("LEFT", 7, 0)
        ico:SetTexture(h.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
        ico:SetTexCoord(0.08, 0.92, 0.08, 0.92)

        c.title = c:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        c.title:SetPoint("TOPLEFT", ico, "TOPRIGHT", 8, -2)
        c.title:SetText(h.name)

        local sub = c:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        sub:SetPoint("TOPLEFT", c.title, "BOTTOMLEFT", 0, -2)
        sub:SetText(h.sub or "")

        c:SetScript("OnClick", function()
            LoadHeroModel(i)
            RefreshSidebarSelection()
        end)
        table.insert(HUD.heroCards, c)
    end

    HUD.zoneText = leftInset:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    HUD.zoneText:SetPoint("BOTTOM", 0, 38)

    local nextZoneBtn = CreateFrame("Button", nil, leftInset, "UIPanelButtonTemplate")
    nextZoneBtn:SetSize(SIDEBAR_W - 24, 22)
    nextZoneBtn:SetPoint("BOTTOM", 0, 10)
    nextZoneBtn:SetText("Сменить локацию")
    nextZoneBtn:SetScript("OnClick", function()
        local nextIdx = (State.zoneIdx % #ZONES) + 1
        ApplyZone(nextIdx, true)
    end)

    -- Right Inset Panel holding Game Viewport cleanly inside its border
    local rightInset = CreateFrame("Frame", nil, MainFrame, InsetFrameTemplate and "InsetFrameTemplate" or nil)
    rightInset:SetSize(GAME_W + 8, GAME_H + 8)
    rightInset:SetPoint("TOPRIGHT", -10, -48)

    Viewport = CreateFrame("Frame", nil, rightInset)
    Viewport:SetSize(GAME_W, GAME_H)
    Viewport:SetPoint("CENTER", 0, 0)
    Viewport:SetClipsChildren(true)

    Viewport.bgTex = Viewport:CreateTexture(nil, "BACKGROUND")
    Viewport.bgTex:SetAllPoints()

    for i = 1, NUM_ROAD_STRIPS do
        local z0 = (i - 1) / NUM_ROAD_STRIPS
        local z1 = i / NUM_ROAD_STRIPS
        local y0, w0 = PerspectiveAt(z0)
        local y1, w1 = PerspectiveAt(z1)
        local tex = Viewport:CreateTexture(nil, "ARTWORK")
        pcall(tex.SetTexture, tex, TEX_PATH .. "road_cobble.tga", "CLAMP", "REPEAT")
        if not tex:GetTexture() then tex:SetTexture(TEX_PATH .. "road_cobble.tga") end
        tex:SetPoint("BOTTOM", Viewport, "BOTTOM", 0, y1)
        local avgW = (w0 + w1) * 0.5
        local stripH = math.max(2, y0 - y1 + 1)
        tex:SetSize(avgW, stripH)
        if tex.SetVertexOffset then
            local dxTop = (w0 - avgW) * 0.5
            local dxBot = (w1 - avgW) * 0.5
            tex:SetVertexOffset(1, -dxTop, 0)
            tex:SetVertexOffset(2,  dxTop, 0)
            tex:SetVertexOffset(3, -dxBot, 0)
            tex:SetVertexOffset(4,  dxBot, 0)
        end
        tex:SetAlpha(math.min(1.0, i / 3.5))
        table.insert(RoadStrips, { tex = tex })
    end

    Viewport.heroShadow = Viewport:CreateTexture(nil, "ARTWORK")
    Viewport.heroShadow:SetTexture(TEX_PATH .. "particle_glow.tga")
    Viewport.heroShadow:SetVertexColor(0, 0, 0, 0.65)
    Viewport.heroShadow:SetSize(96, 26)

    for i = 1, 24 do
        local tex = Viewport:CreateTexture(nil, "OVERLAY")
        tex:SetTexture(TEX_PATH .. "particle_glow.tga")
        tex:SetBlendMode("ADD")
        table.insert(BgParticles, {
            tex = tex,
            x = math.random(0, GAME_W),
            y = math.random(0, GAME_H),
            alpha = 0.35 + math.random() * 0.5,
            phase = math.random() * 6.28,
        })
    end

    -- Shared 3D ModelScene (unified camera, lighting, fog, hero + 3D mob actors)
    local okScene, sc = pcall(CreateFrame, "ModelScene", "WarcraftRunnerModelScene", Viewport)
    if okScene and sc and sc.CreateActor then
        Scene3D = sc
        Scene3D:SetAllPoints()
        Scene3D:SetFrameLevel(Viewport:GetFrameLevel() + 9)
        pcall(Scene3D.SetCameraPosition, Scene3D, -6.8, 0, 2.5)
        pcall(Scene3D.SetCameraOrientationByYawPitchRoll, Scene3D, 0, math.rad(13), 0)
        pcall(Scene3D.SetCameraFieldOfView, Scene3D, math.rad(55))
        local okAct, ha = pcall(Scene3D.CreateActor, Scene3D)
        if okAct and ha then
            HeroActor3D = ha
            USE_3D_SCENE = true
            UpdateHeroActor3D()
        end
    end

    ModelAnchor = CreateFrame("Frame", nil, Viewport)
    ModelAnchor:SetSize(210, 240)
    ModelAnchor:SetFrameLevel(Viewport:GetFrameLevel() + 10)
    ModelAnchor:SetPoint("BOTTOM", Viewport, "BOTTOM", 0, 10)

    PlayerModel = CreateFrame("PlayerModel", "WarcraftRunnerPlayerModel", ModelAnchor)
    PlayerModel:SetAllPoints()
    PlayerModel:SetScript("OnModelLoaded", function()
        State.modelLoaded = true
        ApplyModelCameraAndAnim()
    end)

    -- Dedicated HUDLayer above platforms, entities, and 3D model
    local hudLayer = CreateFrame("Frame", nil, Viewport)
    hudLayer:SetAllPoints()
    hudLayer:SetFrameLevel(Viewport:GetFrameLevel() + 18)

    local hudTopBg = hudLayer:CreateTexture(nil, "BACKGROUND")
    SetSolidColor(hudTopBg, 0.05, 0.06, 0.08, 0.55)
    hudTopBg:SetPoint("TOPLEFT")
    hudTopBg:SetPoint("TOPRIGHT")
    hudTopBg:SetHeight(52)

    HUD.scoreText = hudLayer:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    HUD.scoreText:SetPoint("TOPLEFT", 14, -8)
    HUD.goldText = hudLayer:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    HUD.goldText:SetPoint("TOPLEFT", 14, -30)
    HUD.bestText = hudLayer:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    HUD.bestText:SetPoint("TOPRIGHT", -14, -10)
    HUD.livesText = hudLayer:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    HUD.livesText:SetPoint("TOPRIGHT", -14, -28)
    HUD.boostText = hudLayer:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    HUD.boostText:SetPoint("TOP", 0, -10)
    HUD.boostText:Hide()

    HUD.zoneBanner = hudLayer:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    HUD.zoneBanner:SetPoint("TOP", 0, -64)
    HUD.zoneBanner:Hide()

    HUD.damageFlash = hudLayer:CreateTexture(nil, "BACKGROUND")
    SetSolidColor(HUD.damageFlash, 0.85, 0.05, 0.05, 0.0)
    HUD.damageFlash:SetAllPoints()
    HUD.damageFlash:Hide()

    HUD.floatText = hudLayer:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    HUD.floatText:SetPoint("CENTER", 0, 60)
    HUD.floatText:Hide()

    HUD.comboText = hudLayer:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    HUD.comboText:SetPoint("TOPLEFT", 14, -56)
    HUD.comboText:Hide()

    -- Start / GameOver Overlay
    HUD.overlay = CreateStyledFrame("Frame", nil, Viewport)
    HUD.overlay:SetAllPoints()
    HUD.overlay:SetFrameLevel(Viewport:GetFrameLevel() + 22)
    local ovBg = HUD.overlay:CreateTexture(nil, "BACKGROUND")
    SetSolidColor(ovBg, 0.04, 0.05, 0.07, 0.68)
    ovBg:SetAllPoints()

    HUD.overlayTitle = HUD.overlay:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    HUD.overlayTitle:SetPoint("CENTER", 0, 48)
    HUD.overlaySub = HUD.overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    HUD.overlaySub:SetPoint("CENTER", 0, 12)

    HUD.overlayBtn = CreateFrame("Button", nil, HUD.overlay, "UIPanelButtonTemplate")
    HUD.overlayBtn:SetSize(180, 34)
    HUD.overlayBtn:SetPoint("CENTER", 0, -38)
    HUD.overlayBtn:SetText("Начать игру")
    HUD.overlayBtn:SetScript("OnClick", StartGame)

    MainFrame:EnableKeyboard(true)
    MainFrame:SetScript("OnKeyDown", function(self, key)
        if key == "ESCAPE" then
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
            State.running = false
            self:Hide()
            return
        end
        if not State.running then
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
            return
        end
        if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
        State.keys[key] = true

        if State.mode == "subway" then
            if key == "A" or key == "LEFT" then
                State.lane = math.max(1, State.lane - 1)
            elseif key == "D" or key == "RIGHT" then
                State.lane = math.min(3, State.lane + 1)
            elseif key == "SPACE" or key == "W" or key == "UP" then
                if State.jumpZ <= 1 then
                    State.jumpVz = 530
                    State.jumpCount = 1
                    SetHeroAnim(ANIM_JUMP, true)
                    SafePlaySound(847)
                elseif State.jumpCount < 2 then
                    State.jumpVz = 490
                    State.jumpCount = 2
                    SetHeroAnim(ANIM_JUMP, true)
                    ShowFloat("|cFF33EEFFДвойной прыжок!|r")
                    SafePlaySound(847)
                end
            elseif key == "S" or key == "DOWN" then
                if State.jumpZ > 0 then State.jumpVz = -750 else State.duckTimer = 0.45 end
            end
        elseif State.mode == "flappy" then
            if key == "SPACE" or key == "W" or key == "UP" then
                State.flappyVy = 320
                SetHeroAnim(ANIM_JUMP, true)
                SafePlaySound(847)
            end
        end
    end)

    MainFrame:SetScript("OnKeyUp", function(self, key)
        State.keys[key] = false
    end)

    Viewport:EnableMouse(true)
    Viewport:SetScript("OnMouseDown", function(_, button)
        if not State.running then return end
        if button == "LeftButton" then
            if State.mode == "subway" and State.jumpZ <= 1 then
                State.jumpVz = 530; State.jumpCount = 1; SetHeroAnim(ANIM_JUMP, true); SafePlaySound(847)
            elseif State.mode == "flappy" then
                State.flappyVy = 320; SetHeroAnim(ANIM_JUMP, true); SafePlaySound(847)
            end
        end
    end)

    MainFrame:SetScript("OnUpdate", function(_, dt)
        dt = math.min(dt, 0.05)
        State.elapsed = State.elapsed + dt
        UpdateParticles(dt)
        if State.running then
            if State.mode == "subway" then UpdateSubway(dt) elseif State.mode == "doodle" then UpdateDoodle(dt) elseif State.mode == "flappy" then UpdateFlappy(dt) else UpdateWhack(dt) end
            UpdateHUD()
        end
    end)

    RefreshSidebarSelection()
end

-- ============================================================================
-- MINIMAP BUTTON
-- ============================================================================
local function UpdateMinimapPosition()
    if not MinimapBtn then return end
    local angle = math.rad(WarcraftRunnerDB.minimapAngle or 215)
    local radius = (Minimap:GetWidth() * 0.5) + 8
    MinimapBtn:ClearAllPoints()
    MinimapBtn:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function CreateMinimapButton()
    MinimapBtn = CreateFrame("Button", "WarcraftRunnerMinimapButton", Minimap)
    MinimapBtn:SetSize(32, 32)
    MinimapBtn:SetFrameStrata("MEDIUM")
    MinimapBtn:SetFrameLevel(20)
    MinimapBtn:Show()
    MinimapBtn:EnableMouse(true)
    MinimapBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    MinimapBtn:RegisterForDrag("LeftButton")

    local bg = MinimapBtn:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(22, 22)
    bg:SetPoint("CENTER")
    bg:SetTexture(TEX_PATH .. "minimap_icon.tga")

    local border = MinimapBtn:CreateTexture(nil, "OVERLAY")
    border:SetSize(54, 54)
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

    MinimapBtn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    MinimapBtn:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            cx, cy = cx / scale, cy / scale
            WarcraftRunnerDB.minimapAngle = math.deg(math.atan2(cy - my, cx - mx))
            UpdateMinimapPosition()
        end)
    end)

    MinimapBtn:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
    end)

    MinimapBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("|cFFFFD100Warcraft Runner|r")
        GameTooltip:AddLine("ЛКМ: Открыть мини-игру (/runner)", 1, 1, 1)
        GameTooltip:AddLine(string.format("Погоня по Азероту: |cFFFFD100%d м|r", math.floor(WarcraftRunnerDB.bestSubway or 0)), 0.85, 0.85, 0.85)
        GameTooltip:AddLine(string.format("Восхождение: |cFFFFD100%d м|r", math.floor(WarcraftRunnerDB.bestDoodle or 0)), 0.85, 0.85, 0.85)
        GameTooltip:AddLine(string.format("Всего золота: |cFFFFD100%d|r", WarcraftRunnerDB.totalGold or 0), 0.85, 0.85, 0.85)
        GameTooltip:Show()
    end)
    MinimapBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    MinimapBtn:SetScript("OnClick", function()
        if MainFrame:IsShown() then
            State.running = false
            MainFrame:Hide()
        else
            MainFrame:Show()
            LoadHeroModel(State.heroIdx)
            SwitchMode(State.mode)
        end
    end)

    UpdateMinimapPosition()
end

-- ============================================================================
-- BOOTSTRAP & SLASH COMMANDS
-- ============================================================================
local Loader = CreateFrame("Frame")
Loader:RegisterEvent("PLAYER_LOGIN")
Loader:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGIN" then
        InitDB()
        CreateUI()
        CreateMinimapButton()
        ApplyZone(WarcraftRunnerDB.zoneIdx or 1, false)
        LoadHeroModel(WarcraftRunnerDB.heroIdx or 1)
        SwitchMode(WarcraftRunnerDB.mode or "subway")

        SLASH_WARCRAFTRUNNER1 = "/runner"
        SLASH_WARCRAFTRUNNER2 = "/wowrunner"
        SLASH_WARCRAFTRUNNER3 = "/wcr"
        print("|cFFFFD100[Warcraft Runner]|r загружен! Иконка у миникарты или команда |cFF33EEFF/runner|r")
        SlashCmdList["WARCRAFTRUNNER"] = function()
            if MainFrame:IsShown() then
                State.running = false
                MainFrame:Hide()
            else
                MainFrame:Show()
                LoadHeroModel(State.heroIdx)
                SwitchMode(State.mode)
            end
        end
    end
end)
