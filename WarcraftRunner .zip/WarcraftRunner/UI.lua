local _, WR = ...

local GAME_LIST = {
    { id = "match3",    name = "Три в ряд",  sub = "Юниты WC3",        spell = 133,   icon = WR.TEX .. "wc3_paladin.tga" },
    { id = "survivors", name = "Выживание",  sub = "Арена + таланты",  spell = 1680,  icon = WR.TEX .. "wc3_grunt.tga" },
    { id = "tactics",   name = "Шахматы",    sub = "Альянс vs Орда",   spell = 20217, icon = WR.TEX .. "wc3_warchief.tga" },
    { id = "flappy",    name = "Полёт",      sub = "Флэппи Азерот",    spell = 32242, icon = WR.TEX .. "wc3_gryphon.tga" },
    { id = "mines",     name = "Сапёр",      sub = "Овцы-мины 6x6",    spell = 118,   icon = WR.TEX .. "mob_sheep.tga" },
    { id = "snake",     name = "Змейка",     sub = "Охота за золотом", spell = 19574, icon = WR.TEX .. "wc3_serpent.tga" },
    { id = "solitaire", name = "Пасьянс",    sub = "Косынка таверны",  spell = 12051, icon = WR.TEX .. "card_back_wc3.tga" },
    { id = "durak",     name = "Дурак",      sub = "Карты (ИИ / PvP)", spell = 12051, icon = WR.TEX .. "suit_spade.tga" },
    { id = "tavern",    name = "Уголок",     sub = "Танцы таверны",    spell = 20594, icon = WR.TEX .. "minimap_icon.tga" },
}

local Particles = {}
local GameCards = {}

function WR.ApplyZone(idx)
    WR.State.zoneIdx = idx
    if WarcraftRunnerDB then WarcraftRunnerDB.zoneIdx = idx end
    local z = WR.ZONES[idx] or WR.ZONES[1]
    if WR.BgTex then WR.BgTex:SetTexture(z.bg) end
    if WR.ZoneLabel then WR.ZoneLabel:SetText("|cFFFFD100" .. z.title .. "|r") end
    for _, p in ipairs(Particles) do
        p.tex:SetVertexColor(z.pColor[1], z.pColor[2], z.pColor[3], p.alpha)
    end
end

function WR.SetHUD(leftText, rightText)
    if WR.HUDLeft then WR.HUDLeft:SetText(leftText or "") end
    if WR.HUDRight then WR.HUDRight:SetText(rightText or "") end
end

function WR.RefreshSidebar()
    for _, c in ipairs(GameCards) do
        if c.gameId == WR.State.activeGame then
            WR.SetColor(c.bg, 0.24, 0.19, 0.08, 0.92)
            c.title:SetTextColor(1, 0.85, 0.25)
            c.sel:Show()
        else
            WR.SetColor(c.bg, 0.08, 0.09, 0.12, 0.65)
            c.title:SetTextColor(0.92, 0.90, 0.85)
            c.sel:Hide()
        end
    end
end

function WR.StopActiveGame()
    local cur = WR.Games[WR.State.activeGame]
    if cur and cur.Stop then cur:Stop() end
    WR.State.running = false
end

function WR.SelectGame(id)
    WR.StopActiveGame()
    WR.State.activeGame = id
    if WarcraftRunnerDB then WarcraftRunnerDB.activeGame = id end
    WR.RefreshSidebar()
        local g = WR.Games[id]
    if g and g.ShowIntro then
        g:ShowIntro()
    end
end

function WR.ShowOverlay(title, sub, btnText, onStart)
    if not WR.Overlay then return end
    WR.OverlayTitle:SetText(title)
    WR.OverlaySub:SetText(sub)
    WR.OverlayBtn:SetText(btnText or "Начать игру")
    WR.OverlayBtn:SetScript("OnClick", function()
        WR.Overlay:Hide()
        WR.State.running = true
        if onStart then onStart() end
    end)
    WR.Overlay:Show()
    WR.AnimPop(WR.OverlayBtn, 1.08)
end

local function CreateUI()
    local SIDEBAR_W = 192
    local TOTAL_W = SIDEBAR_W + WR.GAME_W + 34
    local TOTAL_H = WR.GAME_H + 68

    local ok, f = pcall(CreateFrame, "Frame", "WarcraftRunnerFrame", UIParent, "PortraitFrameTemplate")
    if ok and f then
        WR.MainFrame = f
    else
        WR.MainFrame = WR.CreateStyled("Frame", "WarcraftRunnerFrame", UIParent)
        WR.MainFrame:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
            tile = true, tileSize = 32, edgeSize = 24,
            insets = { left = 6, right = 6, top = 6, bottom = 6 },
        })
    end

    local mf = WR.MainFrame
    mf:SetSize(TOTAL_W, TOTAL_H)
    mf:SetPoint("CENTER")
    mf:SetMovable(true)
    mf:EnableMouse(true)
    mf:SetClampedToScreen(true)
    mf:SetFrameStrata("HIGH")
    mf:RegisterForDrag("LeftButton")
    mf:SetScript("OnDragStart", mf.StartMoving)
    mf:SetScript("OnDragStop", mf.StopMovingOrSizing)
    mf:Hide()
    table.insert(UISpecialFrames, "WarcraftRunnerFrame")

    if mf.SetTitle then mf:SetTitle("Таверна Азерота: Мини-игры") end
    if mf.SetPortraitToAsset then
        pcall(mf.SetPortraitToAsset, mf, "Interface\\Icons\\INV_Boots_05")
    elseif mf.PortraitContainer and mf.PortraitContainer.portrait then
        mf.PortraitContainer.portrait:SetTexture("Interface\\Icons\\INV_Boots_05")
    end
    if mf.CloseButton then
        mf.CloseButton:HookScript("OnClick", function() WR.StopActiveGame() end)
    end

    local leftInset = CreateFrame("Frame", nil, mf, "InsetFrameTemplate")
    leftInset:SetSize(SIDEBAR_W, WR.GAME_H + 8)
    leftInset:SetPoint("TOPLEFT", 10, -48)

    local hdr = leftInset:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hdr:SetPoint("TOPLEFT", 12, -10)
    hdr:SetText("Выбор игры")

    for i, info in ipairs(GAME_LIST) do
        local c = CreateFrame("Button", nil, leftInset)
        c:SetSize(SIDEBAR_W - 20, 36)
        c:SetPoint("TOPLEFT", 10, -25 - (i - 1) * 38)
        c.gameId = info.id

        c.bg = c:CreateTexture(nil, "BACKGROUND")
        c.bg:SetAllPoints()
        WR.SetColor(c.bg, 0.08, 0.09, 0.12, 0.65)

        c.sel = c:CreateTexture(nil, "BORDER")
        c.sel:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        c.sel:SetBlendMode("ADD")
        c.sel:SetAllPoints()
        c.sel:Hide()

        local hl = c:CreateTexture(nil, "HIGHLIGHT")
        hl:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        hl:SetBlendMode("ADD")
        hl:SetAlpha(0.35)
        hl:SetAllPoints()

        local ico = c:CreateTexture(nil, "ARTWORK")
        ico:SetSize(32, 32)
        ico:SetPoint("LEFT", 8, 0)
        ico:SetTexture(info.spell and WR.GetSpellIcon(info.spell, info.icon) or info.icon)
        ico:SetTexCoord(0.07, 0.93, 0.07, 0.93)

        c.title = c:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        c.title:SetPoint("TOPLEFT", ico, "TOPRIGHT", 8, -3)
        c.title:SetText(info.name)

        local sub = c:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        sub:SetPoint("TOPLEFT", c.title, "BOTTOMLEFT", 0, -2)
        sub:SetText(info.sub)

        c:SetScript("OnClick", function()
            WR.PlaySound(847)
            WR.SelectGame(info.id)
        end)
        table.insert(GameCards, c)
    end

    WR.ZoneLabel = leftInset:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    WR.ZoneLabel:SetPoint("BOTTOM", 0, 38)

    local zoneBtn = CreateFrame("Button", nil, leftInset, "UIPanelButtonTemplate")
    zoneBtn:SetSize(SIDEBAR_W - 24, 22)
    zoneBtn:SetPoint("BOTTOM", 0, 10)
    zoneBtn:SetText("Сменить фон")
    zoneBtn:SetScript("OnClick", function()
        local nxt = (WR.State.zoneIdx % #WR.ZONES) + 1
        WR.ApplyZone(nxt)
    end)

    local rightInset = CreateFrame("Frame", nil, mf, "InsetFrameTemplate")
    rightInset:SetSize(WR.GAME_W + 8, WR.GAME_H + 8)
    rightInset:SetPoint("TOPRIGHT", -10, -48)
    WR.RightInset = rightInset

    local vp = CreateFrame("Frame", nil, rightInset)
    vp:SetSize(WR.GAME_W, WR.GAME_H)
    vp:SetPoint("CENTER")
    vp:SetClipsChildren(true)
    WR.Viewport = vp

    WR.BgTex = vp:CreateTexture(nil, "BACKGROUND")
    WR.BgTex:SetAllPoints()

    local dim = vp:CreateTexture(nil, "BORDER")
    WR.SetColor(dim, 0.02, 0.03, 0.05, 0.45)
    dim:SetAllPoints()

    for i = 1, 18 do
        local tex = vp:CreateTexture(nil, "BORDER")
        tex:SetTexture(WR.TEX .. "particle_glow.tga")
        tex:SetBlendMode("ADD")
        tex:SetSize(9, 9)
        table.insert(Particles, {
            tex = tex,
            x = math.random(0, WR.GAME_W),
            y = math.random(0, WR.GAME_H),
            alpha = 0.25 + math.random() * 0.45,
            phase = math.random() * 6.28,
        })
    end

    -- HUD Layer
    local hud = CreateFrame("Frame", nil, vp)
    hud:SetAllPoints()
    hud:SetFrameLevel(vp:GetFrameLevel() + 20)
    WR.HUDLayer = hud

    local hudBg = hud:CreateTexture(nil, "BACKGROUND")
    WR.SetColor(hudBg, 0.04, 0.05, 0.07, 0.65)
    hudBg:SetPoint("TOPLEFT")
    hudBg:SetPoint("TOPRIGHT")
    hudBg:SetHeight(34)

    WR.HUDLeft = hud:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    WR.HUDLeft:SetPoint("TOPLEFT", 12, -10)
    WR.HUDRight = hud:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    WR.HUDRight:SetPoint("TOPRIGHT", -12, -10)

    WR.DamageTex = hud:CreateTexture(nil, "BACKGROUND")
    WR.SetColor(WR.DamageTex, 0.85, 0.05, 0.05, 0.0)
    WR.DamageTex:SetAllPoints()
    WR.DamageTex:Hide()

    -- Overlay
    local ov = CreateFrame("Frame", nil, vp)
    ov:SetAllPoints()
    ov:SetFrameLevel(vp:GetFrameLevel() + 25)
    local ovBg = ov:CreateTexture(nil, "BACKGROUND")
    WR.SetColor(ovBg, 0.03, 0.04, 0.06, 0.72)
    ovBg:SetAllPoints()
    WR.Overlay = ov

    WR.OverlayTitle = ov:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    WR.OverlayTitle:SetPoint("CENTER", 0, 44)
    WR.OverlaySub = ov:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    WR.OverlaySub:SetPoint("CENTER", 0, 10)
    WR.OverlayBtn = CreateFrame("Button", nil, ov, "UIPanelButtonTemplate")
    WR.OverlayBtn:SetSize(180, 34)
    WR.OverlayBtn:SetPoint("CENTER", 0, -38)

    -- Keyboard forwarding
    mf:EnableKeyboard(true)
    mf:SetScript("OnKeyDown", function(self, key)
        if key == "ESCAPE" then
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
            WR.StopActiveGame()
            self:Hide()
            return
        end
        local g = WR.Games[WR.State.activeGame]
        if WR.State.running and g and g.OnKeyDown then
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
            g:OnKeyDown(key)
        else
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end
    end)
    mf:SetScript("OnKeyUp", function(_, key)
        local g = WR.Games[WR.State.activeGame]
        if g and g.OnKeyUp then g:OnKeyUp(key) end
    end)

    mf:SetScript("OnUpdate", function(_, dt)
        dt = math.min(dt, 0.05)
        WR.State.elapsed = WR.State.elapsed + dt
        local t = WR.State.elapsed
        for _, p in ipairs(Particles) do
            p.y = p.y + 18 * dt
            p.x = p.x + math.sin(t * 1.6 + p.phase) * 14 * dt
            if p.y > WR.GAME_H + 10 then p.y = -10 end
            p.tex:SetAlpha(p.alpha * (0.5 + 0.5 * math.sin(t * 2.5 + p.phase)))
            p.tex:ClearAllPoints()
            p.tex:SetPoint("CENTER", vp, "BOTTOMLEFT", p.x, p.y)
        end
        if WR.State.shakeTimer > 0 then
            WR.State.shakeTimer = WR.State.shakeTimer - dt
            local amp = (WR.State.shakeTimer / 0.25) * 5
            vp:ClearAllPoints()
            vp:SetPoint("CENTER", rightInset, "CENTER", math.sin(t * 95) * amp, math.cos(t * 80) * amp)
            if WR.State.shakeTimer <= 0 then
                vp:ClearAllPoints()
                vp:SetPoint("CENTER", rightInset, "CENTER", 0, 0)
            end
        end
        if WR.State.flashTimer > 0 and WR.DamageTex then
            WR.State.flashTimer = WR.State.flashTimer - dt
            WR.DamageTex:SetAlpha(math.max(0, (WR.State.flashTimer / 0.30) * 0.4))
            if WR.State.flashTimer <= 0 then WR.DamageTex:Hide() end
        end
        if WR.State.running then
            local g = WR.Games[WR.State.activeGame]
            if g and g.OnUpdate then g:OnUpdate(dt) end
        end
    end)

    WR.ApplyZone(WarcraftRunnerDB.zoneIdx or 1)
    WR.SelectGame(WarcraftRunnerDB.activeGame or "match3")
end

function WR.Toggle()
    if not WR.MainFrame then
        CreateUI()
    end
    if WR.MainFrame:IsShown() then
        WR.StopActiveGame()
        WR.MainFrame:Hide()
    else
        WR.MainFrame:Show()
        WR.SelectGame(WR.State.activeGame)
    end
end
