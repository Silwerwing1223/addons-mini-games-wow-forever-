local _, WR = ...

local G = {}
WR.Games.flappy = G

local Root, HeroFrame, HeroModel
local Pillars = {}
local FY, FVy = 220, 0
local SpawnT = 0
local Score = 0
local NextZoneScore = 10

local function ClearPillars()
    for _, p in ipairs(Pillars) do
        p.active = false
        p.cap:Hide()
        p.beam:Hide()
    end
end

local function AcquirePillar()
    for _, p in ipairs(Pillars) do
        if not p.active then
            p.active = true
            p.cap:Show()
            p.beam:Show()
            return p
        end
    end
    local cap = CreateFrame("Frame", nil, Root)
    cap:SetSize(84, 28)
    cap:SetFrameLevel(Root:GetFrameLevel() + 6)
    local cTex = cap:CreateTexture(nil, "ARTWORK")
    cTex:SetAllPoints()
    cTex:SetTexture(WR.TEX .. "platform_dalaran.tga")

    local beam = Root:CreateTexture(nil, "BORDER")
    beam:SetTexture(WR.TEX .. "particle_glow.tga")
    beam:SetBlendMode("ADD")
    beam:SetVertexColor(0.45, 0.25, 1.0, 0.72)

    local obj = { cap = cap, beam = beam, active = true }
    table.insert(Pillars, obj)
    return obj
end

local function EnsureUI()
    if Root then return end
    Root = CreateFrame("Frame", nil, WR.Viewport)
    Root:SetAllPoints()
    Root:SetFrameLevel(WR.Viewport:GetFrameLevel() + 8)
    Root:EnableMouse(true)
    Root:SetScript("OnMouseDown", function()
        if WR.State.running then G:Flap() end
    end)

    HeroFrame = CreateFrame("Frame", nil, Root)
    HeroFrame:SetSize(120, 130)
    HeroFrame:SetFrameLevel(Root:GetFrameLevel() + 12)
    HeroModel = CreateFrame("PlayerModel", nil, HeroFrame)
    HeroModel:SetAllPoints()
    HeroModel:SetScript("OnModelLoaded", function(self)
        pcall(self.SetPortraitZoom, self, 0)
        pcall(self.SetCamDistanceScale, self, 1.55)
        pcall(self.SetPosition, self, 0, 0, -0.05)
        pcall(self.SetFacing, self, math.pi * 0.45)
        pcall(self.SetAnimation, self, 37)
    end)
end

function G:Flap()
    FVy = 325
    pcall(HeroModel.SetAnimation, HeroModel, 37)
end

function G:Start()
    EnsureUI()
    ClearPillars()
    Root:Show()
    FY = 220
    FVy = 260
    SpawnT = 0.6
    Score = 0
    NextZoneScore = 10
    pcall(HeroModel.SetUnit, HeroModel, "player")
    WR.SetHUD("Врата: |cFFFFD1000|r", string.format("Рекорд: %d", WarcraftRunnerDB.bestFlappy or 0))
end

function G:ShowIntro()
    EnsureUI()
    Root:Show()
    WR.SetHUD("Полёт над Азеротом", string.format("Рекорд: %d", WarcraftRunnerDB.bestFlappy or 0))
    WR.ShowOverlay("|cFFFFD100ФЛЭППИ БЁРД: АЗЕРОТ|r", "[Пробел / W / ЛКМ] Взмах сквозь рунические врата", "Взлететь!", function() G:Start() end)
end

function G:Stop()
    ClearPillars()
    if Root then Root:Hide() end
end

function G:OnKeyDown(key)
    if key == "SPACE" or key == "W" or key == "UP" then
        G:Flap()
    end
end

function G:OnUpdate(dt)
    FVy = FVy - 860 * dt
    FY = FY + FVy * dt

    HeroFrame:ClearAllPoints()
    HeroFrame:SetPoint("CENTER", Root, "BOTTOM", -150, FY)

    if FY < 12 or FY > WR.GAME_H - 12 then
        if Score > (WarcraftRunnerDB.bestFlappy or 0) then WarcraftRunnerDB.bestFlappy = Score end
        WR.State.running = false
        WR.DamageFlash()
        WR.PlaySoundFile("herofallen.ogg", 1.0)
        WR.ShowOverlay("|cFFFF4444ПАДЕНИЕ!|r", string.format("Пройдено врат: |cFFFFD100%d|r", Score), "Играть снова", function() G:Start() end)
        return
    end

    SpawnT = SpawnT - dt
    if SpawnT <= 0 then
        SpawnT = 1.55
        local gapY = math.random(125, WR.GAME_H - 125)
        local gapH = 148

        local bot = AcquirePillar()
        bot.x = WR.GAME_W * 0.5 + 50
        bot.h = gapY - gapH * 0.5
        bot.y = bot.h * 0.5
        bot.capY = bot.h - 14
        bot.scored = false

        local top = AcquirePillar()
        top.x = WR.GAME_W * 0.5 + 50
        top.h = WR.GAME_H - (gapY + gapH * 0.5)
        top.y = (gapY + gapH * 0.5 + WR.GAME_H) * 0.5
        top.capY = gapY + gapH * 0.5 + 14
        top.scored = true
    end

    for _, p in ipairs(Pillars) do
        if p.active then
            p.x = p.x - 195 * dt
            if p.x < -WR.GAME_W * 0.5 - 60 then
                p.active = false; p.cap:Hide(); p.beam:Hide()
            else
                p.cap:ClearAllPoints()
                p.cap:SetPoint("CENTER", Root, "BOTTOM", p.x, p.capY)
                p.beam:SetSize(38, math.max(24, p.h))
                p.beam:ClearAllPoints()
                p.beam:SetPoint("CENTER", Root, "BOTTOM", p.x, p.y)

                if not p.scored and p.x < -150 then
                    p.scored = true
                    Score = Score + 1
                    WarcraftRunnerDB.totalGold = (WarcraftRunnerDB.totalGold or 0) + 1
                    WR.PlaySoundFile("complete.ogg", 0.5)
                    WR.FloatText("+1", -150, FY - 180, 1, 0.85, 0.2)
                    if Score >= NextZoneScore then
                        NextZoneScore = NextZoneScore + 10
                        WR.ApplyZone((WR.State.zoneIdx % #WR.ZONES) + 1)
                        WR.PlaySound(8959)
                    end
                    WR.SetHUD(string.format("Врата: |cFFFFD100%d|r", Score), string.format("Рекорд: %d", math.max(Score, WarcraftRunnerDB.bestFlappy or 0)))
                end

                if math.abs(p.x - (-150)) < 36 and math.abs(FY - p.y) < (p.h * 0.5 + 14) then
                    if Score > (WarcraftRunnerDB.bestFlappy or 0) then WarcraftRunnerDB.bestFlappy = Score end
                    WR.State.running = false
                    WR.DamageFlash()
                    WR.PlaySoundFile("herofallen.ogg", 1.0)
                    WR.ShowOverlay("|cFFFF4444СТОЛКНОВЕНИЕ!|r", string.format("Пройдено врат: |cFFFFD100%d|r", Score), "Играть снова", function() G:Start() end)
                    return
                end
            end
        end
    end
end
