local _, WR = ...

local G = {}
WR.Games.snake = G

local COLS = 24
local ROWS = 16
local CELL = 20
local STEP_BASE = 0.14
local STEP_MIN = 0.065

local Root
local GridTex = {}
local Snake = {}
local Dir = { x = 1, y = 0 }
local NextDirs = {}
local Food = { x = 16, y = 8 }
local Score = 0
local StepTimer = 0
local FoodTex, HeadTex
local BodyPool = {}

local function GetHeadTex()
    return WR.TEX .. "wc3_serpent.tga"
end

local function GetBodyTex()
    return WR.GetSpellIcon(1126, "Interface\\Icons\\INV_Misc_MonsterScales_07")
end

local function GetFoodTex()
    return WR.TEX .. "coin_gold.tga"
end

local function KeyToDir(key)
    if key == "W" or key == "UP" then return { x = 0, y = -1 } end
    if key == "S" or key == "DOWN" then return { x = 0, y = 1 } end
    if key == "A" or key == "LEFT" then return { x = -1, y = 0 } end
    if key == "D" or key == "RIGHT" then return { x = 1, y = 0 } end
    return nil
end

local function SpawnFood()
    local free = {}
    local occ = {}
    for _, seg in ipairs(Snake) do
        occ[seg.y .. ":" .. seg.x] = true
    end
    for y = 1, ROWS do
        for x = 1, COLS do
            if not occ[y .. ":" .. x] then
                table.insert(free, { x = x, y = y })
            end
        end
    end
    if #free > 0 then
        local pick = free[math.random(1, #free)]
        Food.x = pick.x
        Food.y = pick.y
    end
end

local function Render()
    for _, bt in ipairs(BodyPool) do bt:Hide() end

    for i, seg in ipairs(Snake) do
        local cell = GridTex[seg.y] and GridTex[seg.y][seg.x]
        if cell then
            if i == 1 then
                HeadTex:ClearAllPoints()
                HeadTex:SetPoint("CENTER", cell, "CENTER", 0, 0)
                HeadTex:Show()
            else
                local bt = BodyPool[i - 1]
                if not bt then
                    bt = HeadTex:GetParent():CreateTexture(nil, "OVERLAY")
                    bt:SetSize(CELL - 2, CELL - 2)
                    bt:SetTexture(GetBodyTex())
                    bt:SetTexCoord(0.08, 0.92, 0.08, 0.92)
                    BodyPool[i - 1] = bt
                end
                local fade = math.max(0.45, 1.0 - (i / (#Snake + 8)) * 0.5)
                bt:SetVertexColor(0.65 * fade, 1.0 * fade, 0.55 * fade)
                bt:ClearAllPoints()
                bt:SetPoint("CENTER", cell, "CENTER", 0, 0)
                bt:Show()
            end
        end
    end

    if FoodTex then
        FoodTex:ClearAllPoints()
        FoodTex:SetPoint("CENTER", GridTex[Food.y][Food.x], "CENTER", 0, 0)
        FoodTex:Show()
    end

    WR.SetHUD(
        string.format("Змейка  |  Золото: |cFFFFD100%d|r", Score),
        string.format("Рекорд: |cFFFFD100%d|r  |  WASD / Стрелки", WarcraftRunnerDB.bestSnake or 0)
    )
end

local function GameOver()
    WR.State.running = false
    WR.DamageFlash()
    WR.PlaySoundFile("herofallen.ogg", 1.0)
    local best = WarcraftRunnerDB.bestSnake or 0
    if Score > best then
        WarcraftRunnerDB.bestSnake = Score
    end
    local reward = math.floor(Score / 2)
    if reward > 0 then
        WarcraftRunnerDB.totalGold = (WarcraftRunnerDB.totalGold or 0) + reward
    end
    WR.ShowOverlay(
        "|cFFFF4444ЗМЕЙ ПОВЕРЖЕН|r",
        string.format("Собрано: %d  |  Рекорд: %d  |  Награда: +%d золота", Score, WarcraftRunnerDB.bestSnake or 0, reward),
        "Играть снова",
        function() G:Start() end
    )
end

local function Step()
    if #NextDirs > 0 then
        local nd = table.remove(NextDirs, 1)
        if not (nd.x == -Dir.x and nd.y == -Dir.y) then
            Dir = nd
        end
    end

    local head = Snake[1]
    local nx = head.x + Dir.x
    local ny = head.y + Dir.y

    if nx < 1 or nx > COLS or ny < 1 or ny > ROWS then
        GameOver()
        return
    end

    local ate = (nx == Food.x and ny == Food.y)
    local checkLen = ate and #Snake or (#Snake - 1)
    for i = 1, checkLen do
        if Snake[i].x == nx and Snake[i].y == ny then
            GameOver()
            return
        end
    end

    table.insert(Snake, 1, { x = nx, y = ny })
    if ate then
        Score = Score + 1
        WR.PlaySoundFile("complete.ogg", 0.4)
        WR.FloatText("+1", (nx - (COLS + 1) * 0.5) * CELL, ((ROWS + 1) * 0.5 - ny) * CELL - 16, 1, 0.85, 0.2)
        SpawnFood()
    else
        table.remove(Snake)
    end
    Render()
end

local function EnsureUI()
    if Root then return end
    Root = CreateFrame("Frame", nil, WR.Viewport)
    Root:SetAllPoints()
    Root:SetFrameLevel(WR.Viewport:GetFrameLevel() + 8)

    local board = WR.CreateStyled("Frame", nil, Root)
    board:SetSize(COLS * CELL + 12, ROWS * CELL + 12)
    board:SetPoint("CENTER", Root, "CENTER", 0, -16)
    if board.SetBackdrop then
        board:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true, tileSize = 16, edgeSize = 14,
            insets = { left = 4, right = 4, top = 4, bottom = 4 },
        })
        board:SetBackdropBorderColor(0.85, 0.68, 0.22, 0.9)
    end

    for y = 1, ROWS do
        GridTex[y] = {}
        for x = 1, COLS do
            local t = board:CreateTexture(nil, "ARTWORK")
            t:SetSize(CELL - 1, CELL - 1)
            t:SetPoint("TOPLEFT", board, "TOPLEFT", 6 + (x - 1) * CELL, -6 - (y - 1) * CELL)
            if (x + y) % 2 == 0 then
                WR.SetColor(t, 0.08, 0.11, 0.09, 0.80)
            else
                WR.SetColor(t, 0.06, 0.08, 0.07, 0.80)
            end
            GridTex[y][x] = t
        end
    end

    HeadTex = board:CreateTexture(nil, "OVERLAY")
    HeadTex:SetSize(CELL, CELL)
    HeadTex:SetTexture(GetHeadTex())
    HeadTex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    HeadTex:SetVertexColor(1, 0.9, 0.45)

    FoodTex = board:CreateTexture(nil, "OVERLAY")
    FoodTex:SetSize(CELL - 1, CELL - 1)
    FoodTex:SetTexture(GetFoodTex())
    FoodTex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
end

function G:OnKeyDown(key)
    local d = KeyToDir(key)
    if not d then return end
    local last = NextDirs[#NextDirs] or Dir
    if (d.x == -last.x and d.y == -last.y) or (d.x == last.x and d.y == last.y) then
        return
    end
    if #NextDirs < 2 then
        table.insert(NextDirs, d)
    end
end

function G:OnUpdate(dt)
    local interval = math.max(STEP_MIN, STEP_BASE - Score * 0.0025)
    StepTimer = StepTimer + dt
    while StepTimer >= interval do
        StepTimer = StepTimer - interval
        Step()
        if not WR.State.running then break end
    end
end

function G:Start()
    EnsureUI()
    Root:Show()
    Snake = {
        { x = 8, y = 8 },
        { x = 7, y = 8 },
        { x = 6, y = 8 },
    }
    Dir = { x = 1, y = 0 }
    NextDirs = {}
    Score = 0
    StepTimer = 0
    SpawnFood()
    Render()
end

function G:ShowIntro()
    EnsureUI()
    Root:Show()
    WR.SetHUD("Змейка Азерота", string.format("Рекорд: %d", WarcraftRunnerDB.bestSnake or 0))
    WR.ShowOverlay("|cFFFFD100ЗМЕЙКА АЗЕРОТА|r", "Собирай золотые монеты, управляя ветрокрылом. Управление: WASD или стрелки.", "Начать охоту", function() G:Start() end)
end

function G:Stop()
    if Root then Root:Hide() end
end
