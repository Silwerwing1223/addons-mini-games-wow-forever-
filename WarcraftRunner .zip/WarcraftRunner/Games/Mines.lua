local _, WR = ...

local G = {}
WR.Games.mines = G

local SIZE = 6
local BOMBS = 6
local CELL = 52
local Root
local Grid = {}
local Tiles = {}
local Revealed = 0
local Flags = 0

local function FloodReveal(r, c)
    if r < 1 or r > SIZE or c < 1 or c > SIZE then return end
    local cell = Grid[r][c]
    if cell.open or cell.flag or cell.bomb then return end
    cell.open = true
    Revealed = Revealed + 1
    local b = Tiles[r][c]
    WR.SetColor(b.bg, 0.08, 0.10, 0.13, 0.88)
    WR.AnimPop(b, 1.12)
    if cell.adj > 0 then
        local colors = { "|cFF33EEFF", "|cFF44FF44", "|cFFFFD100", "|cFFFF6600", "|cFFFF3333" }
        b.txt:SetText((colors[math.min(5, cell.adj)] or "|cFFFFFFFF") .. cell.adj .. "|r")
    else
        for dr = -1, 1 do
            for dc = -1, 1 do
                if dr ~= 0 or dc ~= 0 then FloodReveal(r + dr, c + dc) end
            end
        end
    end
end

local function OnClickTile(r, c, btn)
    if not WR.State.running then return end
    local cell = Grid[r][c]
    local tile = Tiles[r][c]
    if cell.open then return end

    if btn == "RightButton" then
        cell.flag = not cell.flag
        Flags = Flags + (cell.flag and 1 or -1)
        tile.txt:SetText(cell.flag and "|cFFFF4444!|r" or "")
        WR.AnimPop(tile, 1.15)
        WR.PlaySound(847)
        WR.SetHUD(string.format("Сапёр: |cFFFFD100%d / %d|r", Revealed, SIZE * SIZE - BOMBS), string.format("Флаги: %d/%d", Flags, BOMBS))
        return
    end
    if cell.flag then return end

    if cell.bomb then
        WR.SetColor(tile.bg, 0.55, 0.10, 0.10, 0.96)
        tile.ico:SetTexture(WR.TEX .. "mob_sheep.tga")
        tile.ico:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        tile.ico:Show()
        WR.DamageFlash()
        WR.FloatText("БАБАХ!", (c - 3.5) * CELL, (3.5 - r) * CELL, 1, 0.25, 0.2)
        WR.PlaySoundFile("mortar_explode.ogg", 0.5)
        WR.State.running = false
        WR.ShowOverlay("|cFFFF4444ВЗРЫВ!|r", string.format("Открыто клеток: |cFFFFD100%d|r", Revealed), "Играть снова", function() G:Start() end)
        return
    end

    FloodReveal(r, c)
    WR.PlaySound(120)
    local score = Revealed * 10
    if score > (WarcraftRunnerDB.bestMines or 0) then WarcraftRunnerDB.bestMines = score end
    WR.SetHUD(string.format("Сапёр: |cFFFFD100%d / %d|r", Revealed, SIZE * SIZE - BOMBS), string.format("Флаги: %d/%d", Flags, BOMBS))

    if Revealed >= (SIZE * SIZE - BOMBS) then
        WarcraftRunnerDB.totalGold = (WarcraftRunnerDB.totalGold or 0) + 25
        WR.PlaySoundFile("jobdone.ogg", 1.0)
        WR.State.running = false
        WR.ShowOverlay("|cFFFFD100ПОБЕДА!|r", "Все овцы-мины обезврежены! +25 золота", "Играть снова", function() G:Start() end)
    end
end

local function EnsureUI()
    if Root then return end
    Root = CreateFrame("Frame", nil, WR.Viewport)
    Root:SetAllPoints()
    Root:SetFrameLevel(WR.Viewport:GetFrameLevel() + 8)

    for r = 1, SIZE do
        Tiles[r] = {}
        Grid[r] = {}
        for c = 1, SIZE do
            local b = CreateFrame("Button", nil, Root)
            b:SetSize(CELL - 3, CELL - 3)
            b:SetPoint("CENTER", Root, "CENTER", (c - 3.5) * CELL, (3.5 - r) * CELL - 16)
            b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            b.bg = b:CreateTexture(nil, "BACKGROUND")
            b.bg:SetAllPoints()
            b.ico = b:CreateTexture(nil, "ARTWORK")
            b.ico:SetPoint("CENTER")
            b.ico:SetSize(CELL - 12, CELL - 12)
            b.txt = b:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
            b.txt:SetPoint("CENTER")
            local rr, cc = r, c
            b:SetScript("OnClick", function(_, btn) OnClickTile(rr, cc, btn) end)
            Tiles[r][c] = b
        end
    end
end

function G:Start()
    EnsureUI()
    Root:Show()
    Revealed = 0
    Flags = 0
    for r = 1, SIZE do
        for c = 1, SIZE do
            Grid[r][c] = { bomb = false, open = false, flag = false, adj = 0 }
            local b = Tiles[r][c]
            WR.SetColor(b.bg, 0.16, 0.19, 0.25, 0.94)
            b.ico:Hide()
            b.txt:SetText("")
        end
    end
    local placed = 0
    while placed < BOMBS do
        local r, c = math.random(1, SIZE), math.random(1, SIZE)
        if not Grid[r][c].bomb then Grid[r][c].bomb = true; placed = placed + 1 end
    end
    for r = 1, SIZE do
        for c = 1, SIZE do
            if not Grid[r][c].bomb then
                local cnt = 0
                for dr = -1, 1 do
                    for dc = -1, 1 do
                        local nr, nc = r + dr, c + dc
                        if Grid[nr] and Grid[nr][nc] and Grid[nr][nc].bomb then cnt = cnt + 1 end
                    end
                end
                Grid[r][c].adj = cnt
            end
        end
    end
    WR.SetHUD(string.format("Сапёр: |cFFFFD1000 / %d|r", SIZE * SIZE - BOMBS), string.format("Флаги: 0/%d", BOMBS))
end

function G:ShowIntro()
    EnsureUI()
    Root:Show()
    WR.SetHUD("Сапёр Азерота", string.format("Рекорд: %d", WarcraftRunnerDB.bestMines or 0))
    WR.ShowOverlay("|cFFFFD100САПЁР АЗЕРОТА|r", "ЛКМ: открыть клетку  |  ПКМ: флаг (!) на взрывную овцу", "Начать игру", function() G:Start() end)
end

function G:Stop()
    if Root then Root:Hide() end
end
