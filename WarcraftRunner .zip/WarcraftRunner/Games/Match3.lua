local _, WR = ...

local G = {}
WR.Games.match3 = G

local ROWS, COLS = 7, 7
local MATCH_SOUNDS = { "footman_attack.ogg", "knight_attack.ogg", "paladin_attack.ogg", "archmage_attack.ogg", "grunt_attack.ogg", "shaman_attack.ogg", "rifleman_attack.ogg" }
local CELL = 46

local RUNE_SETS = {
    units = {
        { id = 1, name = "Пехотинец", tex = WR.TEX .. "wc3_footman.tga" },
        { id = 2, name = "Паладин",   tex = WR.TEX .. "wc3_paladin.tga" },
        { id = 3, name = "Архимаг",   tex = WR.TEX .. "wc3_archmage.tga" },
        { id = 4, name = "Бугай",     tex = WR.TEX .. "wc3_grunt.tga" },
        { id = 5, name = "Шаман",     tex = WR.TEX .. "wc3_shaman.tga" },
        { id = 6, name = "Вождь",     tex = WR.TEX .. "wc3_warchief.tga" },
    },
    artifacts = {
        { id = 1, name = "Мана",      tex = WR.TEX .. "wc3_potion_blue.tga" },
        { id = 2, name = "Здоровье",  tex = WR.TEX .. "wc3_potion_red.tga" },
        { id = 3, name = "Сапоги",    tex = WR.TEX .. "wc3_boots.tga" },
        { id = 4, name = "Книга",     tex = WR.TEX .. "wc3_tome.tga" },
        { id = 5, name = "Свиток",    tex = WR.TEX .. "wc3_scroll.tga" },
        { id = 6, name = "Кольцо",    tex = WR.TEX .. "wc3_ring.tga" },
    },
    legends = {
        { id = 1, name = "Артас",     tex = WR.TEX .. "wc3_arthas.tga" },
        { id = 2, name = "Иллидан",   tex = WR.TEX .. "wc3_illidan.tga" },
        { id = 3, name = "Кел'Тузад", tex = WR.TEX .. "wc3_kelthuzad.tga" },
        { id = 4, name = "Громмаш",   tex = WR.TEX .. "wc3_grom.tga" },
        { id = 5, name = "Тралл",     tex = WR.TEX .. "wc3_warchief.tga" },
        { id = 6, name = "Самуро",    tex = WR.TEX .. "wc3_blademaster.tga" },
    },
}

local MATCH_SOUNDS = {
    tier1 = { "spell_fire.ogg", "spell_frost.ogg", "combat_metal_bash.ogg" },
    tier2 = { "spell_lightning.ogg", "combat_blade_strike.ogg", "spell_frostnova.ogg" },
    tier3 = { "combat_whirlwind.ogg", "spell_rain_of_fire.ogg", "warcry_hero.ogg" },
}

local BOSSES = {
    { name = "Дробитель",            display = 384,   hp = 140, atk = 14, set = "units",     intro = "boss_hogger_spawn.ogg",   attack = "boss_hogger_attack.ogg" },
    { name = "Вождь мурлоков",       display = 397,   hp = 200, atk = 18, set = "units",     intro = "boss_murloc_spawn.ogg",   attack = "boss_murloc_attack.ogg" },
    { name = "Король кобольдов",     display = 10913, hp = 260, atk = 22, set = "artifacts", intro = "boss_kobold_spawn.ogg",   attack = "boss_kobold_attack.ogg" },
    { name = "Громмаш Адский Крик",  display = 19141, hp = 340, atk = 26, set = "legends",   intro = "boss_grom_spawn.ogg",     attack = "boss_grom_attack.ogg" },
    { name = "Кел'Тузад",            display = 15990, hp = 430, atk = 30, set = "artifacts", intro = "boss_kelthuzad_spawn.ogg",attack = "boss_kelthuzad_attack.ogg" },
    { name = "Иллидан Ярость Бури",  display = 21135, hp = 530, atk = 34, set = "legends",   intro = "boss_illidan_spawn.ogg",  attack = "boss_illidan_attack.ogg" },
    { name = "Король-лич Артас",     display = 28620, hp = 660, atk = 40, set = "legends",   intro = "boss_lichking_spawn.ogg", attack = "boss_lichking_attack.ogg" },
}

local CurrentRunes = RUNE_SETS.units
local Root, BossScene, BossActor, BossModel, BossHPBar, BossHPText, PlayerHPBar, PlayerHPText, TurnText
local Grid = {}
local Cells = {}
local Selected = nil
local Locked = false
local BossIdx = 1
local BossHP, BossMaxHP = 140, 140
local PlayerHP, PlayerMaxHP = 100, 100
local MovesLeft = 3
local Score = 0

local function UpdateBars()
    if BossHPBar then
        BossHPBar:SetMinMaxValues(0, BossMaxHP)
        BossHPBar:SetValue(math.max(0, BossHP))
        BossHPText:SetText(string.format("%s: %d / %d", BOSSES[BossIdx].name, math.max(0, BossHP), BossMaxHP))
    end
    if PlayerHPBar then
        PlayerHPBar:SetMinMaxValues(0, PlayerMaxHP)
        PlayerHPBar:SetValue(math.max(0, PlayerHP))
        PlayerHPText:SetText(string.format("Твоё HP: %d / %d", math.max(0, PlayerHP), PlayerMaxHP))
    end
    if TurnText then
        TurnText:SetText(string.format("До удара босса: |cFFFFD100%d|r ходов", MovesLeft))
    end
    WR.SetHUD(string.format("Счёт: |cFFFFD100%d|r", Score), string.format("Рекорд: %d", WarcraftRunnerDB.bestMatch3 or 0))
end

local function SetBossAnimation(animId)
    if BossActor then
        pcall(BossActor.SetAnimation, BossActor, animId)
    elseif BossModel then
        pcall(BossModel.SetAnimation, BossModel, animId)
    end
end

local function RefreshCells()
    for r = 1, ROWS do
        for c = 1, COLS do
            local btn = Cells[r][c]
            local kind = Grid[r][c]
            local info = CurrentRunes[kind] or CurrentRunes[1]
            btn.ico:SetTexture(info.tex)
            btn.ico:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            if Selected and Selected.r == r and Selected.c == c then
                WR.SetColor(btn.bg, 0.35, 0.28, 0.08, 0.95)
            else
                WR.SetColor(btn.bg, 0.10, 0.12, 0.16, 0.85)
            end
        end
    end
end

local function SpawnBoss(idx)
    BossIdx = ((idx - 1) % #BOSSES) + 1
    local b = BOSSES[BossIdx]
    BossMaxHP = b.hp
    BossHP = b.hp
    MovesLeft = 3
    CurrentRunes = RUNE_SETS[b.set] or RUNE_SETS.units

    if BossActor then
        pcall(BossActor.SetModelByCreatureDisplayID, BossActor, b.display)
        pcall(BossActor.SetYaw, BossActor, math.pi)
        pcall(BossActor.SetPosition, BossActor, 0, 0, 0)
        pcall(BossActor.SetAnimation, BossActor, 0)
    elseif BossModel then
        pcall(BossModel.SetDisplayInfo, BossModel, b.display)
        pcall(BossModel.SetFacing, BossModel, 0)
        pcall(BossModel.SetPosition, BossModel, 0, 0, 0)
        pcall(BossModel.SetAnimation, BossModel, 0)
    end

    if b.intro then
        WR.PlaySoundFile(b.intro, 1.8)
    end

    RefreshCells()
    UpdateBars()
end

local function FindMatches()
    local mark = {}
    for r = 1, ROWS do mark[r] = {} end
    for r = 1, ROWS do
        for c = 1, COLS - 2 do
            local k = Grid[r][c]
            if k > 0 and Grid[r][c+1] == k and Grid[r][c+2] == k then
                mark[r][c] = true; mark[r][c+1] = true; mark[r][c+2] = true
            end
        end
    end
    for c = 1, COLS do
        for r = 1, ROWS - 2 do
            local k = Grid[r][c]
            if k > 0 and Grid[r+1][c] == k and Grid[r+2][c] == k then
                mark[r][c] = true; mark[r+1][c] = true; mark[r+2][c] = true
            end
        end
    end
    local count = 0
    for r = 1, ROWS do
        for c = 1, COLS do
            if mark[r][c] then count = count + 1 end
        end
    end
    return mark, count
end

local function CollapseAndResolve(combo)
    local mark, count = FindMatches()
    if count == 0 then
        Locked = false
        return
    end
    combo = combo or 1
    local dmg = count * 5 * combo
    Score = Score + dmg
    BossHP = BossHP - dmg
    WarcraftRunnerDB.totalGold = (WarcraftRunnerDB.totalGold or 0) + count
    local sndList = (combo <= 1) and MATCH_SOUNDS.tier1 or ((combo == 2) and MATCH_SOUNDS.tier2 or MATCH_SOUNDS.tier3)
    WR.PlaySoundFile(sndList[math.random(1, #sndList)], 0.45)
    WR.FloatText(string.format("-%d%s", dmg, combo > 1 and (" (x" .. combo .. "!)") or ""), 150, 20, 1, 0.85, 0.2)
    SetBossAnimation(8)

    for r = 1, ROWS do
        for c = 1, COLS do
            if mark[r][c] then
                WR.AnimPop(Cells[r][c], 1.25)
                Grid[r][c] = 0
            end
        end
    end

    -- Drop down
    for c = 1, COLS do
        local writeR = ROWS
        for r = ROWS, 1, -1 do
            if Grid[r][c] ~= 0 then
                Grid[writeR][c] = Grid[r][c]
                writeR = writeR - 1
            end
        end
        for r = writeR, 1, -1 do
            Grid[r][c] = math.random(1, #CurrentRunes)
            WR.AnimPop(Cells[r][c], 1.12)
        end
    end

    RefreshCells()

    if BossHP <= 0 then
        WR.PlaySoundFile("complete.ogg", 1.0)
        SetBossAnimation(1)
        WR.FloatText("|cFFFFD100БОСС ПОВЕРЖЕН! +50|r", 0, 50, 1, 0.85, 0.2)
        Score = Score + 50
        PlayerHP = math.min(PlayerMaxHP, PlayerHP + 30)
        if Score > (WarcraftRunnerDB.bestMatch3 or 0) then WarcraftRunnerDB.bestMatch3 = Score end
        C_Timer.After(0.9, function()
            if WR.State.running and WR.State.activeGame == "match3" then
                SpawnBoss(BossIdx + 1)
                CollapseAndResolve(1)
            end
        end)
        return
    end

    UpdateBars()
    C_Timer.After(0.28, function()
        if WR.State.running and WR.State.activeGame == "match3" then
            CollapseAndResolve(combo + 1)
        end
    end)
end

local function OnCellClick(r, c)
    if not WR.State.running or Locked then return end
    if not Selected then
        Selected = { r = r, c = c }
        WR.AnimPop(Cells[r][c], 1.12)
        RefreshCells()
        return
    end
    local sr, sc = Selected.r, Selected.c
    Selected = nil
    if math.abs(sr - r) + math.abs(sc - c) ~= 1 then
        RefreshCells()
        return
    end
    -- Swap
    Grid[sr][sc], Grid[r][c] = Grid[r][c], Grid[sr][sc]
    local _, cnt = FindMatches()
    if cnt == 0 then
        -- Revert invalid swap
        Grid[sr][sc], Grid[r][c] = Grid[r][c], Grid[sr][sc]
        WR.PlaySound(1247)
        WR.Shake(0.12)
        RefreshCells()
        return
    end
    Locked = true
    RefreshCells()
    MovesLeft = MovesLeft - 1
    CollapseAndResolve(1)

    if MovesLeft <= 0 and BossHP > 0 then
        MovesLeft = 3
        local b = BOSSES[BossIdx]
        local atk = b.atk
        PlayerHP = PlayerHP - atk
        SetBossAnimation(16)
        WR.DamageFlash()
        WR.FloatText("-" .. atk .. " HP", -120, -100, 1, 0.25, 0.25)
        WR.PlaySoundFile(b.attack or "boss_attack.ogg", 0.8)
        UpdateBars()
        if PlayerHP <= 0 then
            if Score > (WarcraftRunnerDB.bestMatch3 or 0) then WarcraftRunnerDB.bestMatch3 = Score end
            WR.State.running = false
            WR.PlaySoundFile("herofallen.ogg", 2.0)
            WR.ShowOverlay("|cFFFF4444ПОРАЖЕНИЕ|r", string.format("Итоговый счёт: |cFFFFD100%d|r", Score), "Играть снова", function() G:Start() end)
        end
    end
end

local function EnsureUI()
    if Root then return end
    Root = CreateFrame("Frame", nil, WR.Viewport)
    Root:SetAllPoints()
    Root:SetFrameLevel(WR.Viewport:GetFrameLevel() + 8)

    for r = 1, ROWS do
        Cells[r] = {}
        Grid[r] = {}
        for c = 1, COLS do
            local b = CreateFrame("Button", nil, Root)
            b:SetSize(CELL - 3, CELL - 3)
            b:SetPoint("TOPLEFT", 18 + (c - 1) * CELL, -52 - (r - 1) * CELL)
            b.bg = b:CreateTexture(nil, "BACKGROUND")
            b.bg:SetAllPoints()
            b.ico = b:CreateTexture(nil, "ARTWORK")
            b.ico:SetPoint("CENTER")
            b.ico:SetSize(CELL - 11, CELL - 11)
            local rr, cc = r, c
            b:SetScript("OnClick", function() OnCellClick(rr, cc) end)
            Cells[r][c] = b
            Grid[r][c] = 1
        end
    end

    -- Right side 3D Boss Panel (ModelScene with PlayerModel fallback)
    local ok, sc = pcall(CreateFrame, "ModelScene", nil, Root)
    if ok and sc and sc.CreateActor then
        BossScene = sc
        BossScene:SetSize(210, 230)
        BossScene:SetPoint("TOPRIGHT", -14, -56)
        pcall(BossScene.SetCameraPosition, BossScene, -4.5, 0, 1.3)
        pcall(BossScene.SetCameraOrientationByYawPitchRoll, BossScene, 0, math.rad(6), 0)
        local okA, act = pcall(BossScene.CreateActor, BossScene)
        if okA and act then BossActor = act end
    end

    if not BossActor then
        local okM, pm = pcall(CreateFrame, "PlayerModel", nil, Root)
        if okM and pm then
            BossModel = pm
            BossModel:SetSize(210, 230)
            BossModel:SetPoint("TOPRIGHT", -14, -56)
            pcall(BossModel.SetFacing, BossModel, 0)
        end
    end

    BossHPBar = CreateFrame("StatusBar", nil, Root)
    BossHPBar:SetSize(200, 18)
    BossHPBar:SetPoint("TOPRIGHT", -18, -296)
    BossHPBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    BossHPBar:SetStatusBarColor(0.85, 0.15, 0.15)
    local bBg = BossHPBar:CreateTexture(nil, "BACKGROUND")
    bBg:SetAllPoints(); WR.SetColor(bBg, 0.1, 0.1, 0.1, 0.85)
    BossHPText = BossHPBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    BossHPText:SetPoint("CENTER")

    PlayerHPBar = CreateFrame("StatusBar", nil, Root)
    PlayerHPBar:SetSize(200, 18)
    PlayerHPBar:SetPoint("TOPRIGHT", -18, -324)
    PlayerHPBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    PlayerHPBar:SetStatusBarColor(0.18, 0.78, 0.25)
    local pBg = PlayerHPBar:CreateTexture(nil, "BACKGROUND")
    pBg:SetAllPoints(); WR.SetColor(pBg, 0.1, 0.1, 0.1, 0.85)
    PlayerHPText = PlayerHPBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    PlayerHPText:SetPoint("CENTER")

    TurnText = Root:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    TurnText:SetPoint("TOPRIGHT", -18, -356)
end

function G:Start()
    EnsureUI()
    Root:Show()
    Score = 0
    PlayerHP = PlayerMaxHP
    Selected = nil
    Locked = false
    SpawnBoss(1)

    for r = 1, ROWS do
        for c = 1, COLS do
            local k
            repeat
                k = math.random(1, #CurrentRunes)
            until not ((c >= 3 and Grid[r][c-1] == k and Grid[r][c-2] == k) or (r >= 3 and Grid[r-1][c] == k and Grid[r-2][c] == k))
            Grid[r][c] = k
        end
    end
    RefreshCells()
end

function G:ShowIntro()
    EnsureUI()
    Root:Show()
    WR.SetHUD("Три в ряд: Битва с боссом", string.format("Рекорд: %d", WarcraftRunnerDB.bestMatch3 or 0))
    WR.ShowOverlay("|cFFFFD100ТРИ В РЯД: БОССЫ АЗЕРОТА|r", "Собирай 3+ рун в ряд, чтобы бить 3D-босса и собирать комбо!", "В бой!", function() G:Start() end)
end

function G:Stop()
    if Root then Root:Hide() end
end
