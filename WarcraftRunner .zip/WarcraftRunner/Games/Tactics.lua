local _, WR = ...

local G = {}
WR.Games.tactics = G

local SIZE = 6
local CELL = 52
local PREFIX = "WRCHESS"
local Root
local Board = {}
local Tiles = {}
local Selected = nil
local ValidMoves = {}
local Turn = "player" -- "player" | "ai"
local MovesCount = 0

local NetMode = false
local MyTeam = "player"
local Opponent = nil
local PendingInviteFrom = nil
local NameInput, StatusBtn, ResignBtn, RaceBtn

local RACE_ORDER = { "human", "orc", "nightelf", "undead" }
local RACE_NAMES = {
    human = "Люди",
    orc = "Орки",
    nightelf = "Эльфы",
    undead = "Нежить",
}

local RACES = {
    human = {
        name = "Люди (Альянс)",
        king = {
            name = "Артас",
            hp = 4, atk = 2, range = 1,
            icon = WR.TEX .. "wc3_arthas.tga",
            soundWhat = "paladin_what.ogg",
            soundYes = "paladin_yes.ogg",
            soundAttack = "paladin_attack.ogg",
            soundDeath = "paladin_death.ogg",
            phraseSelect = "За Альянс!",
            phraseAttack = "За Лордерон!",
        },
        mage = {
            name = "Архимаг",
            hp = 2, atk = 3, range = 2,
            icon = WR.TEX .. "wc3_archmage.tga",
            soundWhat = "archmage_what.ogg",
            soundYes = "archmage_yes.ogg",
            soundAttack = "archmage_attack.ogg",
            soundDeath = "archmage_death.ogg",
            phraseSelect = "Чего желаешь?",
            phraseAttack = "Магия сокрушит тебя!",
        },
        knight = {
            name = "Рыцарь",
            hp = 3, atk = 2, range = 2,
            icon = WR.TEX .. "wc3_knight.tga",
            soundWhat = "knight_what.ogg",
            soundYes = "knight_yes.ogg",
            soundAttack = "knight_attack.ogg",
            soundDeath = "knight_death.ogg",
            phraseSelect = "К вашим услугам!",
            phraseAttack = "Вперёд, в бой!",
        },
        archer = {
            name = "Стрелок",
            hp = 2, atk = 2, range = 2,
            icon = WR.TEX .. "wc3_rifleman.tga",
            soundWhat = "rifleman_what.ogg",
            soundYes = "rifleman_yes.ogg",
            soundAttack = "rifleman_attack.ogg",
            soundDeath = "rifleman_death.ogg",
            phraseSelect = "Цель указана?",
            phraseAttack = "Лови пулю!",
        },
        pawn = {
            name = "Пехотинец",
            hp = 2, atk = 1, range = 1,
            icon = WR.TEX .. "wc3_footman.tga",
            soundWhat = "footman_what.ogg",
            soundYes = "footman_yes.ogg",
            soundAttack = "footman_attack.ogg",
            soundDeath = "footman_death.ogg",
            phraseSelect = "Готов к труду и обороне!",
            phraseAttack = "За Альянс!",
        },
    },
    orc = {
        name = "Орки (Орда)",
        king = {
            name = "Тралл",
            hp = 4, atk = 2, range = 1,
            icon = WR.TEX .. "wc3_warchief.tga",
            soundWhat = "warchief_what.ogg",
            soundYes = "warchief_yes.ogg",
            soundAttack = "warchief_attack.ogg",
            soundDeath = "grunt_death.ogg",
            phraseSelect = "Лок-тар огар!",
            phraseAttack = "Сила стихий!",
        },
        mage = {
            name = "Шаман",
            hp = 2, atk = 3, range = 2,
            icon = WR.TEX .. "wc3_shaman.tga",
            soundWhat = "shaman_what.ogg",
            soundYes = "shaman_yes.ogg",
            soundAttack = "shaman_attack.ogg",
            soundDeath = "shaman_death.ogg",
            phraseSelect = "Духи зовут меня.",
            phraseAttack = "Гром и молния!",
        },
        knight = {
            name = "Всадник на волке",
            hp = 3, atk = 2, range = 2,
            icon = WR.TEX .. "wc3_wolfrider.tga",
            soundWhat = "wolfrider_what.ogg",
            soundYes = "wolfrider_yes.ogg",
            soundAttack = "wolfrider_attack.ogg",
            soundDeath = "wolfrider_death.ogg",
            phraseSelect = "Волки голодны!",
            phraseAttack = "Разорвать их!",
        },
        archer = {
            name = "Охотник за головами",
            hp = 2, atk = 2, range = 2,
            icon = WR.TEX .. "wc3_headhunter.tga",
            soundWhat = "headhunter_what.ogg",
            soundYes = "headhunter_yes.ogg",
            soundAttack = "headhunter_attack.ogg",
            soundDeath = "headhunter_death.ogg",
            phraseSelect = "Кого проткнуть?",
            phraseAttack = "Получи копьё!",
        },
        pawn = {
            name = "Бугай",
            hp = 2, atk = 1, range = 1,
            icon = WR.TEX .. "wc3_grunt.tga",
            soundWhat = "grunt_what.ogg",
            soundYes = "grunt_yes.ogg",
            soundAttack = "grunt_attack.ogg",
            soundDeath = "grunt_death.ogg",
            phraseSelect = "Чего надо?",
            phraseAttack = "Кровь и гром!",
        },
    },
    nightelf = {
        name = "Ночные эльфы",
        king = {
            name = "Иллидан",
            hp = 4, atk = 2, range = 1,
            icon = WR.TEX .. "wc3_ne_king.tga",
            soundWhat = "demonhunter_what.ogg",
            soundYes = "demonhunter_yes.ogg",
            soundAttack = "demonhunter_attack.ogg",
            soundDeath = "demonhunter_death.ogg",
            phraseSelect = "Вы не готовы!",
            phraseAttack = "Вкусите пламя!",
        },
        mage = {
            name = "Хранитель рощи",
            hp = 2, atk = 3, range = 2,
            icon = WR.TEX .. "wc3_ne_mage.tga",
            soundWhat = "keeper_what.ogg",
            soundYes = "keeper_yes.ogg",
            soundAttack = "keeper_attack.ogg",
            soundDeath = "keeper_death.ogg",
            phraseSelect = "Лес в опасности?",
            phraseAttack = "Гнев природы!",
        },
        knight = {
            name = "Охотница",
            hp = 3, atk = 2, range = 2,
            icon = WR.TEX .. "wc3_ne_knight.tga",
            soundWhat = "huntress_what.ogg",
            soundYes = "huntress_yes.ogg",
            soundAttack = "huntress_attack.ogg",
            soundDeath = "huntress_death.ogg",
            phraseSelect = "Во имя Элуны!",
            phraseAttack = "Шакрам летит!",
        },
        archer = {
            name = "Лучница",
            hp = 2, atk = 2, range = 2,
            icon = WR.TEX .. "wc3_ne_archer.tga",
            soundWhat = "archer_what.ogg",
            soundYes = "archer_yes.ogg",
            soundAttack = "archer_attack.ogg",
            soundDeath = "archer_death.ogg",
            phraseSelect = "Я на страже.",
            phraseAttack = "Прямо в яблочко!",
        },
        pawn = {
            name = "Дриада",
            hp = 2, atk = 1, range = 1,
            icon = WR.TEX .. "wc3_ne_pawn.tga",
            soundWhat = "dryad_what.ogg",
            soundYes = "dryad_yes.ogg",
            soundAttack = "dryad_attack.ogg",
            soundDeath = "dryad_death.ogg",
            phraseSelect = "Приветствую!",
            phraseAttack = "Я не просто оленёнок!",
        },
    },
    undead = {
        name = "Нежить (Плеть)",
        king = {
            name = "Рыцарь смерти",
            hp = 4, atk = 2, range = 1,
            icon = WR.TEX .. "wc3_ud_king.tga",
            soundWhat = "deathknight_what.ogg",
            soundYes = "deathknight_yes.ogg",
            soundAttack = "deathknight_attack.ogg",
            soundDeath = "deathknight_death.ogg",
            phraseSelect = "Мертвецы ждут...",
            phraseAttack = "Смерть живым!",
        },
        mage = {
            name = "Лич",
            hp = 2, atk = 3, range = 2,
            icon = WR.TEX .. "wc3_ud_mage.tga",
            soundWhat = "lich_what.ogg",
            soundYes = "lich_yes.ogg",
            soundAttack = "lich_attack.ogg",
            soundDeath = "lich_death.ogg",
            phraseSelect = "Хлад могилы вечен.",
            phraseAttack = "Замёрзни навеки!",
        },
        knight = {
            name = "Поганище",
            hp = 3, atk = 2, range = 2,
            icon = WR.TEX .. "wc3_ud_knight.tga",
            soundWhat = "abomination_what.ogg",
            soundYes = "abomination_yes.ogg",
            soundAttack = "abomination_attack.ogg",
            soundDeath = "abomination_death.ogg",
            phraseSelect = "Мы крушить?",
            phraseAttack = "Рвать на куски!",
        },
        archer = {
            name = "Могильщик",
            hp = 2, atk = 2, range = 2,
            icon = WR.TEX .. "wc3_ud_archer.tga",
            soundWhat = "cryptfiend_what.ogg",
            soundYes = "cryptfiend_yes.ogg",
            soundAttack = "cryptfiend_attack.ogg",
            soundDeath = "cryptfiend_death.ogg",
            phraseSelect = "Из глубин тьмы.",
            phraseAttack = "Опутать паутиной!",
        },
        pawn = {
            name = "Вурдалак",
            hp = 2, atk = 1, range = 1,
            icon = WR.TEX .. "wc3_ud_pawn.tga",
            soundWhat = "ghoul_what.ogg",
            soundYes = "ghoul_yes.ogg",
            soundAttack = "ghoul_attack.ogg",
            soundDeath = "ghoul_death.ogg",
            phraseSelect = "Жрать... мясо!",
            phraseAttack = "Свежее мясо!",
        },
    },
}

local PlayerRace = "human"
local AIRace = "orc"

local function GetUnitDef(race, kind)
    local r = RACES[race] or RACES.human
    return r[kind] or r.pawn
end

local function SendNet(msg, target)
    local dest = target or Opponent
    if not dest or dest == "" then return end
    if C_ChatInfo and C_ChatInfo.SendAddonMessage then
        pcall(C_ChatInfo.SendAddonMessage, PREFIX, msg, "WHISPER", dest)
    elseif SendAddonMessage then
        pcall(SendAddonMessage, PREFIX, msg, "WHISPER", dest)
    end
end

local function ShortName(name)
    if not name then return "" end
    return Ambiguate and Ambiguate(name, "short") or name:match("^([^%-]+)") or name
end

local function ToBoardCoords(vr, vc)
    if NetMode and MyTeam == "ai" then
        return (SIZE + 1) - vr, (SIZE + 1) - vc
    end
    return vr, vc
end

local function CalcValid(sr, sc)
    local valid = {}
    local u = Board[sr][sc]
    if not u then return valid end
    local def = GetUnitDef(u.race, u.kind)
    local rng = def.range
    for r = 1, SIZE do
        for c = 1, SIZE do
            local dist = math.max(math.abs(r - sr), math.abs(c - sc))
            if dist >= 1 and dist <= rng then
                local target = Board[r][c]
                if not target or target.team ~= u.team then
                    valid[r .. ":" .. c] = true
                end
            end
        end
    end
    return valid
end

local function RefreshBoard()
    for vr = 1, SIZE do
        for vc = 1, SIZE do
            local r, c = ToBoardCoords(vr, vc)
            local btn = Tiles[vr][vc]
            local u = Board[r][c]
            local isLight = ((r + c) % 2 == 0)
            local key = r .. ":" .. c

            if Selected and Selected.r == r and Selected.c == c then
                WR.SetColor(btn.bg, 0.45, 0.35, 0.10, 0.95)
            elseif ValidMoves[key] then
                if u and u.team ~= Turn then
                    WR.SetColor(btn.bg, 0.55, 0.14, 0.14, 0.92)
                else
                    WR.SetColor(btn.bg, 0.14, 0.42, 0.18, 0.90)
                end
            elseif isLight then
                WR.SetColor(btn.bg, 0.20, 0.22, 0.27, 0.90)
            else
                WR.SetColor(btn.bg, 0.11, 0.12, 0.16, 0.92)
            end

            if u then
                local def = GetUnitDef(u.race, u.kind)
                btn.ico:SetTexture(def.icon)
                btn.ico:SetTexCoord(0.07, 0.93, 0.07, 0.93)
                btn.ico:Show()
                if u.team == MyTeam then
                    btn.ico:SetVertexColor(1, 1, 1)
                    btn.hp:SetText("|cFF44FF44" .. u.hp .. "|r")
                else
                    btn.ico:SetVertexColor(1, 0.78, 0.78)
                    btn.hp:SetText("|cFFFF5555" .. u.hp .. "|r")
                end
                btn.hp:Show()
            else
                btn.ico:Hide()
                btn.hp:Hide()
            end
        end
    end

    local turnText
    if NetMode then
        turnText = (Turn == MyTeam)
            and ("|cFF44FF44Твой ход|r (vs " .. ShortName(Opponent) .. ")")
            or ("|cFFFF5555Ход: " .. ShortName(Opponent) .. "|r")
    else
        turnText = (Turn == "player") and "Ход: |cFF44FF44Твой|r" or "Ход: |cFFFF5555Противник|r"
    end
    WR.SetHUD(turnText, string.format("Ходов: %d  |  Побед: %d", MovesCount, WarcraftRunnerDB.bestTactics or 0))
end

local function CheckVictory()
    local pKing, eKing = false, false
    for r = 1, SIZE do
        for c = 1, SIZE do
            local u = Board[r][c]
            if u and u.kind == "king" then
                if u.team == "player" then pKing = true else eKing = true end
            end
        end
    end
    local winTeam = nil
    if not eKing then winTeam = "player" elseif not pKing then winTeam = "ai" end
    if not winTeam then return false end

    WR.State.running = false
    if winTeam == MyTeam then
        WarcraftRunnerDB.bestTactics = (WarcraftRunnerDB.bestTactics or 0) + 1
        WarcraftRunnerDB.totalGold = (WarcraftRunnerDB.totalGold or 0) + 30
        WR.PlaySoundFile("complete.ogg", 1.0)
        WR.ShowOverlay("|cFFFFD100ПОБЕДА!|r", "Король врага повержен! Награда: +30 золота", "Играть снова", function()
            if NetMode and Opponent then SendNet("REMATCH") end
            G:Start(NetMode, MyTeam, Opponent)
        end)
    else
        WR.PlaySoundFile("herofallen.ogg", 1.0)
        WR.ShowOverlay("|cFFFF4444ПОРАЖЕНИЕ|r", "Твой Король пал в бою.", "Играть снова", function()
            if NetMode and Opponent then SendNet("REMATCH") end
            G:Start(NetMode, MyTeam, Opponent)
        end)
    end
    return true
end

local function ExecuteMove(sr, sc, tr, tc)
    local attacker = Board[sr][sc]
    local target = Board[tr][tc]
    local vr, vc = ToBoardCoords(tr, tc)
    local atkDef = GetUnitDef(attacker.race, attacker.kind)

    if target then
        local dmg = atkDef.atk
        target.hp = target.hp - dmg
        WR.AnimPop(Tiles[vr][vc], 1.25)
        WR.FloatText("-" .. dmg, (vc - 3.5) * CELL, (3.5 - vr) * CELL, 1, 0.3, 0.2)
        if atkDef.soundAttack then
            WR.PlaySoundFile(atkDef.soundAttack, 0.8)
        end
        if atkDef.phraseAttack and attacker.team == MyTeam then
            WR.FloatText(atkDef.phraseAttack, (vc - 3.5) * CELL, (3.5 - vr) * CELL + 22, 1, 0.85, 0.2)
        end

        if target.hp <= 0 then
            local tgtDef = GetUnitDef(target.race, target.kind)
            if tgtDef.soundDeath then
                C_Timer.After(0.2, function() WR.PlaySoundFile(tgtDef.soundDeath, 0.8) end)
            end
            Board[tr][tc] = attacker
            Board[sr][sc] = nil
        end
    else
        Board[tr][tc] = attacker
        Board[sr][sc] = nil
        WR.AnimPop(Tiles[vr][vc], 1.12)
        if atkDef.soundYes then
            WR.PlaySoundFile(atkDef.soundYes, 1.0)
        end
    end
end

local function RunAI()
    if NetMode or not WR.State.running or WR.State.activeGame ~= "tactics" then return end
    local bestMove = nil
    local bestScore = -999
    for r = 1, SIZE do
        for c = 1, SIZE do
            local u = Board[r][c]
            if u and u.team == "ai" then
                local moves = CalcValid(r, c)
                for key in pairs(moves) do
                    local tr, tc = strsplit(":", key)
                    tr, tc = tonumber(tr), tonumber(tc)
                    local target = Board[tr][tc]
                    local sc = tr * 2
                    if target then
                        sc = sc + (target.kind == "king" and 100 or 35)
                    end
                    if sc > bestScore then
                        bestScore = sc
                        bestMove = { sr = r, sc = c, tr = tr, tc = tc }
                    end
                end
            end
        end
    end
    if bestMove then
        ExecuteMove(bestMove.sr, bestMove.sc, bestMove.tr, bestMove.tc)
    end
    Turn = "player"
    RefreshBoard()
    CheckVictory()
end

local function OnTileClick(vr, vc)
    if not WR.State.running or Turn ~= MyTeam then return end
    local r, c = ToBoardCoords(vr, vc)
    local u = Board[r][c]
    if Selected and ValidMoves[r .. ":" .. c] then
        local sr, sc = Selected.r, Selected.c
        ExecuteMove(sr, sc, r, c)
        Selected = nil
        ValidMoves = {}
        MovesCount = MovesCount + 1
        if NetMode then
            SendNet(string.format("MOVE:%d:%d:%d:%d", sr, sc, r, c))
        end
        if CheckVictory() then return end
        Turn = (MyTeam == "player") and "ai" or "player"
        RefreshBoard()
        if not NetMode then
            C_Timer.After(0.45, RunAI)
        end
        return
    end
    if u and u.team == MyTeam then
        Selected = { r = r, c = c }
        ValidMoves = CalcValid(r, c)
        WR.AnimPop(Tiles[vr][vc], 1.1)
        local def = GetUnitDef(u.race, u.kind)
        if def.soundWhat then
            WR.PlaySoundFile(def.soundWhat, 1.2)
        end
        if def.phraseSelect then
            WR.FloatText(def.phraseSelect, (vc - 3.5) * CELL, (3.5 - vr) * CELL + 22, 0.4, 0.9, 1)
        end
    else
        Selected = nil
        ValidMoves = {}
    end
    RefreshBoard()
end

local function UpdateRaceButton()
    if RaceBtn then
        RaceBtn:SetText("Раса: " .. (RACE_NAMES[PlayerRace] or "Люди"))
    end
end

local function CyclePlayerRace()
    local idx = 1
    for i, r in ipairs(RACE_ORDER) do
        if r == PlayerRace then idx = i; break end
    end
    local nextIdx = (idx % #RACE_ORDER) + 1
    PlayerRace = RACE_ORDER[nextIdx]
    if WarcraftRunnerDB then WarcraftRunnerDB.tacticsRace = PlayerRace end
    UpdateRaceButton()
    G:Start(NetMode, MyTeam, Opponent)
end

local function EnsureUI()
    if Root then return end
    Root = CreateFrame("Frame", nil, WR.Viewport)
    Root:SetAllPoints()
    Root:SetFrameLevel(WR.Viewport:GetFrameLevel() + 8)

    for vr = 1, SIZE do
        Tiles[vr] = {}
        Board[vr] = {}
        for vc = 1, SIZE do
            local b = CreateFrame("Button", nil, Root)
            b:SetSize(CELL - 3, CELL - 3)
            b:SetPoint("CENTER", Root, "CENTER", (vc - 3.5) * CELL, (3.5 - vr) * CELL - 4)
            b.bg = b:CreateTexture(nil, "BACKGROUND")
            b.bg:SetAllPoints()
            b.ico = b:CreateTexture(nil, "ARTWORK")
            b.ico:SetPoint("CENTER")
            b.ico:SetSize(CELL - 14, CELL - 14)
            b.hp = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            b.hp:SetPoint("BOTTOMRIGHT", -3, 2)
            local rr, cc = vr, vc
            b:SetScript("OnClick", function() OnTileClick(rr, cc) end)
            Tiles[vr][vc] = b
        end
    end

    -- Compact bottom PvP bar
    local bar = CreateFrame("Frame", nil, Root)
    bar:SetHeight(26)
    bar:SetPoint("BOTTOMLEFT", 12, 8)
    bar:SetPoint("BOTTOMRIGHT", -12, 8)

    NameInput = CreateFrame("EditBox", nil, bar, "InputBoxTemplate")
    NameInput:SetSize(110, 20)
    NameInput:SetPoint("LEFT", 4, 0)
    NameInput:SetAutoFocus(false)
    NameInput:SetMaxLetters(40)
    NameInput:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

    local inviteBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    inviteBtn:SetSize(105, 22)
    inviteBtn:SetPoint("LEFT", NameInput, "RIGHT", 5, 0)
    inviteBtn:SetText("Вызвать (PvP)")
    inviteBtn:SetScript("OnClick", function()
        local target = strtrim(NameInput:GetText() or "")
        if target == "" and UnitExists("target") and UnitIsPlayer("target") then
            local n, realm = UnitName("target")
            target = (realm and realm ~= "") and (n .. "-" .. realm) or n
            NameInput:SetText(target)
        end
        if target == "" then
            WR.FloatText("Выбери игрока или введи ник!", 0, -140, 1, 0.35, 0.35)
            return
        end
        WR.PlaySound(847)
        SendNet("INVITE", target)
        WR.FloatText("Вызов отправлен: " .. ShortName(target), 0, -140, 0.3, 0.9, 1)
    end)

    StatusBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    StatusBtn:SetSize(85, 22)
    StatusBtn:SetPoint("LEFT", inviteBtn, "RIGHT", 5, 0)
    StatusBtn:SetText("Соло (ИИ)")
    StatusBtn:SetScript("OnClick", function()
        WR.PlaySound(847)
        if NetMode and Opponent then
            SendNet("RESIGN")
        end
        G:Start(false, "player", nil)
        if WR.Overlay then WR.Overlay:Hide() end
        WR.State.running = true
    end)

    RaceBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    RaceBtn:SetSize(110, 22)
    RaceBtn:SetPoint("LEFT", StatusBtn, "RIGHT", 5, 0)
    RaceBtn:SetScript("OnClick", function()
        WR.PlaySound(847)
        CyclePlayerRace()
    end)

    ResignBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    ResignBtn:SetSize(80, 22)
    ResignBtn:SetPoint("RIGHT", -4, 0)
    ResignBtn:SetText("Сдаться")
    ResignBtn:SetScript("OnClick", function()
        if not WR.State.running then return end
        WR.PlaySound(121)
        if NetMode and Opponent then
            SendNet("RESIGN")
        end
        WR.State.running = false
        WR.ShowOverlay("|cFFFF4444СДАЧА|r", "Партия завершена.", "Играть снова", function()
            G:Start(false, "player", nil)
        end)
    end)
end

function G:Start(isNet, myTeam, oppName)
    if WarcraftRunnerDB and WarcraftRunnerDB.tacticsRace then
        PlayerRace = WarcraftRunnerDB.tacticsRace
    end
    EnsureUI()
    UpdateRaceButton()
    Root:Show()
    NetMode = isNet and true or false
    MyTeam = myTeam or "player"
    Opponent = oppName
    Selected = nil
    ValidMoves = {}
    Turn = "player"
    MovesCount = 0

    -- Select AI race differing from player
    local otherRaces = {}
    for _, r in ipairs(RACE_ORDER) do
        if r ~= PlayerRace then table.insert(otherRaces, r) end
    end
    AIRace = otherRaces[math.random(1, #otherRaces)]

    for r = 1, SIZE do for c = 1, SIZE do Board[r][c] = nil end end

    local backRow = { "archer", "knight", "king", "mage", "knight", "archer" }
    for c = 1, SIZE do
        local aiKind = backRow[c]
        local aiDef = GetUnitDef(AIRace, aiKind)
        Board[1][c] = { team = "ai", race = AIRace, kind = aiKind, hp = aiDef.hp }

        local aiPawnDef = GetUnitDef(AIRace, "pawn")
        Board[2][c] = { team = "ai", race = AIRace, kind = "pawn", hp = aiPawnDef.hp }

        local pPawnDef = GetUnitDef(PlayerRace, "pawn")
        Board[5][c] = { team = "player", race = PlayerRace, kind = "pawn", hp = pPawnDef.hp }

        local pKind = backRow[c]
        local pDef = GetUnitDef(PlayerRace, pKind)
        Board[6][c] = { team = "player", race = PlayerRace, kind = pKind, hp = pDef.hp }
    end
    WR.State.running = true
    RefreshBoard()
end

function G:ShowIntro()
    EnsureUI()
    UpdateRaceButton()
    Root:Show()
    WR.SetHUD("Шахматы Таверны 6x6", string.format("Побед: %d", WarcraftRunnerDB.bestTactics or 0))
    WR.ShowOverlay("|cFFFFD100ШАХМАТЫ ТАВЕРНЫ 6x6|r", "4 расы Warcraft III. Играй против ИИ или вызови игрока по сети.", "Начать против ИИ", function()
        G:Start(false, "player", nil)
    end)
end

function G:Stop()
    if Root then Root:Hide() end
end

-- Network listener for WRCHESS
local NetFrame = CreateFrame("Frame")
NetFrame:RegisterEvent("PLAYER_LOGIN")
NetFrame:RegisterEvent("CHAT_MSG_ADDON")
NetFrame:SetScript("OnEvent", function(_, event, prefix, msg, channel, sender)
    if event == "PLAYER_LOGIN" then
        if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
            pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX)
        elseif RegisterAddonMessagePrefix then
            pcall(RegisterAddonMessagePrefix, PREFIX)
        end
        return
    end
    if event ~= "CHAT_MSG_ADDON" or prefix ~= PREFIX or not msg then return end
    if ShortName(sender) == UnitName("player") then return end

    if msg == "INVITE" then
        PendingInviteFrom = sender
        print(string.format("|cFFFFD100[Warcraft Runner]|r %s вызывает вас на партию в Шахматы! Откройте /runner -> Шахматы.", ShortName(sender)))
        if not WR.MainFrame or not WR.MainFrame:IsShown() then
            WR.Toggle()
        end
        WR.SelectGame("tactics")
        WR.ShowOverlay(
            "|cFFFFD100ВЫЗОВ НА ШАХМАТЫ!|r",
            string.format("Игрок |cFF33EEFF%s|r приглашает сыграть по сети (вы играете за чёрные фигуры).", ShortName(sender)),
            "Принять вызов",
            function()
                if PendingInviteFrom then
                    SendNet("ACCEPT", PendingInviteFrom)
                    G:Start(true, "ai", PendingInviteFrom)
                    PendingInviteFrom = nil
                end
            end
        )
    elseif msg == "ACCEPT" then
        if not WR.MainFrame or not WR.MainFrame:IsShown() then WR.Toggle() end
        WR.SelectGame("tactics")
        if WR.Overlay then WR.Overlay:Hide() end
        G:Start(true, "player", sender)
        WR.FloatText("Матч начался!", 0, 20, 0.3, 1, 0.3)
    elseif msg == "REMATCH" then
        if NetMode and Opponent and ShortName(Opponent) == ShortName(sender) then
            if WR.Overlay then WR.Overlay:Hide() end
            G:Start(true, MyTeam, Opponent)
        end
    elseif msg == "RESIGN" then
        if NetMode and Opponent and ShortName(Opponent) == ShortName(sender) then
            WR.State.running = false
            WarcraftRunnerDB.bestTactics = (WarcraftRunnerDB.bestTactics or 0) + 1
            WarcraftRunnerDB.totalGold = (WarcraftRunnerDB.totalGold or 0) + 30
            WR.PlaySoundFile("complete.ogg", 1.0)
            WR.ShowOverlay("|cFFFFD100ПОБЕДА!|r", ShortName(sender) .. " сдался. Награда: +30 золота", "Играть снова", function()
                G:Start(false, "player", nil)
            end)
        end
    elseif msg:sub(1, 5) == "MOVE:" then
        if not NetMode or not Opponent or ShortName(Opponent) ~= ShortName(sender) then return end
        local _, sr, sc, tr, tc = strsplit(":", msg)
        sr, sc, tr, tc = tonumber(sr), tonumber(sc), tonumber(tr), tonumber(tc)
        if sr and sc and tr and tc and Board[sr] and Board[sr][sc] then
            ExecuteMove(sr, sc, tr, tc)
            MovesCount = MovesCount + 1
            Turn = MyTeam
            RefreshBoard()
            CheckVictory()
        end
    end
end)
