local _, WR = ...

local G = {}
WR.Games.tavern = G

local Root
local Models = {}
local AnimTimer = 0
local CurrentAnim = 69 -- 69 = EmoteDance
local ZoomLevels = { 0.0, 0.0, 0.0 }
local TavernMusicOn = true

local DANCERS = {
    {
        label = "Ночная эльфийка",
        isElf = true,
        displayId = 5446, -- Naked Night Elf Female
        m2 = "Character\\NightElf\\Female\\NightElfFemale.m2",
        facing = 0.25,
        xOff = -176,
    },
    {
        label = "Суккуб",
        creatureId = 1863,
        displayId = 4162,
        m2 = "Creature\\Succubus\\Succubus.m2",
        facing = 0,
        xOff = 0,
    },
    {
        label = "Ночная эльфийка",
        isElf = true,
        displayId = 5446, -- Naked Night Elf Female
        m2 = "Character\\NightElf\\Female\\NightElfFemale.m2",
        facing = -0.25,
        xOff = 176,
    },
}

local EMOTES = {
    { name = "Танец",    anim = 69, width = 56 },
    { name = "Привет",   anim = 68, width = 60 },
    { name = "Смех",     anim = 70, width = 54 },
    { name = "Поклон",   anim = 66, width = 58 },
    { name = "Хлопки",   anim = 67, width = 60 },
    { name = "Поцелуй",  anim = 74, width = 64 },
}

local function ApplyZoom(idx)
    local m = Models[idx]
    if m and m.SetPosition then
        pcall(m.SetPosition, m, ZoomLevels[idx] or 0.0, 0, 0)
    end
end

local function ChangeZoom(idx, delta)
    ZoomLevels[idx] = math.max(-0.8, math.min(2.2, (ZoomLevels[idx] or 0.0) + delta))
    ApplyZoom(idx)
end

local function ApplyDancerModel(idx)
    local m = Models[idx]
    local cfg = DANCERS[idx]
    if not m or not cfg then return end

    local ok = false
    if cfg.creatureId then
        m._isElf = false
        if m.SetCreature then ok = pcall(m.SetCreature, m, cfg.creatureId) end
        if not ok and m.SetDisplayInfo then ok = pcall(m.SetDisplayInfo, m, cfg.displayId) end
        if not ok and m.SetModel then ok = pcall(m.SetModel, m, cfg.m2) end
    else
        m._isElf = true
        if m.SetDisplayInfo then ok = pcall(m.SetDisplayInfo, m, cfg.displayId or 5446) end
        if not ok and m.SetCustomRace then ok = pcall(m.SetCustomRace, m, 4, 1) end
        if not ok and m.SetModel then ok = pcall(m.SetModel, m, cfg.m2) end
        if m.Undress then pcall(m.Undress, m) end
        C_Timer.After(0.06, function()
            if m and m.Undress then pcall(m.Undress, m) end
        end)
    end

    if m.SetFacing then
        pcall(m.SetFacing, m, cfg.facing or 0)
    elseif m.SetRotation then
        pcall(m.SetRotation, m, cfg.facing or 0)
    end
    ApplyZoom(idx)
    if m.SetAnimation then
        pcall(m.SetAnimation, m, CurrentAnim)
    end
end

local function SetAllAnim(animId)
    CurrentAnim = animId
    for _, m in ipairs(Models) do
        if m.SetAnimation then
            pcall(m.SetAnimation, m, animId)
        end
    end
end

local function PlayTavernMusic()
    if not TavernMusicOn then return end
    local path = "Interface\\AddOns\\WarcraftRunner\\Sounds\\tavern_music.ogg"
    if PlayMusic then
        pcall(PlayMusic, path)
    elseif WR.PlaySoundFile then
        WR.PlaySoundFile("tavern_music.ogg", 0, "Music")
    end
end

local function StopTavernMusic()
    if StopMusic then
        pcall(StopMusic)
    end
end

local MusicBtn

local function EnsureUI()
    if Root then return end
    Root = CreateFrame("Frame", nil, WR.Viewport)
    Root:SetAllPoints()
    Root:SetFrameLevel(WR.Viewport:GetFrameLevel() + 8)

    local stageBg = Root:CreateTexture(nil, "BACKGROUND")
    stageBg:SetPoint("TOPLEFT", 14, -42)
    stageBg:SetPoint("BOTTOMRIGHT", -14, 42)
    WR.SetColor(stageBg, 0.06, 0.04, 0.08, 0.55)

    for i, cfg in ipairs(DANCERS) do
        local idx = i
        local frame = CreateFrame("Frame", nil, Root)
        frame:SetSize(172, 310)
        frame:SetPoint("CENTER", Root, "CENTER", cfg.xOff, -4)

        local m = CreateFrame("DressUpModel", nil, frame)
        if not m then
            m = CreateFrame("PlayerModel", nil, frame)
        end
        m:SetPoint("TOPLEFT", 0, 0)
        m:SetPoint("BOTTOMRIGHT", 0, 26)
        m:EnableMouse(true)
        m:EnableMouseWheel(true)
        m:SetScript("OnMouseWheel", function(_, delta)
            ChangeZoom(idx, delta * 0.25)
        end)
        m:SetScript("OnMouseDown", function(self, btn)
            if btn == "LeftButton" then
                self._dragging = true
                self._lastX = GetCursorPosition()
            end
        end)
        m:SetScript("OnMouseUp", function(self)
            self._dragging = false
        end)
        m:SetScript("OnUpdate", function(self)
            if self._dragging then
                local cx = GetCursorPosition()
                local dx = (cx - (self._lastX or cx)) * 0.015
                self._lastX = cx
                local cur = (self.GetFacing and self:GetFacing()) or 0
                if self.SetFacing then
                    pcall(self.SetFacing, self, cur + dx)
                elseif self.SetRotation then
                    pcall(self.SetRotation, self, cur + dx)
                end
            end
        end)
        m:SetScript("OnModelLoaded", function(self)
            if self._isElf and self.Undress then
                pcall(self.Undress, self)
            end
            if CurrentAnim and self.SetAnimation then
                pcall(self.SetAnimation, self, CurrentAnim)
            end
        end)

        local lbl = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetPoint("BOTTOM", frame, "BOTTOM", -22, 6)
        lbl:SetText("|cFFFFD100" .. cfg.label .. "|r")

        local plusBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
        plusBtn:SetSize(22, 18)
        plusBtn:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -24, 2)
        plusBtn:SetText("+")
        plusBtn:SetScript("OnClick", function() ChangeZoom(idx, 0.3) end)

        local minusBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
        minusBtn:SetSize(22, 18)
        minusBtn:SetPoint("LEFT", plusBtn, "RIGHT", 2, 0)
        minusBtn:SetText("-")
        minusBtn:SetScript("OnClick", function() ChangeZoom(idx, -0.3) end)

        Models[i] = m
    end

    local bar = CreateFrame("Frame", nil, Root)
    bar:SetHeight(26)
    bar:SetPoint("BOTTOMLEFT", 12, 10)
    bar:SetPoint("BOTTOMRIGHT", -12, 10)

    local lastBtn = nil
    for _, em in ipairs(EMOTES) do
        local animId = em.anim
        local btn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
        btn:SetSize(em.width, 22)
        if not lastBtn then
            btn:SetPoint("LEFT", 0, 0)
        else
            btn:SetPoint("LEFT", lastBtn, "RIGHT", 4, 0)
        end
        btn:SetText(em.name)
        btn:SetScript("OnClick", function()
            WR.PlaySound(847)
            SetAllAnim(animId)
        end)
        lastBtn = btn
    end

    MusicBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    MusicBtn:SetSize(96, 22)
    MusicBtn:SetPoint("LEFT", lastBtn, "RIGHT", 6, 0)
    MusicBtn:SetText(TavernMusicOn and "Музыка: Вкл" or "Музыка: Выкл")
    MusicBtn:SetScript("OnClick", function()
        TavernMusicOn = not TavernMusicOn
        if TavernMusicOn then
            PlayTavernMusic()
            MusicBtn:SetText("Музыка: Вкл")
        else
            StopTavernMusic()
            MusicBtn:SetText("Музыка: Выкл")
        end
        WR.PlaySound(847)
    end)

    local resetBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    resetBtn:SetSize(66, 22)
    resetBtn:SetPoint("RIGHT", 0, 0)
    resetBtn:SetText("Сброс")
    resetBtn:SetScript("OnClick", function()
        CurrentAnim = 69
        ZoomLevels = { 0.0, 0.0, 0.0 }
        for i = 1, #DANCERS do
            ApplyDancerModel(i)
        end
        WR.PlaySound(847)
    end)
end

function G:OnUpdate(dt)
    AnimTimer = AnimTimer + dt
    if AnimTimer >= 6.0 then
        AnimTimer = 0
        SetAllAnim(CurrentAnim)
    end
end

function G:Start()
    EnsureUI()
    Root:Show()
    WR.State.running = true
    AnimTimer = 0
    for i = 1, #DANCERS do
        ApplyDancerModel(i)
    end
    PlayTavernMusic()
    WR.SetHUD("Закрытый уголок таверны", "ЛКМ — вращение  |  Колёсико / +- — свой зум")
end

function G:ShowIntro()
    EnsureUI()
    Root:Show()
    if WR.Overlay then WR.Overlay:Hide() end
    G:Start()
end

function G:Stop()
    StopTavernMusic()
    if Root then Root:Hide() end
end
