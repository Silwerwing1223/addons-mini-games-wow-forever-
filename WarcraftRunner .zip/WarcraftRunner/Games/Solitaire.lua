local _, WR = ...

local G = {}
WR.Games.solitaire = G

local CARD_W = 64
local CARD_H = 82
local COL_GAP = 10
local TOP_Y = -44
local TAB_Y = -142
local LEFT_X = 36

local SUITS = {
    { id = "H", sym = "Ч", name = "Черви",  tex = WR.TEX .. "suit_heart.tga",   color = "|cFFFF2222", red = true },
    { id = "D", sym = "Б", name = "Бубны",  tex = WR.TEX .. "suit_diamond.tga", color = "|cFFFF6600", red = true },
    { id = "C", sym = "Т", name = "Трефы",  tex = WR.TEX .. "suit_club.tga",    color = "|cFF2060E0", red = false },
    { id = "S", sym = "П", name = "Пики",   tex = WR.TEX .. "suit_spade.tga",   color = "|cFF151820", red = false },
}
local RANKS = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" }

local Root
local Stock = {}
local Waste = {}
local Foundations = { {}, {}, {}, {} }
local Tableau = { {}, {}, {}, {}, {}, {}, {} }
local Selected = nil -- { zone = "waste"|"tab"|"found", col = n, idx = n }
local MovesCount = 0

local CardPool = {}
local SlotButtons = {}

local function NewDeck()
    local deck = {}
    for s = 1, 4 do
        for r = 1, 13 do
            table.insert(deck, { suit = s, rank = r, up = false })
        end
    end
    for i = #deck, 2, -1 do
        local j = math.random(1, i)
        deck[i], deck[j] = deck[j], deck[i]
    end
    return deck
end

local function CanPlaceFoundation(card, fIdx)
    local pile = Foundations[fIdx]
    local top = pile[#pile]
    if not top then
        return card.rank == 1
    end
    return card.suit == top.suit and card.rank == top.rank + 1
end

local function CanPlaceTableau(card, colIdx)
    local col = Tableau[colIdx]
    local top = col[#col]
    if not top then
        return card.rank == 13
    end
    if not top.up then return false end
    return (SUITS[card.suit].red ~= SUITS[top.suit].red) and (card.rank == top.rank - 1)
end

local function ReleaseCards()
    for _, btn in ipairs(CardPool) do
        btn:Hide()
        btn:ClearAllPoints()
    end
end

local function AcquireCardBtn()
    for _, btn in ipairs(CardPool) do
        if not btn:IsShown() then
            btn:Show()
            return btn
        end
    end
    local btn = CreateFrame("Button", nil, Root)
    btn:SetSize(CARD_W, CARD_H)
    btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    btn.border = btn:CreateTexture(nil, "BACKGROUND")
    btn.border:SetAllPoints()

    btn.bg = btn:CreateTexture(nil, "BORDER")
    btn.bg:SetPoint("TOPLEFT", 2, -2)
    btn.bg:SetPoint("BOTTOMRIGHT", -2, 2)

    btn.topTxt = btn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    btn.topTxt:SetPoint("TOPLEFT", 5, -4)

    btn.suitIcon = btn:CreateTexture(nil, "OVERLAY")
    btn.suitIcon:SetSize(22, 22)
    btn.suitIcon:SetPoint("CENTER", 0, -4)
    btn.suitIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    btn.centerTxt = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    btn.centerTxt:SetPoint("CENTER", 0, -2)

    table.insert(CardPool, btn)
    return btn
end

local function CheckWin()
    local total = #Foundations[1] + #Foundations[2] + #Foundations[3] + #Foundations[4]
    if total == 52 then
        WR.State.running = false
        WarcraftRunnerDB.bestSolitaire = (WarcraftRunnerDB.bestSolitaire or 0) + 1
        WarcraftRunnerDB.totalGold = (WarcraftRunnerDB.totalGold or 0) + 25
        WR.PlaySoundFile("jobdone.ogg", 1.0)
        WR.ShowOverlay("|cFFFFD100ПАСЬЯНС СОБРАН!|r", string.format("Ходов: %d  |  Награда: +25 золота", MovesCount), "Новая раздача", function() G:Start() end)
        return true
    end
    return false
end

local Render -- forward declaration

local function TryAutoFoundation(zone, col, idx)
    local card
    if zone == "waste" then
        card = Waste[#Waste]
    elseif zone == "tab" then
        local t = Tableau[col]
        if idx == #t then card = t[idx] end
    end
    if not card or not card.up then return false end

    for f = 1, 4 do
        if CanPlaceFoundation(card, f) then
            if zone == "waste" then
                table.remove(Waste)
            else
                table.remove(Tableau[col])
                local nt = Tableau[col]
                if #nt > 0 and not nt[#nt].up then nt[#nt].up = true end
            end
            table.insert(Foundations[f], card)
            MovesCount = MovesCount + 1
            Selected = nil
            WR.PlaySoundFile("complete.ogg", 0.5)
            Render()
            CheckWin()
            return true
        end
    end
    return false
end

local function ExecuteMove(targetZone, targetCol)
    if not Selected then return false end
    local sz, sc, si = Selected.zone, Selected.col, Selected.idx

    if targetZone == "found" then
        local card
        if sz == "waste" then
            card = Waste[#Waste]
        elseif sz == "tab" and si == #Tableau[sc] then
            card = Tableau[sc][si]
        end
        if card and CanPlaceFoundation(card, targetCol) then
            if sz == "waste" then
                table.remove(Waste)
            else
                table.remove(Tableau[sc])
                local nt = Tableau[sc]
                if #nt > 0 and not nt[#nt].up then nt[#nt].up = true end
            end
            table.insert(Foundations[targetCol], card)
            MovesCount = MovesCount + 1
            Selected = nil
            WR.PlaySoundFile("complete.ogg", 0.5)
            Render()
            CheckWin()
            return true
        end
    elseif targetZone == "tab" then
        if sz == "tab" and sc == targetCol then
            Selected = nil
            Render()
            return false
        end
        local moving = {}
        if sz == "waste" then
            if #Waste > 0 then table.insert(moving, Waste[#Waste]) end
        elseif sz == "found" then
            local fp = Foundations[sc]
            if #fp > 0 then table.insert(moving, fp[#fp]) end
        elseif sz == "tab" then
            local col = Tableau[sc]
            for i = si, #col do table.insert(moving, col[i]) end
        end

        if #moving > 0 and CanPlaceTableau(moving[1], targetCol) then
            if sz == "waste" then
                table.remove(Waste)
            elseif sz == "found" then
                table.remove(Foundations[sc])
            elseif sz == "tab" then
                local col = Tableau[sc]
                for _ = si, #col do table.remove(col) end
                if #col > 0 and not col[#col].up then col[#col].up = true end
            end
            for _, c in ipairs(moving) do
                table.insert(Tableau[targetCol], c)
            end
            MovesCount = MovesCount + 1
            Selected = nil
            WR.PlaySound(847)
            Render()
            return true
        end
    end
    return false
end

local function OnCardClick(zone, col, idx, button)
    if not WR.State.running then return end
    if button == "RightButton" then
        if TryAutoFoundation(zone, col, idx) then return end
    end

    if Selected then
        if Selected.zone == zone and Selected.col == col and Selected.idx == idx then
            Selected = nil
            Render()
            return
        end
        if ExecuteMove(zone, col) then return end
    end

    if zone == "waste" and #Waste > 0 then
        Selected = { zone = "waste", col = 0, idx = #Waste }
        WR.PlaySound(847)
    elseif zone == "found" and #Foundations[col] > 0 then
        Selected = { zone = "found", col = col, idx = #Foundations[col] }
        WR.PlaySound(847)
    elseif zone == "tab" then
        local c = Tableau[col][idx]
        if c and c.up then
            Selected = { zone = "tab", col = col, idx = idx }
            WR.PlaySound(847)
        elseif c and not c.up and idx == #Tableau[col] then
            c.up = true
            WR.PlaySound(847)
        else
            Selected = nil
        end
    else
        Selected = nil
    end
    Render()
end

local function StyleCardButton(btn, card, isSelected, level)
    btn:SetFrameLevel(level)

    if card.up then
        local s = SUITS[card.suit]
        if isSelected then
            WR.SetColor(btn.border, 1.0, 0.82, 0.15, 1)
        elseif s.red then
            WR.SetColor(btn.border, 0.85, 0.22, 0.18, 1)
        else
            WR.SetColor(btn.border, 0.18, 0.22, 0.35, 1)
        end

        btn.bg:SetTexture(nil)
        btn.bg:SetTexCoord(0, 1, 0, 1)
        WR.SetColor(btn.bg, 0.96, 0.94, 0.90, 1)
        btn.topTxt:SetText(s.color .. RANKS[card.rank] .. " " .. s.sym .. "|r")
        btn.suitIcon:SetTexture(s.tex)
        btn.suitIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        btn.suitIcon:SetVertexColor(1, 1, 1, 1)
        btn.suitIcon:Show()
        btn.centerTxt:SetText("")
    else
        if isSelected then
            WR.SetColor(btn.border, 1.0, 0.82, 0.15, 1)
        else
            WR.SetColor(btn.border, 0.22, 0.20, 0.15, 1)
        end
        btn.bg:SetTexture(WR.TEX .. "card_back_wc3.tga")
        btn.bg:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        btn.bg:SetVertexColor(1, 1, 1, 1)
        btn.suitIcon:Hide()
        btn.topTxt:SetText("")
        btn.centerTxt:SetText("")
    end
end

Render = function()
    ReleaseCards()
    local baseLevel = Root:GetFrameLevel() + 2

    -- Waste top card
    if #Waste > 0 then
        local c = Waste[#Waste]
        local b = AcquireCardBtn()
        b:SetPoint("TOPLEFT", Root, "TOPLEFT", LEFT_X + (CARD_W + COL_GAP), TOP_Y)
        local isSel = Selected and Selected.zone == "waste"
        StyleCardButton(b, c, isSel, baseLevel + 2)
        b:SetScript("OnClick", function(_, button) OnCardClick("waste", 0, #Waste, button) end)
    end

    -- Foundations
    for f = 1, 4 do
        local pile = Foundations[f]
        if #pile > 0 then
            local c = pile[#pile]
            local b = AcquireCardBtn()
            b:SetPoint("TOPLEFT", Root, "TOPLEFT", LEFT_X + (f + 2) * (CARD_W + COL_GAP), TOP_Y)
            local isSel = Selected and Selected.zone == "found" and Selected.col == f
            StyleCardButton(b, c, isSel, baseLevel + 2)
            b:SetScript("OnClick", function(_, button) OnCardClick("found", f, #pile, button) end)
        end
    end

    -- Tableau columns
    for col = 1, 7 do
        local x = LEFT_X + (col - 1) * (CARD_W + COL_GAP)
        local yOff = 0
        for idx, c in ipairs(Tableau[col]) do
            local b = AcquireCardBtn()
            b:SetPoint("TOPLEFT", Root, "TOPLEFT", x, TAB_Y - yOff)
            local isSel = Selected and Selected.zone == "tab" and Selected.col == col and idx >= Selected.idx
            StyleCardButton(b, c, isSel, baseLevel + idx + 1)
            local cc, ii = col, idx
            b:SetScript("OnClick", function(_, button) OnCardClick("tab", cc, ii, button) end)
            yOff = yOff + (c.up and 18 or 9)
        end
    end

    if SlotButtons.stockBg then
        if #Stock > 0 then
            SlotButtons.stockBg:SetTexture(WR.TEX .. "card_back_wc3.tga")
            SlotButtons.stockBg:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            SlotButtons.stockBg:SetVertexColor(1, 1, 1, 1)
        else
            SlotButtons.stockBg:SetTexture(nil)
            SlotButtons.stockBg:SetTexCoord(0, 1, 0, 1)
            WR.SetColor(SlotButtons.stockBg, 0.08, 0.11, 0.15, 0.65)
        end
    end

    if SlotButtons.stockLabel then
        SlotButtons.stockLabel:SetText(#Stock > 0 and ("|cFFFFD100" .. #Stock .. "|r") or "↻")
    end

    WR.SetHUD(
        string.format("Пасьянс Косынка  |  Ходов: %d", MovesCount),
        string.format("Побед: |cFFFFD100%d|r  |  ПКМ: в дом", WarcraftRunnerDB.bestSolitaire or 0)
    )
end

local function OnStockClick()
    if not WR.State.running then return end
    Selected = nil
    if #Stock > 0 then
        local c = table.remove(Stock)
        c.up = true
        table.insert(Waste, c)
    elseif #Waste > 0 then
        while #Waste > 0 do
            local c = table.remove(Waste)
            c.up = false
            table.insert(Stock, c)
        end
    end
    MovesCount = MovesCount + 1
    WR.PlaySound(847)
    Render()
end

local function MakeSlot(x, y, labelText, onClick)
    local s = CreateFrame("Button", nil, Root)
    s:SetSize(CARD_W, CARD_H)
    s:SetPoint("TOPLEFT", Root, "TOPLEFT", x, y)
    local bg = s:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    WR.SetColor(bg, 0.08, 0.11, 0.15, 0.65)
    local txt = s:CreateFontString(nil, "OVERLAY", "GameFontDisable")
    txt:SetPoint("CENTER")
    txt:SetText(labelText)
    s:SetScript("OnClick", onClick)
    return s, txt, bg
end

local function EnsureUI()
    if Root then return end
    Root = CreateFrame("Frame", nil, WR.Viewport)
    Root:SetAllPoints()
    Root:SetFrameLevel(WR.Viewport:GetFrameLevel() + 8)

    local _, stockTxt, stockBg = MakeSlot(LEFT_X, TOP_Y, "24", OnStockClick)
    SlotButtons.stockLabel = stockTxt
    SlotButtons.stockBg = stockBg

    MakeSlot(LEFT_X + (CARD_W + COL_GAP), TOP_Y, "Сброс", function() end)

    for f = 1, 4 do
        local ff = f
        local s, _, bg = MakeSlot(LEFT_X + (f + 2) * (CARD_W + COL_GAP), TOP_Y, "", function()
            if Selected then ExecuteMove("found", ff) end
        end)
        local ico = s:CreateTexture(nil, "ARTWORK")
        ico:SetSize(22, 22)
        ico:SetPoint("CENTER")
        ico:SetTexture(SUITS[f].tex)
        ico:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        ico:SetAlpha(0.35)
    end

    for col = 1, 7 do
        local cc = col
        MakeSlot(LEFT_X + (col - 1) * (CARD_W + COL_GAP), TAB_Y, "K", function()
            if Selected then ExecuteMove("tab", cc) end
        end)
    end

    local resetBtn = CreateFrame("Button", nil, Root, "UIPanelButtonTemplate")
    resetBtn:SetSize(96, 22)
    resetBtn:SetPoint("BOTTOMRIGHT", -12, 8)
    resetBtn:SetText("Пересдать")
    resetBtn:SetScript("OnClick", function()
        WR.PlaySound(847)
        G:Start()
    end)
end

function G:Start()
    EnsureUI()
    Root:Show()
    local deck = NewDeck()
    Stock = {}
    Waste = {}
    Foundations = { {}, {}, {}, {} }
    Tableau = { {}, {}, {}, {}, {}, {}, {} }
    Selected = nil
    MovesCount = 0

    local idx = 1
    for col = 1, 7 do
        for row = 1, col do
            local c = deck[idx]
            idx = idx + 1
            c.up = (row == col)
            table.insert(Tableau[col], c)
        end
    end
    for i = idx, #deck do
        table.insert(Stock, deck[i])
    end

    Render()
end

function G:ShowIntro()
    EnsureUI()
    Root:Show()
    WR.SetHUD("Пасьянс Косынка", string.format("Побед: %d", WarcraftRunnerDB.bestSolitaire or 0))
    WR.ShowOverlay("|cFFFFD100ПАСЬЯНС КОСЫНКА|r", "Собери все 4 масти от Туза до Короля. Правый клик — автоотправка в дом.", "Раздать карты", function() G:Start() end)
end

function G:Stop()
    if Root then Root:Hide() end
end
