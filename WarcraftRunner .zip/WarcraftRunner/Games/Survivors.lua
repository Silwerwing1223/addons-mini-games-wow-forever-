local _, WR = ...

local G = {}
WR.Games.survivors = G

local Root, HeroFrame, HeroModel, AoERing, TalentPanel
local SkillBtns = {}
local TalentBtns = {}
local Enemies, Bolts, Gems = {}, {}, {}
local Keys = {}
local PX, PY = 0, 0
local HP, MaxHP = 100, 100
local XP, NextXP, Level = 0, 5, 1
local Score, Elapsed = 0, 0
local SpawnT, BoltT, AoET = 0, 0, 0
local AoEDmg, AoERadius, BoltDmg, BoltCount, BoltInterval = 20, 75, 25, 1, 0.75
local NovaDmg, FrostDmg, FrostDur, MoveSpeed = 60, 35, 3.0, 175
local CDMult, DmgReduce = 1.0, 1.0
local DashCD, ShieldCD, NovaCD, FrostCD, HealCD = 0, 0, 0, 0, 0
local ShieldT = 0
local Paused = false
local TalentRanks = {}

local TALENTS = {
    { id = "consecrate", title = "Освящение",         spell = 26573, desc = "Аура: +15 урона и +8 радиуса",      fn = function() AoEDmg = AoEDmg + 15; AoERadius = math.min(160, AoERadius + 8) end },
    { id = "frostbolt",  title = "Ледяная стрела",    spell = 116,   desc = "Урон самонаводящихся болтов +20",   fn = function() BoltDmg = BoltDmg + 20 end },
    { id = "multishot",  title = "Веер клинков",      spell = 51723, desc = "+1 дополнительный болт за залп",    fn = function() BoltCount = math.min(6, BoltCount + 1) end },
    { id = "spiritwolf", title = "Дух волка",         spell = 2983,  desc = "Скорость бега +25 и +30 HP",        fn = function() MoveSpeed = MoveSpeed + 25; HP = math.min(MaxHP, HP + 30) end },
    { id = "stormbolt",  title = "Молот бурь",        spell = 24275, desc = "Урон Молота гнева [3]: +45",        fn = function() NovaDmg = NovaDmg + 45 end },
    { id = "blizzard",   title = "Снежная буря",      spell = 10,    desc = "Кольцо льда [4]: +40 урона и +0.6с", fn = function() FrostDmg = FrostDmg + 40; FrostDur = FrostDur + 0.6 end },
    { id = "holylight",  title = "Свет небес",        spell = 635,   desc = "Макс. HP +35 и полное исцеление",   fn = function() MaxHP = MaxHP + 35; HP = MaxHP end },
    { id = "bloodlust",  title = "Жажда крови",       spell = 2825,  desc = "Частота болтов +15% и +10 урона",   fn = function() BoltInterval = math.max(0.22, BoltInterval * 0.85); BoltDmg = BoltDmg + 10 end },
    { id = "arcane",     title = "Магическая мощь",   spell = 23920, desc = "Перезарядка всех скиллов -12%",     fn = function() CDMult = math.max(0.30, CDMult * 0.88) end },
    { id = "devotion",   title = "Аура благочестия",  spell = 465,   desc = "Получаемый урон -12% и +25 HP",     fn = function() DmgReduce = math.max(0.25, DmgReduce * 0.88); HP = math.min(MaxHP, HP + 25) end },
}

local function AcquireObj(pool, size, texPath, layer)
    for _, o in ipairs(pool) do
        if not o.active then
            o.active = true
            o.f:Show()
            o.tex:SetTexture(texPath)
            o.tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            return o
        end
    end
    local f = CreateFrame("Frame", nil, Root)
    f:SetSize(size, size)
    f:SetFrameLevel(Root:GetFrameLevel() + (layer or 4))
    local t = f:CreateTexture(nil, "ARTWORK")
    t:SetAllPoints()
    t:SetTexture(texPath)
    t:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local obj = { f = f, tex = t, active = true }
    table.insert(pool, obj)
    return obj
end

local function ClearAll()
    for _, pool in ipairs({ Enemies, Bolts, Gems }) do
        for _, o in ipairs(pool) do o.active = false; o.f:Hide() end
    end
end

local function CountActive(pool)
    local n = 0
    for _, o in ipairs(pool) do if o.active then n = n + 1 end end
    return n
end

local function ShowTalents()
    Paused = true
    local idxs = {}
    for i = 1, #TALENTS do idxs[i] = i end
    for i = #idxs, 2, -1 do
        local j = math.random(1, i)
        idxs[i], idxs[j] = idxs[j], idxs[i]
    end
    for i = 1, 3 do
        local tal = TALENTS[idxs[i]]
        local b = TalentBtns[i]
        local rank = TalentRanks[tal.id] or 0
        b.ico:SetTexture(WR.GetSpellIcon(tal.spell, WR.TEX .. "wc3_paladin.tga"))
        b.ico:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        b.title:SetText(string.format("%s |cFF88EE88(%d)|r", tal.title, rank + 1))
        b.desc:SetText(tal.desc)
        b:SetScript("OnClick", function()
            TalentRanks[tal.id] = rank + 1
            tal.fn()
            TalentPanel:Hide()
            Paused = false
            WR.PlaySoundFile("complete.ogg", 0.8)
        end)
    end
    TalentPanel:Show()
    WR.AnimPop(TalentPanel, 1.06)
end

local function EnsureUI()
    if Root then return end
    Root = CreateFrame("Frame", nil, WR.Viewport)
    Root:SetAllPoints()
    Root:SetFrameLevel(WR.Viewport:GetFrameLevel() + 8)

    AoERing = Root:CreateTexture(nil, "BORDER")
    AoERing:SetSize(130, 130)
    AoERing:SetTexture(WR.TEX .. "particle_glow.tga")
    AoERing:SetBlendMode("ADD")
    AoERing:SetVertexColor(1, 0.78, 0.2, 0.25)

    HeroFrame = CreateFrame("Frame", nil, Root)
    HeroFrame:SetSize(60, 60)
    HeroFrame:SetFrameLevel(Root:GetFrameLevel() + 10)
    HeroModel = CreateFrame("PlayerModel", nil, HeroFrame)
    HeroModel:SetAllPoints()
    HeroModel:SetScript("OnModelLoaded", function(self)
        pcall(self.SetUnit, self, "player")
        pcall(self.SetFacing, self, 0)
        pcall(self.SetPosition, self, 0, 0, -0.05)
        pcall(self.SetAnimation, self, 5)
    end)

    TalentPanel = WR.CreateStyled("Frame", nil, Root)
    TalentPanel:SetSize(466, 200)
    TalentPanel:SetPoint("CENTER")
    TalentPanel:SetFrameLevel(Root:GetFrameLevel() + 20)
    TalentPanel:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        tile = true, tileSize = 32, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    local th = TalentPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    th:SetPoint("TOP", 0, -12)
    th:SetText("|cFFFFD100НОВЫЙ УРОВЕНЬ! ВЫБЕРИ ТАЛАНТ:|r")

    for i = 1, 3 do
        local b = CreateFrame("Button", nil, TalentPanel, "UIPanelButtonTemplate")
        b:SetSize(138, 132)
        b:SetPoint("BOTTOMLEFT", 14 + (i - 1) * 150, 14)

        local ico = b:CreateTexture(nil, "ARTWORK")
        ico:SetSize(36, 36)
        ico:SetPoint("TOP", 0, -10)
        b.ico = ico

        local title = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        title:SetPoint("TOP", ico, "BOTTOM", 0, -6)
        title:SetWidth(128)
        b.title = title

        local desc = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        desc:SetPoint("TOP", title, "BOTTOM", 0, -4)
        desc:SetWidth(124)
        b.desc = desc

        TalentBtns[i] = b
    end
    TalentPanel:Hide()

    local skills = {
        { key = "1", name = "Рывок",  spell = 100,   fb = WR.TEX .. "potion_speed.tga" },
        { key = "2", name = "Щит",    spell = 642,   fb = WR.TEX .. "coin_gold.tga" },
        { key = "3", name = "Молот",  spell = 24275, fb = WR.TEX .. "wc3_paladin.tga" },
        { key = "4", name = "Лёд",    spell = 122,   fb = WR.TEX .. "wc3_archmage.tga" },
        { key = "5", name = "Свет",   spell = 635,   fb = WR.TEX .. "wc3_potion_red.tga" },
    }
    for i, sk in ipairs(skills) do
        local b = CreateFrame("Button", nil, Root)
        b:SetSize(38, 38)
        b:SetPoint("BOTTOM", Root, "BOTTOM", (i - 3) * 46, 12)
        b:SetFrameLevel(Root:GetFrameLevel() + 16)
        local ico = b:CreateTexture(nil, "ARTWORK")
        ico:SetAllPoints()
        ico:SetTexture(WR.GetSpellIcon(sk.spell, sk.fb))
        ico:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        local cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
        cd:SetAllPoints()
        local hk = b:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
        hk:SetPoint("TOPRIGHT", -2, -2)
        hk:SetText(sk.key)
        b.cd = cd
        b:SetScript("OnClick", function() G:OnKeyDown(sk.key) end)
        SkillBtns[i] = b
    end
end

function G:Start()
    EnsureUI()
    ClearAll()
    Root:Show()
    TalentPanel:Hide()
    Paused = false
    PX, PY = 0, 0
    HP, MaxHP = 100, 100
    XP, NextXP, Level = 0, 5, 1
    Score, Elapsed = 0, 0
    AoEDmg, AoERadius, BoltDmg, BoltCount, BoltInterval = 20, 75, 25, 1, 0.75
    NovaDmg, FrostDmg, FrostDur, MoveSpeed = 60, 35, 3.0, 175
    CDMult, DmgReduce = 1.0, 1.0
    DashCD, ShieldCD, NovaCD, FrostCD, HealCD, ShieldT = 0, 0, 0, 0, 0, 0
    TalentRanks = {}
    pcall(HeroModel.SetUnit, HeroModel, "player")
end

function G:ShowIntro()
    EnsureUI()
    Root:Show()
    WR.SetHUD("Выживание в Азероте", string.format("Рекорд: %d", WarcraftRunnerDB.bestSurv or 0))
    WR.ShowOverlay("|cFFFFD100ВЫЖИВАНИЕ В АЗЕРОТЕ|r", "Бесконечный режим: 10 талантов WC3, орды мобов растут с каждым уровнем!", "В бой!", function() G:Start() end)
end

function G:Stop()
    ClearAll()
    if Root then Root:Hide() end
end

function G:OnKeyDown(key)
    Keys[key] = true
    if Paused or not WR.State.running then return end
    if key == "1" and DashCD <= 0 then
        local cd = 4 * CDMult
        DashCD = cd; if SkillBtns[1] and SkillBtns[1].cd then SkillBtns[1].cd:SetCooldown(GetTime(), cd) end
        local dx = (Keys["D"] and 1 or 0) - (Keys["A"] and 1 or 0)
        local dy = (Keys["W"] and 1 or 0) - (Keys["S"] and 1 or 0)
        if dx == 0 and dy == 0 then dy = 1 end
        PX = math.max(-250, math.min(250, PX + dx * 95))
        PY = math.max(-175, math.min(165, PY + dy * 95))
        WR.FloatText("Рывок!", PX, PY + 25, 0.3, 0.9, 1)
        WR.PlaySoundFile("footman_yes.ogg", 0.8)
    elseif key == "2" and ShieldCD <= 0 then
        local cd = 10 * CDMult
        ShieldCD = cd; ShieldT = 4; if SkillBtns[2] and SkillBtns[2].cd then SkillBtns[2].cd:SetCooldown(GetTime(), cd) end
        WR.FloatText("Божественный щит!", PX, PY + 25, 1, 0.85, 0.2)
        WR.PlaySoundFile("paladin_yes.ogg", 0.8)
    elseif key == "3" and NovaCD <= 0 then
        local cd = 6 * CDMult
        NovaCD = cd; if SkillBtns[3] and SkillBtns[3].cd then SkillBtns[3].cd:SetCooldown(GetTime(), cd) end
        WR.Shake(0.18)
        WR.FloatText("Молот бурь!", PX, PY + 25, 1, 0.4, 0.2)
        WR.PlaySoundFile("paladin_attack.ogg", 0.6)
        for _, e in ipairs(Enemies) do
            if e.active and ((e.x - PX)^2 + (e.y - PY)^2) < 165^2 then
                e.hp = e.hp - NovaDmg
            end
        end
    elseif key == "4" and FrostCD <= 0 then
        local cd = 8 * CDMult
        FrostCD = cd; if SkillBtns[4] and SkillBtns[4].cd then SkillBtns[4].cd:SetCooldown(GetTime(), cd) end
        WR.FloatText("Кольцо льда!", PX, PY + 25, 0.4, 0.85, 1)
        WR.PlaySoundFile("archmage_attack.ogg", 0.6)
        for _, e in ipairs(Enemies) do
            if e.active and ((e.x - PX)^2 + (e.y - PY)^2) < 175^2 then
                e.hp = e.hp - FrostDmg
                e.slowT = FrostDur
                e.tex:SetVertexColor(0.5, 0.8, 1)
            end
        end
    elseif key == "5" and HealCD <= 0 then
        local cd = 12 * CDMult
        HealCD = cd; if SkillBtns[5] and SkillBtns[5].cd then SkillBtns[5].cd:SetCooldown(GetTime(), cd) end
        HP = math.min(MaxHP, HP + 40)
        WR.FloatText("+40 HP", PX, PY + 25, 0.3, 1, 0.4)
        WR.PlaySoundFile("paladin_ready.ogg", 0.8)
    end
end

function G:OnKeyUp(key)
    Keys[key] = false
end

function G:OnUpdate(dt)
    if Paused then return end
    Elapsed = Elapsed + dt
    DashCD = math.max(0, DashCD - dt)
    ShieldCD = math.max(0, ShieldCD - dt)
    NovaCD = math.max(0, NovaCD - dt)
    FrostCD = math.max(0, FrostCD - dt)
    HealCD = math.max(0, HealCD - dt)
    ShieldT = math.max(0, ShieldT - dt)

    local dx = ((Keys["D"] or Keys["RIGHT"]) and 1 or 0) - ((Keys["A"] or Keys["LEFT"]) and 1 or 0)
    local dy = ((Keys["W"] or Keys["UP"]) and 1 or 0) - ((Keys["S"] or Keys["DOWN"]) and 1 or 0)
    PX = math.max(-255, math.min(255, PX + dx * MoveSpeed * dt))
    PY = math.max(-180, math.min(165, PY + dy * MoveSpeed * dt))
    if dx ~= 0 then pcall(HeroModel.SetFacing, HeroModel, dx > 0 and 0.8 or -0.8) end

    HeroFrame:ClearAllPoints(); HeroFrame:SetPoint("CENTER", Root, "CENTER", PX, PY)
    AoERing:SetSize(AoERadius * 1.75, AoERadius * 1.75)
    AoERing:ClearAllPoints(); AoERing:SetPoint("CENTER", Root, "CENTER", PX, PY)
    AoERing:SetVertexColor(ShieldT > 0 and 0.3 or 1, ShieldT > 0 and 0.9 or 0.78, ShieldT > 0 and 1 or 0.2, 0.28)

    SpawnT = SpawnT + dt
    local spawnInterval = math.max(0.22, 1.15 - Level * 0.06)
    if SpawnT >= spawnInterval and CountActive(Enemies) < 48 then
        SpawnT = 0
        local waveCount = math.min(4, 1 + math.floor((Level - 1) / 3))
        for _ = 1, waveCount do
            local isMurloc = (math.random(1, 2) == 1)
            local e = AcquireObj(Enemies, 34, isMurloc and (WR.TEX .. "mob_murloc.tga") or (WR.TEX .. "mob_kobold.tga"), 5)
            e.deathSound = isMurloc and "murloc_death.ogg" or "kobold_death.ogg"
            e.tex:SetVertexColor(1, 1, 1)
            e.slowT = 0
            local ang = math.random() * 6.28
            e.x = math.cos(ang) * 305
            e.y = math.sin(ang) * 235
            e.hp = 30 + Level * 18 + math.floor(Elapsed * 0.7)
        end
    end

    AoET = AoET + dt
    if AoET >= 0.65 then
        AoET = 0
        for _, e in ipairs(Enemies) do
            if e.active and ((e.x - PX)^2 + (e.y - PY)^2) < AoERadius^2 then
                e.hp = e.hp - AoEDmg
            end
        end
    end

    BoltT = BoltT + dt
    if BoltT >= BoltInterval then
        BoltT = 0
        local best, bestD = nil, 999999
        for _, e in ipairs(Enemies) do
            if e.active then
                local d = (e.x - PX)^2 + (e.y - PY)^2
                if d < bestD then bestD = d; best = e end
            end
        end
        if best then
            local baseAng = math.atan2(best.y - PY, best.x - PX)
            for k = 1, BoltCount do
                local spread = (k - (BoltCount + 1) * 0.5) * 0.22
                local ang = baseAng + spread
                local b = AcquireObj(Bolts, 16, WR.TEX .. "particle_glow.tga", 7)
                b.tex:SetVertexColor(0.3, 0.9, 1.0, 1)
                b.x, b.y = PX, PY
                b.vx = math.cos(ang) * 350
                b.vy = math.sin(ang) * 350
                b.ttl = 1.5
            end
        end
    end

    for _, b in ipairs(Bolts) do
        if b.active then
            b.x = b.x + b.vx * dt; b.y = b.y + b.vy * dt; b.ttl = b.ttl - dt
            b.f:ClearAllPoints(); b.f:SetPoint("CENTER", Root, "CENTER", b.x, b.y)
            for _, e in ipairs(Enemies) do
                if e.active and ((e.x - b.x)^2 + (e.y - b.y)^2) < 22^2 then
                    e.hp = e.hp - BoltDmg
                    b.active = false; b.f:Hide()
                    break
                end
            end
            if b.ttl <= 0 then b.active = false; b.f:Hide() end
        end
    end

    local mobBaseSpd = math.min(135, 68 + Level * 3.5)
    local mobDmg = 25 + Level * 3
    for _, e in ipairs(Enemies) do
        if e.active then
            if e.hp <= 0 then
                e.active = false; e.f:Hide()
                if e.deathSound then
                    WR.PlaySoundFile(e.deathSound, 0.35)
                end
                Score = Score + 10 + Level * 2
                local g = AcquireObj(Gems, 18, WR.TEX .. "coin_gold.tga", 4)
                g.x, g.y = e.x, e.y
                g.f:ClearAllPoints(); g.f:SetPoint("CENTER", Root, "CENTER", g.x, g.y)
            else
                if e.slowT and e.slowT > 0 then
                    e.slowT = e.slowT - dt
                    if e.slowT <= 0 then e.tex:SetVertexColor(1, 1, 1) end
                end
                local spd = (e.slowT and e.slowT > 0) and (mobBaseSpd * 0.4) or mobBaseSpd
                local d = math.sqrt((PX - e.x)^2 + (PY - e.y)^2)
                e.x = e.x + ((PX - e.x) / math.max(1, d)) * spd * dt
                e.y = e.y + ((PY - e.y) / math.max(1, d)) * spd * dt
                e.f:ClearAllPoints(); e.f:SetPoint("CENTER", Root, "CENTER", e.x, e.y)
                if d < 24 and ShieldT <= 0 then
                    HP = HP - (mobDmg * DmgReduce) * dt
                    if HP <= 0 then
                        if Score > (WarcraftRunnerDB.bestSurv or 0) then WarcraftRunnerDB.bestSurv = Score end
                        WR.State.running = false
                        WR.DamageFlash()
                        WR.PlaySoundFile("herofallen.ogg", 1.0)
                        WR.ShowOverlay("|cFFFF4444ПОРАЖЕНИЕ|r", string.format("Уровень: %d  |  Очки: |cFFFFD100%d|r", Level, Score), "Играть снова", function() G:Start() end)
                        return
                    end
                end
            end
        end
    end

    for _, g in ipairs(Gems) do
        if g.active and ((g.x - PX)^2 + (g.y - PY)^2) < 34^2 then
            g.active = false; g.f:Hide()
            XP = XP + 1
            WarcraftRunnerDB.totalGold = (WarcraftRunnerDB.totalGold or 0) + 1
            WR.PlaySound(120)
            if XP >= NextXP then
                XP = 0; Level = Level + 1; NextXP = NextXP + 4
                ShowTalents()
            end
        end
    end

    WR.SetHUD(
        string.format("HP: |cFF44FF44%d/%d|r  |  Ур. |cFFFFD100%d|r (%d/%d)  |  Очки: |cFFFFD100%d|r", math.ceil(HP), MaxHP, Level, XP, NextXP, Score),
        string.format("[1]%.0f [2]%.0f [3]%.0f [4]%.0f [5]%.0f", DashCD, ShieldCD, NovaCD, FrostCD, HealCD)
    )
end
