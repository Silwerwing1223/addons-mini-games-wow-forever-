local _, WR = ...

local G = {}
WR.Games.durak = G

local PREFIX = "WRDURAK"
local SUITS = {
    { id = 1, sym = "Ч", color = "|cFFFF2020", tex = "suit_heart.tga", red = true },
    { id = 2, sym = "Б", color = "|cFFFF7000", tex = "suit_diamond.tga", red = true },
    { id = 3, sym = "Т", color = "|cFF2060E0", tex = "suit_club.tga", red = false },
    { id = 4, sym = "П", color = "|cFF151820", tex = "suit_spade.tga", red = false },
}
local RANKS = { [6]="6", [7]="7", [8]="8", [9]="9", [10]="10", [11]="J", [12]="Q", [13]="K", [14]="A" }

local HIGH_CARD_ICONS = {
    [11] = {
        [1] = WR.TEX .. "durak_j_heart.tga",
        [2] = WR.TEX .. "durak_j_diamond.tga",
        [3] = WR.TEX .. "durak_j_club.tga",
        [4] = WR.TEX .. "durak_j_spade.tga",
    },
    [12] = {
        [1] = WR.TEX .. "durak_q_heart.tga",
        [2] = WR.TEX .. "durak_q_diamond.tga",
        [3] = WR.TEX .. "durak_q_club.tga",
        [4] = WR.TEX .. "durak_q_spade.tga",
    },
    [13] = {
        [1] = WR.TEX .. "durak_k_heart.tga",
        [2] = WR.TEX .. "durak_k_diamond.tga",
        [3] = WR.TEX .. "durak_k_club.tga",
        [4] = WR.TEX .. "durak_k_spade.tga",
    },
    [14] = {
        [1] = WR.TEX .. "durak_a_heart.tga",
        [2] = WR.TEX .. "durak_a_diamond.tga",
        [3] = WR.TEX .. "durak_a_club.tga",
        [4] = WR.TEX .. "durak_a_spade.tga",
    },
}

local Root, TrumpBox, DeckText, ActionBtn, NameInput
local HandBtns = {}
local TableCards = {}

local NetMode = false
local IsHost = true
local Opponent = nil
local PendingInviteFrom = nil

local Deck = {}
local TrumpSuit = 1
local MyHand = {}
local OppHand = {} -- used in solo AI; in PvP we track OppCount
local OppCount = 6
local Table = {} -- list of { atk = card, def = card or nil }
local Attacker = "me" -- "me" | "opp"
local GameActive = false

local function ShortName(name)
    if not name then return "" end
    return Ambiguate and Ambiguate(name, "short") or name:match("^([^%-]+)") or name
end

local function SendNet(msg, target)
    local dest = target or Opponent
    if not dest or dest == "" then return end
    if C_ChatInfo and C_ChatInfo.SendAddonMessage then
        pcall(C_ChatInfo.SendAddonMessage, PREFIX, msg, "WHISPER", dest)
    elseif SendAddonMessage then
        pcall(SendAddonMessage, PREFIX, msg, "WHISPER", dest)
    end
end

local function CanBeat(atk, def)
    if def.suit == atk.suit then
        return def.rank > atk.rank
    end
    return def.suit == TrumpSuit and atk.suit ~= TrumpSuit
end

local function CanThrowIn(card)
    if #Table == 0 then return true end
    if #Table >= 6 then return false end
    for _, pair in ipairs(Table) do
        if pair.atk.rank == card.rank then return true end
        if pair.def and pair.def.rank == card.rank then return true end
    end
    return false
end

local function CardStr(c)
    return c.suit .. ":" .. c.rank
end

local function ParseCard(s)
    local su, rk = strsplit(":", s)
    return { suit = tonumber(su), rank = tonumber(rk) }
end

local function SerializeList(list)
    local t = {}
    for _, c in ipairs(list) do table.insert(t, CardStr(c)) end
    return table.concat(t, ",")
end

local function DeserializeList(str)
    local list = {}
    if not str or str == "" then return list end
    for part in str:gmatch("[^,]+") do
        table.insert(list, ParseCard(part))
    end
    return list
end

local function StyleCard(btn, card, clickable)
    btn:Show()
    WR.SetColor(btn.border, clickable and 0.95 or 0.25, clickable and 0.78 or 0.28, clickable and 0.15 or 0.32, 1)
    WR.SetColor(btn.bg, 0.94, 0.91, 0.84, 1)
    local s = SUITS[card.suit]
    btn.topTxt:SetText(s.color .. RANKS[card.rank] .. " " .. s.sym .. "|r")

    local highIco = HIGH_CARD_ICONS[card.rank] and HIGH_CARD_ICONS[card.rank][card.suit]
    if highIco then
        btn.portrait:SetTexture(highIco)
        btn.portrait:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        btn.portrait:Show()
        btn.suitIco:SetSize(16, 16)
        btn.suitIco:ClearAllPoints()
        btn.suitIco:SetPoint("BOTTOMRIGHT", -3, 3)
        btn.suitIco:SetTexture(WR.TEX .. s.tex)
        btn.suitIco:Show()
    else
        btn.portrait:Hide()
        btn.suitIco:SetSize(28, 28)
        btn.suitIco:ClearAllPoints()
        btn.suitIco:SetPoint("CENTER", 0, -6)
        btn.suitIco:SetTexture(WR.TEX .. s.tex)
        btn.suitIco:Show()
    end
end

local Render -- forward

local function CheckWin()
    if #Deck > 0 then return false end
    local myEmpty = (#MyHand == 0)
    local oppEmpty = NetMode and (OppCount <= 0) or (#OppHand == 0)
    if myEmpty or oppEmpty then
        GameActive = false
        WR.State.running = false
        if myEmpty then
            WarcraftRunnerDB.bestDurak = (WarcraftRunnerDB.bestDurak or 0) + 1
            WarcraftRunnerDB.totalGold = (WarcraftRunnerDB.totalGold or 0) + 25
            WR.PlaySoundFile("complete.ogg", 1.0)
            WR.ShowOverlay("|cFFFFD100ПОБЕДА В ДУРАКЕ!|r", "Карты закончились! Награда: +25 золота", "Играть снова", function()
                G:Start(false, nil)
            end)
        else
            WR.PlaySoundFile("herofallen.ogg", 1.0)
            WR.ShowOverlay("|cFFFF4444ПОРАЖЕНИЕ|r", "Противник сбросил все карты первым.", "Играть снова", function()
                G:Start(false, nil)
            end)
        end
        return true
    end
    return false
end

local function RefillHands()
    local first = (Attacker == "me") and MyHand or OppHand
    local second = (Attacker == "me") and OppHand or MyHand
    if not NetMode then
        while #first < 6 and #Deck > 0 do table.insert(first, table.remove(Deck, 1)) end
        while #second < 6 and #Deck > 0 do table.insert(second, table.remove(Deck, 1)) end
        OppCount = #OppHand
    else
        while #MyHand < 6 and #Deck > 0 do table.insert(MyHand, table.remove(Deck, 1)) end
        local oppNeed = math.max(0, 6 - OppCount)
        local given = {}
        for _ = 1, math.min(oppNeed, #Deck) do
            table.insert(given, table.remove(Deck, 1))
            OppCount = OppCount + 1
        end
        if #given > 0 then
            SendNet("DRAW:" .. SerializeList(given))
        end
        SendNet("DECK:" .. SerializeList(Deck))
    end
end

local function RunAI()
    if NetMode or not GameActive then return end
    if Attacker == "me" then
        -- AI defends
        for _, pair in ipairs(Table) do
            if not pair.def then
                local bestIdx, bestScore = nil, 999
                for i, c in ipairs(OppHand) do
                    if CanBeat(pair.atk, c) then
                        local sc = c.rank + ((c.suit == TrumpSuit) and 20 or 0)
                        if sc < bestScore then bestScore = sc; bestIdx = i end
                    end
                end
                if bestIdx then
                    pair.def = table.remove(OppHand, bestIdx)
                else
                    -- AI takes all
                    for _, p in ipairs(Table) do
                        table.insert(OppHand, p.atk)
                        if p.def then table.insert(OppHand, p.def) end
                    end
                    Table = {}
                    RefillHands()
                    Attacker = "me"
                    Render()
                    CheckWin()
                    return
                end
            end
        end
        Render()
        CheckWin()
    else
        -- AI attacks
        if #Table == 0 then
            if #OppHand == 0 then CheckWin(); return end
            table.sort(OppHand, function(a, b)
                local sa = a.rank + ((a.suit == TrumpSuit) and 20 or 0)
                local sb = b.rank + ((b.suit == TrumpSuit) and 20 or 0)
                return sa < sb
            end)
            table.insert(Table, { atk = table.remove(OppHand, 1), def = nil })
        else
            -- Check if all beaten -> try throw in or bito
            local allBeaten = true
            for _, p in ipairs(Table) do if not p.def then allBeaten = false end end
            if allBeaten then
                local threw = false
                if #MyHand > 0 and #Table < 6 then
                    for i, c in ipairs(OppHand) do
                        if CanThrowIn(c) and c.suit ~= TrumpSuit then
                            table.insert(Table, { atk = table.remove(OppHand, i), def = nil })
                            threw = true
                            break
                        end
                    end
                end
                if not threw then
                    Table = {}
                    RefillHands()
                    Attacker = "me"
                end
            end
        end
        Render()
        CheckWin()
    end
end

local function OnMyCardClick(idx)
    if not GameActive then return end
    local c = MyHand[idx]
    if not c then return end

    if Attacker == "me" then
        if not CanThrowIn(c) then
            WR.FloatText("Нельзя подкинуть!", 0, 20, 1, 0.35, 0.35)
            return
        end
        table.remove(MyHand, idx)
        table.insert(Table, { atk = c, def = nil })
        WR.PlaySound(856)
        if NetMode then
            SendNet("ATK:" .. CardStr(c) .. ":" .. #MyHand)
        else
            C_Timer.After(0.45, RunAI)
        end
    else
        -- I am defending: find first unbeaten attack card I can beat
        local beatIdx = nil
        for i, pair in ipairs(Table) do
            if not pair.def and CanBeat(pair.atk, c) then
                beatIdx = i
                break
            end
        end
        if not beatIdx then
            WR.FloatText("Эта карта не бьёт!", 0, 20, 1, 0.35, 0.35)
            return
        end
        table.remove(MyHand, idx)
        Table[beatIdx].def = c
        WR.PlaySound(856)
        if NetMode then
            SendNet("DEF:" .. beatIdx .. ":" .. CardStr(c) .. ":" .. #MyHand)
        else
            C_Timer.After(0.45, RunAI)
        end
    end
    Render()
    CheckWin()
end

local function OnActionClick()
    if not GameActive then return end
    if Attacker == "me" then
        -- Bito! Only if table not empty and all beaten
        if #Table == 0 then return end
        for _, p in ipairs(Table) do
            if not p.def then
                WR.FloatText("Сначала противник должен отбиться!", 0, 20, 1, 0.6, 0.2)
                return
            end
        end
        Table = {}
        if NetMode then
            if IsHost then
                RefillHands()
            end
            Attacker = "opp"
            SendNet("BITO")
        else
            RefillHands()
            Attacker = "opp"
            C_Timer.After(0.45, RunAI)
        end
    else
        -- Take all cards from table
        if #Table == 0 then return end
        for _, p in ipairs(Table) do
            table.insert(MyHand, p.atk)
            if p.def then table.insert(MyHand, p.def) end
        end
        Table = {}
        if NetMode then
            if IsHost then
                RefillHands()
            end
            Attacker = "opp"
            SendNet("TAKE:" .. #MyHand)
        else
            RefillHands()
            Attacker = "opp"
            C_Timer.After(0.45, RunAI)
        end
    end
    WR.PlaySound(856)
    Render()
    CheckWin()
end

local function MakeCardButton(parent, w, h)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(w, h)
    b.border = b:CreateTexture(nil, "BACKGROUND"); b.border:SetAllPoints()
    b.bg = b:CreateTexture(nil, "BORDER"); b.bg:SetPoint("TOPLEFT", 2, -2); b.bg:SetPoint("BOTTOMRIGHT", -2, 2)
    b.topTxt = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    b.topTxt:SetPoint("TOPLEFT", 4, -4)
    b.portrait = b:CreateTexture(nil, "ARTWORK")
    b.portrait:SetSize(34, 34)
    b.portrait:SetPoint("CENTER", 0, -4)
    b.portrait:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    b.portrait:Hide()
    b.suitIco = b:CreateTexture(nil, "OVERLAY")
    b.suitIco:SetSize(28, 28)
    b.suitIco:SetPoint("CENTER", 0, -6)
    b.suitIco:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    return b
end

Render = function()
    for _, b in ipairs(HandBtns) do b:Hide() end
    for _, p in ipairs(TableCards) do p.atk:Hide(); p.def:Hide() end

    -- Trump badge
    local ts = SUITS[TrumpSuit]
    TrumpBox:SetText("Козырь: " .. ts.color .. ts.sym .. "|r")
    DeckText:SetText(string.format("Колода: %d  |  У врага: %d", #Deck, NetMode and OppCount or #OppHand))

    -- Action button
    if Attacker == "me" then
        ActionBtn:SetText("Бито")
    else
        ActionBtn:SetText("Взять")
    end

    -- Table pairs
    for i, pair in ipairs(Table) do
        local slot = TableCards[i]
        if slot then
            local x = -((#Table - 1) * 34) + (i - 1) * 68
            slot.atk:ClearAllPoints()
            slot.atk:SetPoint("CENTER", Root, "CENTER", x, 24)
            StyleCard(slot.atk, pair.atk, false)
            if pair.def then
                slot.def:ClearAllPoints()
                slot.def:SetPoint("CENTER", Root, "CENTER", x + 10, 8)
                StyleCard(slot.def, pair.def, false)
            end
        end
    end

    -- My hand
    local n = #MyHand
    local step = math.min(54, math.floor(480 / math.max(1, n)))
    local startX = -((n - 1) * step) * 0.5
    for i, c in ipairs(MyHand) do
        local b = HandBtns[i]
        if not b then
            b = MakeCardButton(Root, 52, 72)
            local ii = i
            b:SetScript("OnClick", function() OnMyCardClick(ii) end)
            HandBtns[i] = b
        end
        b:ClearAllPoints()
        b:SetPoint("BOTTOM", Root, "BOTTOM", startX + (i - 1) * step, 44)
        b:SetFrameLevel(Root:GetFrameLevel() + 10 + i)
        StyleCard(b, c, true)
    end

    local turnStr = (Attacker == "me") and "|cFF44FF44Твоя атака|r" or "|cFFFF5555Твоя защита|r"
    if NetMode and Opponent then turnStr = turnStr .. " (vs " .. ShortName(Opponent) .. ")" end
    WR.SetHUD(turnStr, string.format("Побед: |cFFFFD100%d|r", WarcraftRunnerDB.bestDurak or 0))
end

local function EnsureUI()
    if Root then return end
    Root = CreateFrame("Frame", nil, WR.Viewport)
    Root:SetAllPoints()
    Root:SetFrameLevel(WR.Viewport:GetFrameLevel() + 8)

    TrumpBox = Root:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    TrumpBox:SetPoint("TOPLEFT", 16, -46)

    DeckText = Root:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    DeckText:SetPoint("TOPRIGHT", -16, -48)

    for i = 1, 6 do
        local atk = MakeCardButton(Root, 52, 72)
        local def = MakeCardButton(Root, 52, 72)
        def:SetFrameLevel(atk:GetFrameLevel() + 2)
        atk:Hide(); def:Hide()
        TableCards[i] = { atk = atk, def = def }
    end

    ActionBtn = CreateFrame("Button", nil, Root, "UIPanelButtonTemplate")
    ActionBtn:SetSize(96, 26)
    ActionBtn:SetPoint("RIGHT", Root, "RIGHT", -16, 24)
    ActionBtn:SetText("Бито")
    ActionBtn:SetScript("OnClick", OnActionClick)

    local bar = CreateFrame("Frame", nil, Root)
    bar:SetHeight(26)
    bar:SetPoint("BOTTOMLEFT", 12, 8)
    bar:SetPoint("BOTTOMRIGHT", -12, 8)

    NameInput = CreateFrame("EditBox", nil, bar, "InputBoxTemplate")
    NameInput:SetSize(140, 20)
    NameInput:SetPoint("LEFT", 4, 0)
    NameInput:SetAutoFocus(false)
    NameInput:SetMaxLetters(40)
    NameInput:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

    local inviteBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    inviteBtn:SetSize(120, 22)
    inviteBtn:SetPoint("LEFT", NameInput, "RIGHT", 6, 0)
    inviteBtn:SetText("Вызвать (PvP)")
    inviteBtn:SetScript("OnClick", function()
        local target = strtrim(NameInput:GetText() or "")
        if target == "" and UnitExists("target") and UnitIsPlayer("target") then
            local n, realm = UnitName("target")
            target = (realm and realm ~= "") and (n .. "-" .. realm) or n
            NameInput:SetText(target)
        end
        if target == "" then
            WR.FloatText("Выбери игрока или введи ник!", 0, -100, 1, 0.35, 0.35)
            return
        end
        SendNet("INVITE", target)
        WR.FloatText("Вызов отправлен: " .. ShortName(target), 0, -100, 0.3, 0.9, 1)
    end)

    local soloBtn = CreateFrame("Button", nil, bar, "UIPanelButtonTemplate")
    soloBtn:SetSize(105, 22)
    soloBtn:SetPoint("RIGHT", 0, 0)
    soloBtn:SetText("Соло (ИИ)")
    soloBtn:SetScript("OnClick", function()
        G:Start(false, nil)
    end)
end

function G:Start(isNet, oppName, isHost)
    EnsureUI()
    Root:Show()
    if WR.Overlay then WR.Overlay:Hide() end
    NetMode = isNet and true or false
    Opponent = oppName
    IsHost = (isHost == nil) and true or isHost
    Table = {}
    MyHand = {}
    OppHand = {}
    GameActive = true
    WR.State.running = true

    if not NetMode or IsHost then
        Deck = {}
        for s = 1, 4 do
            for r = 6, 14 do table.insert(Deck, { suit = s, rank = r }) end
        end
        for i = #Deck, 2, -1 do
            local j = math.random(1, i)
            Deck[i], Deck[j] = Deck[j], Deck[i]
        end
        TrumpSuit = Deck[#Deck].suit
        for _ = 1, 6 do table.insert(MyHand, table.remove(Deck, 1)) end
        for _ = 1, 6 do table.insert(OppHand, table.remove(Deck, 1)) end
        OppCount = 6
        Attacker = "me"
        if NetMode and IsHost then
            SendNet(string.format("DEAL:%d:%s:%s", TrumpSuit, SerializeList(OppHand), SerializeList(Deck)))
            OppHand = {}
        end
    end
    Render()
end

function G:ShowIntro()
    EnsureUI()
    Root:Show()
    WR.SetHUD("Подкидной Дурак (36 карт)", string.format("Побед: %d", WarcraftRunnerDB.bestDurak or 0))
    WR.ShowOverlay("|cFFFFD100ПОДКИДНОЙ ДУРАК|r", "Играй против ИИ или вызови игрока по сети (ник / таргет).", "Играть против ИИ", function()
        G:Start(false, nil)
    end)
end

function G:Stop()
    if Root then Root:Hide() end
end

local NetFrame = CreateFrame("Frame")
NetFrame:RegisterEvent("PLAYER_LOGIN")
NetFrame:RegisterEvent("CHAT_MSG_ADDON")
NetFrame:SetScript("OnEvent", function(_, event, prefix, msg, _, sender)
    if event == "PLAYER_LOGIN" then
        if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
            pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX)
        elseif RegisterAddonMessagePrefix then
            pcall(RegisterAddonMessagePrefix, PREFIX)
        end
        return
    end
    if event ~= "CHAT_MSG_ADDON" or prefix ~= PREFIX or not msg then return end
    if ShortName(sender) == UnitName("player") then return end

    if msg == "INVITE" then
        PendingInviteFrom = sender
        print(string.format("|cFFFFD100[Warcraft Runner]|r %s вызывает вас в Дурака! Откройте /runner -> Дурак.", ShortName(sender)))
        if not WR.MainFrame or not WR.MainFrame:IsShown() then WR.Toggle() end
        WR.SelectGame("durak")
        WR.ShowOverlay(
            "|cFFFFD100ВЫЗОВ В ДУРАКА!|r",
            string.format("Игрок |cFF33EEFF%s|r приглашает сыграть в Подкидного Дурака.", ShortName(sender)),
            "Принять вызов",
            function()
                if PendingInviteFrom then
                    SendNet("ACCEPT", PendingInviteFrom)
                    G:Start(true, PendingInviteFrom, false)
                    PendingInviteFrom = nil
                end
            end
        )
    elseif msg == "ACCEPT" then
        if not WR.MainFrame or not WR.MainFrame:IsShown() then WR.Toggle() end
        WR.SelectGame("durak")
        G:Start(true, sender, true)
    elseif msg:sub(1, 5) == "DEAL:" then
        local _, ts, handStr, deckStr = strsplit(":", msg, 4)
        TrumpSuit = tonumber(ts) or 1
        MyHand = DeserializeList(handStr)
        Deck = DeserializeList(deckStr)
        OppCount = 6
        Table = {}
        Attacker = "opp"
        GameActive = true
        WR.State.running = true
        if WR.Overlay then WR.Overlay:Hide() end
        Render()
    elseif msg:sub(1, 4) == "ATK:" then
        local _, su, rk, cnt = strsplit(":", msg)
        table.insert(Table, { atk = { suit = tonumber(su), rank = tonumber(rk) }, def = nil })
        OppCount = tonumber(cnt) or OppCount
        Render()
        CheckWin()
    elseif msg:sub(1, 4) == "DEF:" then
        local _, idx, su, rk, cnt = strsplit(":", msg)
        local ii = tonumber(idx)
        if Table[ii] then Table[ii].def = { suit = tonumber(su), rank = tonumber(rk) } end
        OppCount = tonumber(cnt) or OppCount
        Render()
        CheckWin()
    elseif msg == "BITO" then
        Table = {}
        if IsHost then RefillHands() end
        Attacker = "me"
        Render()
        CheckWin()
    elseif msg:sub(1, 5) == "TAKE:" then
        local _, cnt = strsplit(":", msg)
        OppCount = tonumber(cnt) or OppCount
        Table = {}
        if IsHost then RefillHands() end
        Attacker = "me"
        Render()
        CheckWin()
    elseif msg:sub(1, 5) == "DRAW:" then
        local got = DeserializeList(msg:sub(6))
        for _, c in ipairs(got) do table.insert(MyHand, c) end
        Render()
    elseif msg:sub(1, 5) == "DECK:" then
        Deck = DeserializeList(msg:sub(6))
        Render()
    end
end)
